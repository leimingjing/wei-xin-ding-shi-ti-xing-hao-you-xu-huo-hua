# -*- coding: utf-8 -*-
"""入口：常驻调度 + 系统托盘控制。

用法：
    python app.py                  # 常驻运行（调度 + 托盘）
    python app.py --run-now        # 立即执行一次后退出
    python app.py --run-now --real # 立即真实执行一次（需 approved=true 且 dry_run=false）
    python app.py --no-tray        # 常驻但不显示托盘
    python app.py --probe          # 只跑控件树探测
"""
import argparse
import atexit
import contextlib
import os
import random
import runpy
import sys
import threading
import time

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

# 控制台视觉系统（仅影响显示，失败不阻塞启动）。
# 桌面客户端（client.py）不碰终端：设置 WECHAT_AUTO_CLIENT=1 跳过主题初始化，
# 避免在无控制台环境（pythonw / PyInstaller windowed）里做终端探测。
sys.path.insert(0, os.path.join(ROOT, "workbench"))
if os.environ.get("WECHAT_AUTO_CLIENT") == "1":
    ui_theme = None
    UI = None
else:
    try:
        import theme as ui_theme

        UI = ui_theme.init(title="微信定时发送 · 管理员工作台")
    except Exception:  # pragma: no cover - 降级为无样式输出
        ui_theme = None
        UI = None


def styled(kind: str, text: str, detail: str = "") -> str:
    """有主题时用带色行，否则退回纯文本，保证任何终端都能读。"""
    if UI:
        return UI.toast(kind, text, detail)
    return f"{text} {detail}".strip()

from wechat_auto import logger as logutil  # noqa: E402
from wechat_auto.config_loader import Config  # noqa: E402
from wechat_auto.safety import SingleInstance  # noqa: E402
from wechat_auto.sender import Sender  # noqa: E402

# 任务执行状态悬浮窗（右上角置顶倒计时）。纯装饰性能力：模块加载失败一律降级为空操作，
# 绝不因为悬浮窗影响发送主流程。
try:
    from wechat_auto import overlay as _overlay
except Exception:  # pragma: no cover - 降级路径
    _overlay = None

WEEKDAY_MAP = {1: "mon", 2: "tue", 3: "wed", 4: "thu", 5: "fri", 6: "sat", 7: "sun"}

# 工作台是否正在占用控制台：占用时后台线程不再刷新加载动画，避免打乱输入行
_UI_ACTIVE = {"on": False}


def overlay_enabled(cfg: Config) -> bool:
    return _overlay is not None and bool((getattr(cfg, "ui", {}) or {}).get("task_overlay", True))


def overlay_budget(cfg: Config, count: int) -> int:
    """按联系人数估算任务总时长（秒），只用于倒计时显示。"""
    per = int((getattr(cfg, "ui", {}) or {}).get("seconds_per_target", 45) or 45)
    return max(15, per * max(1, int(count)))


def task_overlay(cfg: Config, count: int, detail: str = ""):
    """悬浮窗作用域：正常结束 / 取消 / 报错都会关闭窗口并释放计时器。

    未启用或模块不可用时退化为空上下文，调用方无需关心。
    """
    if not overlay_enabled(cfg):
        return contextlib.nullcontext()
    return _overlay.task_window(overlay_budget(cfg, count), detail=detail)


def overlay_detail(text: str):
    """更新悬浮窗副标题（如「正在处理 示例联系人A（1/2）」）。"""
    if _overlay:
        try:
            _overlay.set_detail(text)
        except Exception:
            pass


def register_jobs(scheduler, cfg: Config, logger):
    """按当前配置注册全部定时任务（重复调用前先 remove_all_jobs）。"""
    from apscheduler.triggers.cron import CronTrigger

    weekdays = ",".join(WEEKDAY_MAP[d] for d in cfg.schedule.get("weekdays", [1, 2, 3, 4, 5, 6, 7]))
    sender = Sender(cfg, logger)

    times = {}
    for target in cfg.targets:
        for t in cfg.target_times(target):
            times.setdefault(str(t), []).append(target)

    if not times:
        logger.warning(
            "当前没有任何定时任务：targets 里没有 enabled: true 的联系人。"
            "常驻进程会继续运行但不会发送——请先启用联系人并确认其时间点"
        )

    for time_str, targets in times.items():
        try:
            hour, minute = str(time_str).split(":")[:2]
            trigger = CronTrigger(
                hour=int(hour), minute=int(minute), day_of_week=weekdays, timezone="Asia/Shanghai"
            )
        except Exception as exc:
            logger.error(f"时间点 {time_str} 解析失败：{exc}")
            continue

        def make_job(ts=time_str, group=targets):
            def job():
                jitter = random.randint(0, max(0, int(cfg.schedule.get("jitter_minutes", 3))) * 60)
                if jitter:
                    logger.info(f"[{ts}] 随机延后 {jitter} 秒执行")
                    time.sleep(jitter)
                total = len(group)
                with task_overlay(cfg, total, detail=f"共 {total} 位联系人"):
                    for i, target in enumerate(group, start=1):
                        overlay_detail(f"正在处理 {target['name']}（{i}/{total}）")
                        cfg.reload()
                        result = sender.run_once(target)
                        logger.info(f"[{ts}] {target['name']} 执行结果：{result['status']} {result['detail']}")
                logger.info(
                    f"[{ts}] 本轮任务完成（{total} 位联系人），已恢复后台最小占用"
                )

            return job

        scheduler.add_job(make_job(), trigger, id=f"send_{time_str}", max_instances=1)
        logger.info(f"已注册定时任务：每天 {time_str}（{weekdays}）→ {[t['name'] for t in targets]}")

        # 发送前 2 分钟自检（跨小时取模），同一时间点只注册一次
        def make_check(ts=time_str, group=targets):
            def check():
                preflight_check(cfg, logger, group, ts)

            return check

        ch, cm = int(hour), int(minute) - 2
        if cm < 0:
            ch, cm = (ch - 1) % 24, cm + 60
        try:
            check_trigger = CronTrigger(
                hour=ch, minute=cm, day_of_week=weekdays, timezone="Asia/Shanghai"
            )
            scheduler.add_job(make_check(), check_trigger, id=f"preflight_{time_str}", max_instances=1)
            logger.info(f"已注册发送前自检：每天 {ch:02d}:{cm:02d}（提前 2 分钟）")
        except Exception as exc:
            logger.error(f"自检任务 {time_str} 注册失败：{exc}")


def build_scheduler(cfg: Config, logger):
    from apscheduler.schedulers.background import BackgroundScheduler

    scheduler = BackgroundScheduler(timezone="Asia/Shanghai")
    register_jobs(scheduler, cfg, logger)
    return scheduler


def run_now(cfg: Config, logger, real: bool = False):
    sender = Sender(cfg, logger)
    animate = UI is not None and not _UI_ACTIVE["on"]
    if UI and animate:
        mode = "正式发送" if real else "演练模式，不会真正发送"
        print("\n  " + UI.paint("accent", "立即执行一次", bold=True) + "  "
              + UI.paint("faint", mode))
        print(UI.rule(token="border2"))
    total = len(cfg.targets)
    with task_overlay(cfg, total, detail=f"共 {total} 位联系人"):
        for i, target in enumerate(cfg.targets, start=1):
            overlay_detail(f"正在处理 {target['name']}（{i}/{total}）")
            if animate:
                with ui_theme.Spinner(UI, f"正在处理 {target['name']}：定位 → 校验 → 发送"):
                    result = sender.run_once(target, dry_run=(not real))
            else:
                result = sender.run_once(target, dry_run=(not real))
            logger.info(f"{target['name']} 执行结果：{result['status']} {result['detail']}")
            if UI:
                tone = {"sent": "ok", "dry_run": "info"}.get(
                    result["status"], "warn" if result["status"] in ("skipped", "unverified") else "err"
                )
                print(UI.toast(tone, f"{target['name']}：{result['status']}", result["detail"]))
            else:
                print(f"{target['name']}: {result['status']} {result['detail']}")


def web_run(cfg: Config, logger, real: bool = False):
    """网页控制台触发的执行：只写日志、不直接 print，避免打乱控制台界面。

    执行结果会进入 logs/run.log，网页端「运行日志」页实时可见。
    """
    sender = Sender(cfg, logger)
    total = len(cfg.targets)
    with task_overlay(cfg, total, detail=f"共 {total} 位联系人"):
        for i, target in enumerate(cfg.targets, start=1):
            overlay_detail(f"正在处理 {target['name']}（{i}/{total}）")
            try:
                result = sender.run_once(target, dry_run=(not real))
                logger.info(f"[网页] {target['name']} 执行结果：{result['status']} {result['detail']}")
            except Exception as exc:
                logger.error(f"[网页] {target['name']} 执行异常：{exc}")


class TaskController:
    """把调度器包装成工作台可用的控制接口（暂停/恢复/状态）。

    权限校验沿用原有逻辑：dry_run 开关 + approved 双闸门 + 标题参考图，
    这里只负责展示与暂停，不改变任何发送判定。
    """

    def __init__(self, scheduler, cfg: Config, logger, state: dict):
        self.scheduler = scheduler
        self.cfg = cfg
        self.logger = logger
        self.state = state

    @property
    def paused(self) -> bool:
        return bool(self.state.get("paused"))

    def toggle_pause(self) -> bool:
        self.state["paused"] = not self.paused
        if self.state["paused"]:
            self.scheduler.pause()
        else:
            self.scheduler.resume()
        self.logger.info("调度已" + ("暂停" if self.state["paused"] else "恢复"))
        return self.state["paused"]

    def next_run(self) -> str:
        times = [
            j.next_run_time for j in self.scheduler.get_jobs()
            if j.next_run_time and not str(j.id).startswith("preflight_")
        ]
        if not times:
            return "无（没有启用的联系人）"
        return min(times).strftime("%Y-%m-%d %H:%M:%S")

    def upcoming(self) -> list:
        """全部定时任务的下次执行信息（按下次执行时间升序）。

        每个启用的联系人一行：各自的时间点、下次执行时间与批准/参考图状态。
        """
        jobs = {}
        try:
            for j in self.scheduler.get_jobs():
                if j.next_run_time and not str(j.id).startswith("preflight_"):
                    jobs[str(j.id)] = j.next_run_time
        except Exception:
            pass

        rows = []
        for t in self.cfg.targets:
            if not t.get("enabled"):
                continue
            name = t.get("name", "")
            ts = [str(x) for x in self.cfg.target_times(t)]
            nrts = [jobs[f"send_{x}"] for x in ts if f"send_{x}" in jobs]
            nrt = min(nrts) if nrts else None
            ref = os.path.join(cfg_ref_dir(self.cfg), f"{name}.png")
            rows.append({
                "name": name,
                "times": ts,
                "next_run": nrt.strftime("%Y-%m-%d %H:%M:%S") if nrt else "",
                "approved": bool(t.get("approved")),
                "has_ref": os.path.exists(ref),
            })
        rows.sort(key=lambda r: r["next_run"] or "9999-99-99 99:99:99")
        return rows

    def brief(self) -> str:
        mode = "演练 dry_run" if self.cfg.safety.get("dry_run") else "正式发送"
        return f"发送任务：{'已暂停' if self.paused else '运行中'} | {mode} | 下次 {self.next_run()}"

    def status_lines(self):
        dry = self.cfg.safety.get("dry_run", True)
        targets = self.cfg.targets
        lines = [
            f"调度状态  ：{'已暂停' if self.paused else '运行中'}",
            f"发送模式  ：{'演练模式（不会真正发送）' if dry else '正式发送'}",
            f"下次执行  ：{self.next_run()}",
            f"已启用联系人：{len(targets)} 个",
        ]
        from wechat_auto.vision import ref_path_for  # 与 vision 共用同一套文件名消毒规则（P2-2）

        for t in targets:
            ref = ref_path_for(self.cfg.root, t["name"])
            gate = "已批准" if t.get("approved") else "未批准"
            has_ref = "有参考图" if os.path.exists(ref) else "缺参考图"
            lines.append(
                f"   - {t['name']} | {', '.join(cfg_times(self.cfg, t))} | {gate} | {has_ref}"
            )
        if dry:
            lines.append("提示：正式发送需 safety.dry_run=false 且联系人 approved=true")
        return lines


def cfg_times(cfg: Config, target: dict):
    return [str(x) for x in cfg.target_times(target)]


def cfg_ref_dir(cfg: Config) -> str:
    return os.path.join(cfg.root, "assets", "refs")


def preflight_check(cfg: Config, logger, targets, ts: str):
    """定时发送前 2 分钟自检：只读检测、不改变任何状态，结果写运行日志。

    通过 → 记一条 INFO；有问题 → 逐条 WARNING（不阻塞调度，发送时各闸门照常把关）。
    """
    problems, notes = [], []
    kill = str(cfg.safety.get("kill_switch_file") or "STOP")
    if os.path.exists(os.path.join(cfg.root, kill)):
        problems.append("急停生效：STOP 文件存在，本轮任务不会发送")
    try:
        cfg.reload()
    except Exception as exc:
        problems.append(f"配置重载失败：{exc}")
    # 微信窗口：找不到只提醒（发送时会自动拉起），不阻塞
    try:
        from wechat_auto.wechat.window import WeChatWindow

        win = WeChatWindow(cfg.wechat, logger)
        found = win.find(timeout=2.0)
        # P1-4：is_login_window() 是 WeChatWindow 的方法，而 find() 返回的是 uiautomation
        # Control（或 None）。原实现对返回对象 getattr("is_login_window") 恒为 None →
        # callable 恒为假 → 这个分支从未执行过，9-19 凌晨"微信停在登录页"时自检没有任何
        # 提前提醒。正确姿势：把 Control 交给窗口对象，再向窗口对象提问。
        if found is None:
            notes.append("微信窗口未找到（发送时会自动拉起微信）")
        else:
            win.control = found
            if win.is_login_window():
                problems.append("微信停在登录页：未登录状态下无法发送")
            else:
                # P2-5：layout 里的像素偏移是按固定窗口尺寸/缩放实测的，换显示器或改缩放后
                # 必须先重跑校准，否则会依次表现为"搜索没生效 / 相似度恒失败 / 点错行"。
                base = dict(cfg.wechat.get("window_baseline") or {})
                try:
                    bw, bh = int(base.get("width") or 0), int(base.get("height") or 0)
                except Exception:
                    bw, bh = 0, 0
                rect = win.snapshot_rect()
                if bw and bh and rect:
                    cw, ch = int(rect[2]), int(rect[3])
                    if abs(cw - bw) > 24 or abs(ch - bh) > 24:
                        notes.append(
                            f"窗口尺寸 {cw}x{ch} 与校准基准 {bw}x{bh} 不一致："
                            "坐标定位可能偏移，建议重跑「位置校准」"
                        )
    except Exception as exc:
        notes.append(f"微信窗口检测异常（不阻塞发送）：{exc}")
    from wechat_auto.vision import ref_path_for  # 参考图路径唯一权威实现（P2-2）

    for t in targets:
        name = t.get("name", "")
        if not t.get("approved"):
            problems.append(f"{name} 未批准（approved: false），正式模式不会发送")
        if not os.path.exists(ref_path_for(cfg.root, name)):
            problems.append(f"{name} 缺参考图，发送会被安全中止")
    if problems:
        for p in problems:
            logger.warning(f"[自检 {ts}] {p}")
        logger.warning(f"[自检 {ts}] 共 {len(problems)} 个问题，请尽快处理；发送时各闸门照常把关")
        return False
    logger.info(
        f"[自检 {ts}] 通过：{', '.join(t.get('name', '') for t in targets)} 将按时发送"
        + ("；" + "；".join(notes) if notes else "")
    )
    return True


def build_tray(cfg: Config, logger, scheduler, state, web=None):
    import pystray
    from PIL import Image, ImageDraw

    size = 64
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.ellipse((2, 2, size - 3, size - 3), fill=(7, 193, 96, 255))
    draw.ellipse((18, 18, 46, 46), fill=(255, 255, 255, 255))
    draw.ellipse((12, 12, 30, 30), fill=(255, 255, 255, 255))

    def status_text(item):
        return f"状态：{'已暂停' if state['paused'] else '运行中'}"

    def toggle_pause(icon, item):
        state["paused"] = not state["paused"]
        if state["paused"]:
            scheduler.pause()
        else:
            scheduler.resume()
        logger.info("调度已" + ("暂停" if state["paused"] else "恢复"))
        icon.update_menu()

    def do_run(icon, item):
        threading.Thread(target=lambda: run_now(cfg, logger, real=False), daemon=True).start()

    def open_config(icon, item):
        os.startfile(cfg.path)

    def open_logs(icon, item):
        os.startfile(os.path.join(cfg.root, "logs"))

    def open_web(icon, item):
        if web:
            web.open_browser()

    def quit_app(icon, item):
        logger.info("收到退出指令")
        try:
            scheduler.shutdown(wait=False)
        except Exception:
            pass
        icon.stop()

    menu = pystray.Menu(
        pystray.MenuItem(status_text, None, enabled=False),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("打开网页控制台", open_web),
        pystray.MenuItem("立即演练一次（不发送）", do_run),
        pystray.MenuItem(lambda item: "恢复调度" if state["paused"] else "暂停调度", toggle_pause),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("打开配置文件", open_config),
        pystray.MenuItem("打开日志目录", open_logs),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("退出", quit_app),
    )
    return pystray.Icon("wechat_auto", image, "微信定时发送", menu)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None, help="配置文件路径")
    parser.add_argument("--run-now", action="store_true", help="立即执行一次后退出")
    parser.add_argument("--real", action="store_true", help="配合 --run-now 强制真实发送")
    parser.add_argument("--no-tray", action="store_true", help="常驻但不显示托盘")
    parser.add_argument("--no-web", action="store_true", help="不启动网页控制台")
    parser.add_argument("--web-port", type=int, default=8788, help="网页控制台端口（默认 8788）")
    parser.add_argument("--no-browser", action="store_true", help="启动后不自动打开浏览器")
    parser.add_argument("--probe", action="store_true", help="只运行控件树探测")
    args = parser.parse_args()

    if args.probe:
        # P1-3：打包后 sys.executable 指向 exe 本身，subprocess.call([sys.executable, probe])
        # 等价于"再启动一个客户端实例"，probe.py 根本不会被执行。改为进程内 runpy 执行，
        # 源码运行与打包运行走同一条路径。
        probe = os.path.join(ROOT, "tools", "probe.py")
        argv_backup = sys.argv
        sys.argv = [probe]
        try:
            import ctypes

            try:  # uiautomation 需要 COM 已初始化（打包后主线程尚未初始化）
                ctypes.windll.ole32.CoInitialize(None)
            except Exception:
                pass
            runpy.run_path(probe, run_name="__main__")
        except SystemExit:
            pass
        finally:
            sys.argv = argv_backup
        sys.exit(0)

    cfg = Config(ROOT, args.config)
    logger = logutil.setup(ROOT, int(cfg.safety.get("log_retention_days", 30)))
    errors, warns = cfg.validate()
    for w in warns:
        logger.warning(w)
    if errors:
        for e in errors:
            logger.error(e)
        print(styled("err", "配置有误，已终止", "；".join(errors)))
        sys.exit(1)

    # 单实例锁：防止常驻进程与手动执行并发，导致重复发送
    lock = SingleInstance(ROOT)
    if not lock.acquire():
        msg = (
            f"已有实例在运行（PID {lock.owner_pid}），本次启动已放弃。"
            f"若要重启：先结束该进程，或删除 {lock.path}"
        )
        logger.warning(msg)
        print(styled("warn", "已有实例在运行，本次启动已放弃",
                     f"PID {lock.owner_pid}；重启请先结束该进程"))
        sys.exit(0)
    atexit.register(lock.release)

    logger.info("=" * 60)
    logger.info("程序启动")

    if args.run_now:
        run_now(cfg, logger, real=args.real)
        return

    scheduler = build_scheduler(cfg, logger)
    scheduler.start()

    state = {"paused": False}
    controller = TaskController(scheduler, cfg, logger, state)

    # 联系人数据层提前建好：网页控制台与控制台工作台共用同一份（改动互相可见）
    try:
        from contacts import ContactStore
    except Exception as exc:
        logger.error(f"联系人数据层加载失败：{exc}")
        print(styled("err", "联系人数据层加载失败", str(exc)))
        scheduler.shutdown(wait=False)
        sys.exit(1)
    store = ContactStore(os.path.join(ROOT, "data", "contacts.json"))  # noqa: F811  与网页控制台共用同一实例

    # 网页控制台（默认开启）：只监听 127.0.0.1，安全闸门全部沿用
    web = None
    if not args.no_web:
        try:
            from wechat_auto.webapp import WebConsole

            def rebuild_schedule():
                """网页端改了 config.yaml 后重建定时任务，让改动立即生效。"""
                cfg.reload()
                scheduler.remove_all_jobs()
                if state.get("paused"):
                    scheduler.pause()
                register_jobs(scheduler, cfg, logger)

            web = WebConsole(
                ROOT, store, cfg=cfg, controller=controller,
                run_now=lambda real: web_run(cfg, logger, real=real), logger=logger,
                on_config_change=rebuild_schedule,
            )
            web.start(args.web_port, open_browser=not args.no_browser)
            logger.info(f"网页控制台已启动：{web.url}")
            print(styled("info", "网页控制台已就绪", web.url))
        except Exception as exc:
            logger.warning(f"网页控制台启动失败，控制台工作台不受影响：{exc}")
            web = None

    # 托盘放后台线程（可选），主线程让给工作台界面
    if not args.no_tray:
        try:
            icon = build_tray(cfg, logger, scheduler, state, web=web)
            threading.Thread(target=icon.run, daemon=True).start()
            logger.info("托盘已在后台启动（图标在任务栏右下角，可能被折叠进隐藏图标区）")
        except Exception as exc:
            logger.warning(f"托盘启动失败，已继续运行：{exc}")

    # 合并后的唯一界面入口：管理员工作台（同一进程内打开，不再单开实例）
    try:
        from ui import Workbench
    except Exception as exc:
        logger.error(f"工作台模块加载失败：{exc}")
        print(styled("err", "工作台模块加载失败", str(exc)))
        if web:
            web.stop()
        scheduler.shutdown(wait=False)
        sys.exit(1)

    workbench = Workbench(store, controller)
    # 控制台交给界面：启动期日志暂存下来，由工作台统一重放，不与菜单混排
    workbench.notices = logutil.attach_console_sink(workbench.on_log) + workbench.notices
    if web:
        workbench.notices.append(("INFO", f"网页控制台已就绪：{web.url}（浏览器可随时打开）"))
    if UI:
        atexit.register(UI.screen_end)  # 异常退出时也把终端还原

    logger.info("已打开管理员工作台")
    _UI_ACTIVE["on"] = True
    try:
        workbench.run()
    finally:
        _UI_ACTIVE["on"] = False
        logutil.detach_console_sink()
        if UI:
            UI.screen_end()
        if web:
            web.stop()
        try:
            scheduler.shutdown(wait=False)
        except Exception:
            pass
    logger.info("程序退出")


if __name__ == "__main__":
    main()
