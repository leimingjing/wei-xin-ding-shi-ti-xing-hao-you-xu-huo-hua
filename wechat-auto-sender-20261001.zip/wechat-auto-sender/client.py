# -*- coding: utf-8 -*-
"""桌面客户端入口：独立窗口（pywebview / WebView2）+ 内嵌后端 + 系统托盘。

架构：后端（APScheduler 调度 + 网页控制台 http.server）跑在本进程的后台线程里，
没有子进程、没有 CMD 黑窗；客户端退出时随进程一起结束，天然不残留。

交互：
- 托盘左键单击/双击 = 恢复窗口（菜单 default 项）；右键 = 完整菜单。
- 关闭窗口行为由 data/settings.json 的 close_behavior 决定：minimize=收进托盘 / exit=退出。
- 三个客户端开关（开机自启 / 关闭行为 / 启动最小化）在网页「设置」页改，经 /api/settings 落盘。

用法：
    python client.py                # 打开客户端窗口（开发模式）
    python client.py --startup      # 开机自启拉起（配合「启动时最小化到托盘」）
    python client.py --no-window    # 只跑后端 + 托盘（调试）
"""
import argparse
import atexit
import ctypes
import os
import sys
import threading
import time

# ── 无控制台兜底（必须在任何可能 print 的 import 之前）──────────────────────
# windowed 运行（pythonw / PyInstaller --noconsole）下 sys.stdout/stderr 是 None，
# 任何 print 都会抛 AttributeError。先重定向到日志文件再 import 别的模块。
if sys.stdout is None or sys.stderr is None:
    _boot_root = os.path.dirname(os.path.abspath(
        sys.executable if getattr(sys, "frozen", False) else __file__))
    os.makedirs(os.path.join(_boot_root, "logs"), exist_ok=True)
    _sink = open(os.path.join(_boot_root, "logs", "client_stdout.log"),
                 "a", encoding="utf-8", buffering=1)
    if sys.stdout is None:
        sys.stdout = _sink
    if sys.stderr is None:
        sys.stderr = _sink

os.environ["WECHAT_AUTO_CLIENT"] = "1"  # app.py 看到后跳过终端主题初始化

# ROOT：打包后 = exe 所在目录（config/data/web/assets 都在这）；源码 = 本文件目录
if getattr(sys, "frozen", False):
    ROOT = os.path.dirname(os.path.abspath(sys.executable))
else:
    ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "workbench"))

import app  # noqa: E402  复用调度注册 / Sender / 悬浮窗；客户端模式下不碰终端
from wechat_auto import logger as logutil  # noqa: E402
from wechat_auto.config_loader import Config  # noqa: E402
from wechat_auto.safety import SingleInstance  # noqa: E402
from wechat_auto.settings import Settings  # noqa: E402
from wechat_auto.webapp import WebConsole  # noqa: E402

TITLE = "微信定时发送 · 续火花"
MB_INFO, MB_ERROR = 0x40, 0x10


def decide_close(behavior, quitting: bool) -> bool:
    """关闭窗口决策（纯函数，供自检）：True=放行关闭（程序退出），False=收进托盘。"""
    if quitting:
        return True
    return str(behavior) == "exit"


def _message_box(text: str, style: int = MB_INFO):
    """无控制台环境下的报错出口：原生消息框，不依赖任何 GUI 库。"""
    try:
        ctypes.windll.user32.MessageBoxW(None, text, TITLE, style)
    except Exception:
        pass


def _silence_http_noise():
    """P3-3：压掉 pywebview 内嵌 HTTP 服务的连接重置堆栈与退出清理噪音。

    dist\logs\client_stdout.log 里前端每轮轮询断开都会留下一段
    `ConnectionResetError: [WinError 10054]` 堆栈（数百行/轮），把真实错误
    （如 NameError、登录失败判定）彻底淹没。这里只改"错误怎么打印"，不改任何行为：
      · socketserver 的连接类异常（关页面/刷新属正常现象）→ 吞掉
      · 其它异常 → 一行精简输出，保留可诊断性
      · pywebview 退出时"删不掉用户数据目录"的提示 → 丢弃（无害噪音）
    """
    try:
        import socketserver

        def handle_error(request, client_address):
            exc = sys.exc_info()[1]
            if isinstance(exc, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError)):
                return
            try:
                sys.stderr.write(f"[http] {type(exc).__name__}: {exc}\n")
            except Exception:
                pass

        socketserver.BaseServer.handle_error = handle_error
    except Exception:
        pass
    try:
        import logging

        class _Noise(logging.Filter):
            def filter(self, record):
                try:
                    return "Failed to delete user data folder" not in record.getMessage()
                except Exception:
                    return True

        logging.getLogger("pywebview").addFilter(_Noise())
    except Exception:
        pass


def _load_icon_image():
    """托盘图标：优先 assets/app.ico（打包内置），缺失则现场画一个绿色圆。"""
    from PIL import Image, ImageDraw

    ico = os.path.join(ROOT, "assets", "app.ico")
    if os.path.exists(ico):
        try:
            img = Image.open(ico)
            img.load()
            return img if img.mode == "RGBA" else img.convert("RGBA")
        except Exception:
            pass
    size = 64
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.ellipse((2, 2, size - 3, size - 3), fill=(7, 193, 96, 255))
    draw.ellipse((18, 18, 46, 46), fill=(255, 255, 255, 255))
    draw.ellipse((12, 12, 30, 30), fill=(255, 255, 255, 255))
    return img


def build_tray(cfg, logger, scheduler, state, web, window_ref, quitting):
    """客户端托盘：左键单击/双击恢复窗口（default 项），右键弹完整菜单。"""
    import pystray

    def status_text(item):
        return f"状态：{'已暂停' if state['paused'] else '运行中'}"

    def toggle_pause(icon, item):
        state["paused"] = not state["paused"]
        if state["paused"]:
            scheduler.pause()
        else:
            scheduler.resume()
        logger.info("调度已" + ("暂停" if state["paused"] else "恢复"))
        icon.update_menu()

    def do_run(icon, item):
        threading.Thread(target=lambda: app.web_run(cfg, logger, real=False),
                         daemon=True).start()

    def open_main(icon=None, item=None):
        window = window_ref[0]
        if window is not None:
            try:
                window.show()
                window.restore()
            except Exception as exc:
                logger.warning(f"[客户端] 恢复窗口失败：{exc}")

    def open_settings(icon=None, item=None):
        open_main()
        window = window_ref[0]
        if window is not None:
            try:  # 页面已加载时直接切页签；没加载完就带 hash 重载
                window.evaluate_js("location.hash='#settings'")
            except Exception:
                try:
                    window.load_url(f"{web.url}#settings")
                except Exception:
                    pass

    def open_config(icon, item):
        os.startfile(cfg.path)

    def open_logs(icon, item):
        os.startfile(os.path.join(ROOT, "logs"))

    def quit_app(icon=None, item=None):
        logger.info("[客户端] 托盘菜单退出")
        quitting["on"] = True          # 让 closing 事件放行，不再最小化
        try:
            icon.stop()
        except Exception:
            pass
        window = window_ref[0]
        if window is not None:
            try:
                window.destroy()       # 线程安全：内部 Invoke 到 UI 线程
            except Exception:
                pass

    menu = pystray.Menu(
        pystray.MenuItem(status_text, None, enabled=False),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("打开主界面", open_main, default=True),  # 左键单击/双击图标 = 这一项
        pystray.MenuItem("设置", open_settings),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("立即演练一次（不发送）", do_run),
        pystray.MenuItem(lambda item: "恢复调度" if state["paused"] else "暂停调度", toggle_pause),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("打开配置文件", open_config),
        pystray.MenuItem("打开日志目录", open_logs),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("退出", quit_app),
    )
    return pystray.Icon("wechat_auto_client", _load_icon_image(), TITLE, menu)


def _shutdown(logger, scheduler, web, icon, lock):
    """统一收尾：窗口已关（或托盘退出）后按依赖顺序停干净，最后强制退出防线程悬挂。"""
    try:
        scheduler.shutdown(wait=False)
    except Exception:
        pass
    try:
        web.stop()
    except Exception:
        pass
    if icon is not None:
        try:
            icon.stop()
        except Exception:
            pass
    try:
        logger.info("[客户端] 程序退出")
    except Exception:
        pass
    try:
        lock.release()
    except Exception:
        pass
    os._exit(0)  # 不留给非 daemon 线程悬挂进程的机会（锁已显式释放）


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None, help="配置文件路径")
    parser.add_argument("--web-port", type=int, default=8788, help="内嵌控制台端口（默认 8788）")
    parser.add_argument("--startup", action="store_true", help="开机自启拉起（带此参数仅作标记）")
    parser.add_argument("--no-window", action="store_true", help="只跑后端 + 托盘，不建窗口")
    parser.add_argument("--no-tray", action="store_true", help="不显示托盘（调试）")
    parser.add_argument("--smoke", action="store_true",
                        help="自检模式：完整启动（窗口+托盘+后端）后 3 秒自动走退出流程")
    args = parser.parse_args()

    cfg = Config(ROOT, args.config)
    logger = logutil.setup(ROOT, int(cfg.safety.get("log_retention_days", 30)))
    errors, warns = cfg.validate()
    for w in warns:
        logger.warning(w)
    if errors:
        for e in errors:
            logger.error(e)
        _message_box("配置有误，无法启动：\n\n" + "\n".join(errors), MB_ERROR)
        sys.exit(1)

    lock = SingleInstance(ROOT)
    if not lock.acquire():
        _message_box(
            f"程序已在运行（PID {lock.owner_pid}）。\n\n"
            "请在屏幕右下角的系统托盘找到绿色图标，单击即可打开主界面。")
        sys.exit(0)
    atexit.register(lock.release)

    logger.info("=" * 60)
    logger.info("桌面客户端启动" + ("（开机自启）" if args.startup else ""))

    settings = Settings(os.path.join(ROOT, "data", "settings.json"))
    settings.sync_auto_start_on_boot()  # 自愈：exe 挪过位置 / 注册表被清时按设置重写

    scheduler = app.build_scheduler(cfg, logger)
    scheduler.start()
    state = {"paused": False}
    controller = app.TaskController(scheduler, cfg, logger, state)

    try:
        from contacts import ContactStore
    except Exception as exc:
        logger.error(f"联系人数据层加载失败：{exc}")
        _message_box(f"联系人数据层加载失败：{exc}", MB_ERROR)
        sys.exit(1)
    store = ContactStore(os.path.join(ROOT, "data", "contacts.json"))

    def rebuild_schedule():
        cfg.reload()
        scheduler.remove_all_jobs()
        if state.get("paused"):
            scheduler.pause()
        app.register_jobs(scheduler, cfg, logger)

    # 内嵌后端：同进程线程，无子进程、无黑窗；客户端退出随进程结束
    web = WebConsole(
        ROOT, store, cfg=cfg, controller=controller,
        run_now=lambda real: app.web_run(cfg, logger, real=real), logger=logger,
        on_config_change=rebuild_schedule, settings=settings,
    )
    web.start(args.web_port, open_browser=False)
    logger.info(f"[客户端] 内嵌控制台就绪：{web.url}")

    quitting = {"on": False}       # 托盘退出 / close_behavior=exit 置 True，closing 事件放行
    window_ref = [None]            # 托盘回调里引用窗口（延迟绑定）
    icon = None
    if not args.no_tray:
        try:
            icon = build_tray(cfg, logger, scheduler, state, web, window_ref, quitting)
        except Exception as exc:
            logger.warning(f"[客户端] 托盘创建失败，已继续运行：{exc}")
            icon = None

    if args.no_window:
        # 无窗口模式：托盘跑主线程，退出靠托盘菜单（或无托盘时直接收尾）
        if icon is not None:
            icon.run()             # 阻塞到 icon.stop()
        _shutdown(logger, scheduler, web, icon, lock)
        return

    _silence_http_noise()
    import webview

    win = settings.data.get("window") or {}
    window = webview.create_window(
        TITLE, url=web.url,
        width=int(win.get("width", 1280)), height=int(win.get("height", 860)),
        min_size=(980, 640),
    )
    window_ref[0] = window

    pending_size = {}

    def save_size():
        if pending_size:
            try:
                settings.update({"window": {"width": pending_size["w"],
                                            "height": pending_size["h"]}})
            except Exception:
                pass

    def on_resized(width, height):
        pending_size["w"], pending_size["h"] = int(width), int(height)

    def on_closing():
        save_size()
        if decide_close(settings.data.get("close_behavior"), quitting["on"]):
            quitting["on"] = True
            return True                      # 托盘退出 / 设置「直接退出」：放行关闭
        try:                                 # 默认：最小化到托盘
            window.hide()
            if icon is not None:
                try:
                    icon.notify("程序仍在后台运行，单击托盘图标恢复窗口", TITLE)
                except Exception:
                    pass
        except Exception as exc:
            logger.warning(f"[客户端] 最小化到托盘失败：{exc}")
        return False                         # 返回 False = 取消关闭

    def on_shown():
        if settings.data.get("start_minimized"):
            try:
                window.hide()                # 启动即收进托盘（仅首次显示时）
            except Exception:
                pass

    window.events.closing += on_closing
    window.events.shown += on_shown
    window.events.resized += on_resized

    if args.smoke:
        def _auto_quit():
            time.sleep(3)
            logger.info("[客户端] 冒烟自检：3 秒到，自动退出")
            quitting["on"] = True
            try:
                window.destroy()
            except Exception:
                os._exit(0)
        threading.Thread(target=_auto_quit, daemon=True, name="smoke").start()

    if icon is not None:
        threading.Thread(target=icon.run, daemon=True, name="tray").start()
        logger.info("[客户端] 托盘已启动（右下角绿色图标，左键单击/双击打开主界面）")

    logger.info("[客户端] 主窗口已创建，进入消息循环")
    try:
        webview.start()                      # 阻塞到窗口真正关闭
    finally:
        _shutdown(logger, scheduler, web, icon, lock)


if __name__ == "__main__":
    main()
