# -*- coding: utf-8 -*-
"""发送编排：唤醒 → 搜索 → 校验 → 输入 → 发送 → 复核 → 收尾。

2026-09-19 修复（详见 docs/修复记录-20260919.md）：
  P0-1  MAX_CANDIDATES 未定义 → 恢复为模块级常量 CANDIDATE_LIMIT
  P0-2  results_before 未初始化 → 前置初始化 + 收尾统一 finally + 幂等保护
  P2-3  拒绝发送空消息；type_text 结束后还原用户剪贴板
  P2-4  进程内互斥，避免网页触发与定时任务并发驱动键鼠
  P3-1  程序缺陷 / 环境未就绪不重试，避免一次报错放大成多轮空转
  P3-2  收尾（清理搜索面板 + 还原窗口）统一走 finally
  P3-4  发送成功的判定阈值改为可配置（safety.message_diff_threshold）
"""
import random
import threading
import time

from . import logger as logutil
from .config_loader import Config
from .input.human import Human
from .safety import Abort, Guard, SingleInstance
from .vision import Vision
from .wechat.locator import WeChatLocator, rect_tuple
from .wechat.window import WeChatWindow

# 候选行硬上限：搜索面板可见行约 5~7 行，取 3 足够，避免点到「搜索网络结果」/群聊/聊天记录行。
# 2026-09-16 01:36 那次重构曾把这个常量整个删掉，导致 9-18 凌晨三个联系人的「搜索→点击候选」
# 路径全部抛 NameError（搜索路径 100% 不可用）。固定为模块级常量，禁止再移进条件分支内定义。
CANDIDATE_LIMIT = 3

# 程序缺陷类异常：重试不能自愈，只会把一次报错放大成 N 轮空转 + 反复抢前台。
_NO_RETRY_ERRORS = (
    NameError,
    AttributeError,
    ImportError,
    SyntaxError,
    TypeError,
    NotImplementedError,
)

# 环境未就绪类：重试同样无意义（微信没登录、找不到窗口、缺参考图、校准失效）。
_ENV_NOT_READY_HINTS = (
    "登录窗口",
    "未登录",
    "微信窗口未",
    "找不到微信",
    "参考图",
    "图像模块不可用",
    "校准",
)

# 发送成功的判据：消息区变化比例下限，可在 config.yaml 的 safety.message_diff_threshold 覆盖
DEFAULT_DIFF_THRESHOLD = 0.005


class Sender:
    def __init__(self, cfg: Config, logger):
        self.cfg = cfg
        self.logger = logger
        # 进程内互斥：文件锁在同一 pid 内会放行（app.py 与 Sender 同进程），挡不住
        # 「网页立即发送」与「定时任务」两条线程同时驱动键鼠 → 这里补一道线程级闸门。
        self._gate = threading.Lock()

    # ---------- 对外入口 ----------
    def run_once(self, target: dict, dry_run: bool = None) -> dict:
        name = target.get("name", "?")
        result = {"target": name, "status": "failed", "detail": "", "snapshots": []}

        lock = SingleInstance(self.cfg.root)
        if not lock.acquire():
            self.logger.warning("已有任务正在运行，本次跳过")
            result.update(status="skipped", detail="已有任务正在运行")
            return result

        if not self._gate.acquire(blocking=False):
            self.logger.warning(f"[{name}] 已有发送任务正在执行（进程内互斥），本次跳过")
            result.update(status="skipped", detail="已有发送任务正在执行，本次跳过")
            lock.release()
            return result

        max_retry = int(self.cfg.safety.get("max_retry", 2))
        try:
            for attempt in range(max_retry + 1):
                try:
                    return self._attempt(target, dry_run)
                except Abort as exc:
                    self.logger.error(f"[{name}] 主动中止：{exc}")
                    result.update(status="aborted", detail=str(exc))
                    return result
                except _NO_RETRY_ERRORS as exc:
                    self.logger.exception(f"[{name}] 程序错误（不重试）：{exc}")
                    result.update(status="failed", detail=f"程序错误（不重试）：{exc}")
                    return result
                except Exception as exc:
                    self.logger.exception(f"[{name}] 第 {attempt + 1} 次执行失败：{exc}")
                    # 幂等保护：消息确已发出（mark_sent 已写状态），只是收尾阶段抛错 → 绝不重发
                    if self.cfg.already_sent(name, 300):
                        self.logger.warning(
                            f"[{name}] 本次已确认发送成功（收尾阶段异常），不再重试以免重复发送"
                        )
                        result.update(status="sent", detail=f"已发送（收尾异常：{exc}）")
                        return result
                    # 环境未就绪（未登录 / 找不到微信 / 缺参考图 / 校准失效）：重试无意义且会反复抢前台
                    if any(hint in str(exc) for hint in _ENV_NOT_READY_HINTS):
                        self.logger.warning(f"[{name}] 环境未就绪，不重试：{exc}")
                        result.update(status="failed", detail=f"环境未就绪（不重试）：{exc}")
                        return result
                    if attempt >= max_retry:
                        result.update(status="failed", detail=str(exc))
                        return result
                    backoff = random.uniform(20, 45)
                    self.logger.info(f"{backoff:.0f} 秒后重试（剩余 {max_retry - attempt} 次）")
                    time.sleep(backoff)
            return result
        finally:
            self._gate.release()
            lock.release()

    # ---------- 单次尝试 ----------
    def _attempt(self, target: dict, dry_run: bool = None) -> dict:
        name = target["name"]
        safety = self.cfg.safety
        forced_dry = safety.get("dry_run", True)
        is_dry = forced_dry if dry_run is None else (dry_run or forced_dry)
        if not target.get("approved", False):
            is_dry = True

        result = {"target": name, "status": "failed", "detail": "", "snapshots": []}
        human = Human(self.cfg.behavior)
        guard = Guard(self.cfg.root, safety.get("kill_switch_file", "STOP"), True)
        vision = None
        try:
            vision = Vision(self.cfg.root, self.logger)
        except Exception as exc:
            self.logger.error(f"图像模块不可用（{exc}），无法校验联系人，终止")
            raise Abort(f"图像模块不可用：{exc}")

        # 运行期上下文：guard_check 也用它检测“窗口被拖动/缩放导致坐标失效”
        ctx = {"window": None, "rect": None}

        def guard_check(stage):
            if guard.kill_triggered():
                raise Abort(f"检测到急停文件，中止于「{stage}」")
            if safety.get("abort_on_user_input", True) and human.user_moved_mouse():
                raise Abort(f"检测到用户移动鼠标，为避免干扰中止于「{stage}」")
            win, ref_rect = ctx["window"], ctx["rect"]
            if win and ref_rect and win.rect_moved(ref_rect, win.snapshot_rect()):
                raise Abort(
                    f"微信窗口在执行过程中被移动或缩放（「{stage}」），坐标定位已失效，本次中止"
                )

        if safety.get("abort_on_user_input", True) and guard.user_active():
            raise Abort("检测到用户正在使用键鼠，本次跳过")

        # 1. 唤醒微信
        window = WeChatWindow(self.cfg.wechat, self.logger)
        window.ensure_running()
        guard_check("唤醒微信")
        window.activate()
        human.sleep(0.4)

        rect = rect_tuple(window.control)
        ctx["window"], ctx["rect"] = window, rect
        locator = WeChatLocator(
            rect, human, self.logger, vision, self.cfg.wechat, safety.get("verify_mode", "strict")
        )

        # P0-2：必须在任何分支之前初始化。历史事故：微信恰好停在与目标联系人的会话页时，
        # 下面「已在会话中 → 跳过搜索」的分支不会赋值 results_before，而收尾仍要使用它，
        # 于是发送成功后抛 UnboundLocalError → 被判失败并重试 → 同一条消息真实发送两次。
        results_before = None
        snapshots = result["snapshots"]
        try:
            if safety.get("snapshot", True):
                snapshots.append(logutil.snapshot(self.cfg.root, f"{name}_before"))

            # 正式发送但参考图缺失 → 一个候选行都不点，直接中止。
            # （有参考图才能确认找对人；缺图说明从未演练捕获过，点了也只会白白打开
            #   群聊/兜底行——2026-09-16 误发事故的教训）
            if not is_dry and not vision.has_ref(name):
                raise Abort(
                    f"缺少「{name}」的标题参考图：请先用演练模式跑一次捕获参考图"
                    "（本次未点击任何候选行）"
                )

            # 2. 搜索目标联系人（已在该会话页则直接跳过，杜绝已跳转仍继续搜索点击）
            ok, band = False, locator.band("title_band")
            if vision.has_ref(name) and vision.compare_ref(name, band):
                self.logger.info(f"当前已在与「{name}」的会话中，跳过搜索与点击")
                ok = True

            if not ok:
                # 2. 搜索目标联系人
                overlays_before = window.overlay_snapshot()
                results_before = locator.grab_results_area()
                locator.open_search()
                guard_check("打开搜索")
                locator.type_query(name)
                locator.wait_results()
                guard_check("搜索联系人")

                # 关键安全闸门：搜索没生效就绝不继续（否则输入的文字可能落进当前会话）
                if not locator.results_appeared(results_before, locator.grab_results_area()):
                    raise Abort(
                        "搜索结果区没有出现候选列表，判定搜索未生效，已中止且未做任何点击。"
                        "请检查 wechat.layout.search_box 是否需要重新校准"
                        "（python tools/calibrate.py），必要时人工清理输入框残留文字"
                    )
                self.logger.info(f"搜索已生效，候选列表已出现：{name}")
                locator.scroll_results_to_top()

                # 逐个尝试候选行：微信 4.x 面板第一行可能是「搜索网络结果」（点击会开内置浏览器），
                # 所以刻意不按回车，改为点击“带彩色头像”的候选行，并用标题参考图确认是否找对人。
                # find_contact_rows 内部已把「纯联系人行」（单行名字）排在最前，
                # 群聊/聊天记录行（名字下带“包含:…”副标题/摘要）只作兜底。
                candidates = locator.find_contact_rows()[:CANDIDATE_LIMIT]
                for index, row in enumerate(candidates, start=1):
                    guard_check("选择搜索结果")
                    pos = locator.click_row(row)
                    self.logger.info(f"已点击第 {index} 个候选行 {pos}，正在核对会话标题")
                    # 首跑捕获参考图必须同时满足：演练模式 + 第一个候选 + 该行是“纯联系人行”。
                    # 最后一条是 2026-09-12 事故的教训：当时把群聊「闲鱼教程 (8)」的标题
                    # 存成了参考图，之后每次比对都“相似度 1.000”假阳性通过。
                    allow_capture = is_dry and index == 1 and locator.row_is_contact(0)
                    if is_dry and index == 1 and not locator.row_is_contact(0):
                        self.logger.warning(
                            "第 1 个候选行不是纯联系人行（疑似群聊/记录行），本次不捕获参考图，"
                            "避免把错误会话标题存成身份参考图"
                        )
                    ok, band = locator.verify_conversation(name, allow_capture=allow_capture)
                    if ok:
                        self.logger.info(f"已定位到联系人：{name}（第 {index} 个候选行）")
                        break
                    self.logger.warning(f"第 {index} 个候选行不是「{name}」，继续尝试下一个")
                    closed = window.close_new_overlays(overlays_before)
                    if closed:
                        self.logger.info(f"已关闭微信弹出的 {len(closed)} 个内置窗口")
                        time.sleep(0.8)
                        window.activate()
                    locator.open_search()
                    locator.type_query(name)
                    locator.wait_results()
                    # 重开搜索必须重新过闸门：结果区没变化就中止，绝不能拿旧坐标继续点
                    if not locator.results_appeared(results_before, locator.grab_results_area()):
                        raise Abort(f"第 {index} 个候选行失败后重开搜索未生效，已中止（未继续点击）")
                    locator.scroll_results_to_top()

            if not ok:
                if safety.get("snapshot", True):
                    snapshots.append(logutil.snapshot(self.cfg.root, f"{name}_verify_failed", band))
                raise Abort(f"未能确认已打开与「{name}」的会话，出于安全考虑不发送")

            # P2-3：拒绝发送空消息。模板全为变量或 messages 缺失时渲染结果可能为空串，
            # 继续往下就是「在输入框里空按一次回车」，行为不可控。
            message = (self.cfg.pick_message(target) or "").strip()
            if not message:
                raise Abort(
                    f"「{name}」的消息模板渲染结果为空，已拒绝发送空消息"
                    "（请检查 config.yaml 里该联系人的 messages）"
                )
            before = locator.grab_message_area()

            # 3. 演练模式到此为止
            if is_dry:
                if safety.get("snapshot", True):
                    shot = logutil.snapshot(self.cfg.root, f"{name}_dryrun", band)
                    if shot:
                        snapshots.append(shot)
                self.logger.info("【演练模式】不会真正发送。预览消息：" + message)
                result.update(status="dry_run", detail=message)
                return result

            # 4. 正式发送
            locator.focus_input()
            guard_check("定位输入框")
            human.type_text(message)
            guard_check("输入消息")
            human.press("enter")
            time.sleep(random.uniform(1.5, 2.8))

            # 5. 发送后复核：消息区是否发生变化
            after = locator.grab_message_area()
            shot = ""
            if safety.get("snapshot", True):
                shot = logutil.snapshot(self.cfg.root, f"{name}_after")
                snapshots.append(shot)
            threshold = float(
                safety.get("message_diff_threshold", DEFAULT_DIFF_THRESHOLD) or DEFAULT_DIFF_THRESHOLD
            )
            ratio = Vision.diff_ratio(before, after)
            if ratio >= threshold:
                self.cfg.mark_sent(name)
                self.logger.info(f"[{name}] 发送完成，消息区变化 {ratio:.2%}：{message}")
                result.update(status="sent", detail=message)
            else:
                self.logger.warning(
                    f"[{name}] 已执行发送，但消息区几乎无变化（{ratio:.2%}，阈值 {threshold:.2%}），"
                    f"请人工核对截图：{shot}"
                )
                result.update(status="unverified", detail=message)
            return result
        finally:
            # P3-2：任何异常路径都保证收尾——清理搜索面板残留 + 还原窗口状态 + 还原剪贴板。
            # 收尾自身出错不允许覆盖原始异常，只记 debug。
            try:
                human.restore_clipboard()
            except Exception:
                self.logger.debug("收尾：还原剪贴板失败（已忽略）", exc_info=True)
            try:
                locator.clear_search(results_before)
            except Exception:
                self.logger.debug("收尾：清理搜索面板失败（已忽略）", exc_info=True)
            try:
                window.restore()
            except Exception:
                self.logger.debug("收尾：还原窗口失败（已忽略）", exc_info=True)
