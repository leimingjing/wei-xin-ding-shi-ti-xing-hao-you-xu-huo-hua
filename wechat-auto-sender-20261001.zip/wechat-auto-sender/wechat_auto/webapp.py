# -*- coding: utf-8 -*-
"""本地网页控制台：把管理员工作台搬到浏览器里。

原则：
- 只监听 127.0.0.1，不对外网暴露；
- 只做「展示 + 触发既有动作」，绝不绕过安全闸门：
  dry_run / approved / 参考图校验 / 急停 STOP 文件全部沿用原逻辑；
- 零第三方依赖：标准库 http.server，联系人校验复用 workbench.contacts。

启动方式：
- 随 app.py 常驻启动（默认），自动打开 http://127.0.0.1:8788
- 独立运行（只管理联系人 + 只读状态，不接管调度）：
    python wechat_auto/webapp.py --port 8899
"""
from __future__ import annotations

import argparse
import json
import os
import re
import runpy
import sys
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "workbench"))

import contacts as contacts_mod  # noqa: E402  （workbench 数据层：校验与持久化）
from wechat_auto import config_editor  # noqa: E402
from wechat_auto.vision import ref_path_for  # noqa: E402  （参考图路径唯一权威实现，P2-2）

WEEKDAY_CN = {1: "周一", 2: "周二", 3: "周三", 4: "周四", 5: "周五", 6: "周六", 7: "周日"}
DEFAULT_PORT = 8788
TIME_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")


class WebConsole:
    """网页控制台核心：路由 + 数据组装。Handler 只做 IO 薄壳。"""

    def __init__(self, root, store, cfg=None, controller=None, run_now=None, logger=None,
                 on_config_change=None, settings=None):
        self.root = root
        self.store = store
        self.cfg = cfg                    # Config 实例（可为 None，仅独立演示模式）
        self.controller = controller      # TaskController（可为 None）
        self.run_now_cb = run_now         # fn(real: bool)，由 app.py 注入
        self.logger = logger
        self.on_config_change = on_config_change  # fn()：config.yaml 变更后重建调度
        self.settings = settings          # wechat_auto.settings.Settings（桌面客户端注入，可为 None）
        self.lock = threading.RLock()
        self.port = None
        self.server = None
        self.started_at = time.time()
        # 最近一次从网页触发的动作，供概览页展示
        self.last_action = None
        # 校准任务状态
        self.calibrating = False
        self.calibrate_done_at = ""
        # 发送任务运行态：网页连点 / 与定时任务撞车时直接拒绝（P2-4）
        self.running = False
        # 自动识别（contact_resolve）的进程内互斥，懒初始化
        self._resolve_lock = None

    # ---------- 生命周期 ----------
    def start(self, port: int = DEFAULT_PORT, open_browser: bool = False) -> int:
        handler = _make_handler(self)
        for candidate in range(port, port + 20):
            try:
                self.server = ThreadingHTTPServer(("127.0.0.1", candidate), handler)
                self.port = candidate
                break
            except OSError:
                continue
        if self.server is None:
            raise RuntimeError(f"端口 {port}~{port + 19} 均被占用，网页控制台启动失败")
        threading.Thread(target=self.server.serve_forever, daemon=True, name="webconsole").start()
        if open_browser:
            self.open_browser()
        return self.port

    def stop(self):
        if self.server:
            try:
                self.server.shutdown()
            except Exception:
                pass

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port or DEFAULT_PORT}"

    def open_browser(self):
        try:
            webbrowser.open(self.url)
        except Exception:
            pass

    # ---------- 数据组装 ----------
    def _ref_path(self, name: str) -> str:
        # 与 vision / 自检共用同一套文件名消毒规则，杜绝"预览说有图、发送说没图"的分叉（P2-2）
        return ref_path_for(self.root, name)

    def _kill_path(self) -> str:
        filename = "STOP"
        if self.cfg is not None:
            try:
                filename = self.cfg.safety.get("kill_switch_file") or "STOP"
            except Exception:
                pass
        return os.path.join(self.root, filename)

    def _lock_pid(self):
        path = os.path.join(self.root, "logs", "wechat_auto.lock")
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return int(fh.read().strip() or 0)
        except Exception:
            return 0

    def overview(self) -> dict:
        with self.lock:
            self.store.load()
        cfg = self.cfg
        if cfg is not None:
            try:
                cfg.reload()
            except Exception:
                pass

        dry_run = bool(cfg.safety.get("dry_run", True)) if cfg else True
        paused = None
        next_run = ""
        upcoming = []
        if self.controller is not None:
            paused = self.controller.paused
            next_run = self.controller.next_run()
            try:
                upcoming = self.controller.upcoming()
            except Exception as exc:
                if self.logger:
                    self.logger.warning(f"[网页] 读取计划任务列表失败：{exc}")

        targets = []
        if cfg is not None:
            for i, t in enumerate(cfg.data.get("targets", []), start=1):
                name = t.get("name", "")
                targets.append({
                    "index": i,          # 与 /api/targets 的编号一致，供前端直达批准弹窗
                    "name": name,
                    "enabled": bool(t.get("enabled")),
                    "approved": bool(t.get("approved")),
                    "has_ref": os.path.exists(self._ref_path(name)),
                    "times": [str(x) for x in (t.get("times") or cfg.schedule.get("times") or [])],
                    "messages": [m for m in t.get("messages", []) if m],
                })

        schedule = {"times": [], "weekdays": [1, 2, 3, 4, 5, 6, 7], "jitter_minutes": 3}
        if cfg is not None:
            schedule = {
                "times": [str(x) for x in cfg.schedule.get("times", [])],
                "weekdays": list(cfg.schedule.get("weekdays", [1, 2, 3, 4, 5, 6, 7])),
                "jitter_minutes": int(cfg.schedule.get("jitter_minutes", 3)),
            }

        # P2-5：把「校准时所处的窗口尺寸」一并回显——换显示器 / 改缩放后一眼能看出是否需要重跑校准
        baseline = {}
        if cfg is not None:
            try:
                baseline = dict(cfg.wechat.get("window_baseline") or {})
            except Exception:
                baseline = {}
            if baseline:
                baseline["summary"] = (
                    f"{baseline.get('width', '?')}x{baseline.get('height', '?')}"
                    + (f" / 缩放 {baseline.get('scale')}%" if baseline.get("scale") else "")
                )

        kill_active = os.path.exists(self._kill_path())
        return {
            "window_baseline": baseline,      # 校准基准窗口（P2-5）
            "connected": self.controller is not None,   # 是否接管了常驻调度
            "paused": paused,
            "dry_run": dry_run,
            "verify_mode": (cfg.safety.get("verify_mode", "strict") if cfg else "strict"),
            "next_run": next_run,
            "upcoming": upcoming,
            "kill_active": kill_active,
            "lock_pid": self._lock_pid(),
            "contacts_count": len(self.store),
            "load_error": self.store.load_error,
            "targets": targets,
            "schedule": schedule,
            "last_action": self.last_action,
            "uptime": int(time.time() - self.started_at),
            "url": self.url,
        }

    # ---------- 联系人 ----------
    def contacts(self) -> dict:
        with self.lock:
            self.store.load()
            rows = [dict(c, index=i) for i, c in enumerate(self.store.contacts, start=1)]
        return {"contacts": rows, "count": len(rows), "load_error": self.store.load_error}

    def contact_add(self, body: dict):
        with self.lock:
            self.store.load()
            record = self.store.add(
                str(body.get("name", "")), str(body.get("contact", "")), str(body.get("datetime", ""))
            )
        if self.logger:
            self.logger.info(f"[网页] 新增联系人 {record['name']}")
        return record

    # ---------- 自动识别（按昵称在微信里查找） ----------
    def contact_resolve(self, body: dict) -> dict:
        """在已登录的微信窗口里按昵称/备注名查找联系人。

        仅查找 + 保存参考图，不修改任何持久化数据。
        """
        name = str(body.get("name", "")).strip()
        allow_save = bool(body.get("allow_save_ref", True))
        cfg = self._require_cfg()
        # 防止网页多次同时触发（共享一个进程、共享一份微信窗口）
        if not hasattr(self, "_resolve_lock") or self._resolve_lock is None:
            self._resolve_lock = threading.Lock()
        if not self._resolve_lock.acquire(blocking=False):
            raise PermissionError("已有一次自动识别正在进行，请先等它完成")
        try:
            from wechat_auto.wechat.resolver import ContactResolver, ResolveError
            resolver = ContactResolver(cfg, self.logger)
            try:
                result = resolver.resolve(name, allow_save_ref=allow_save)
            except ResolveError as exc:
                if self.logger:
                    self.logger.warning(f"[网页] 自动识别失败：{exc.code} - {exc.message}")
                raise
            if self.logger:
                self.logger.info(
                    f"[网页] 自动识别成功：{result.matched_name}（检查 {result.checked_rows}/{result.total_rows} 行）"
                    + ("，参考图已新建" if result.ref_saved else "，复用既有参考图")
                )
            # 参考图文件名做了字符消毒（空格/斜杠等会变下划线），URL 必须用消毒后的名字
            ref_file = re.sub(r'[\\/:*?"<>|\s]+', "_", result.matched_name)
            return {
                "matched_name": result.matched_name,
                "ref_saved": result.ref_saved,
                "had_ref_before": result.had_ref_before,
                "verify_score": result.verify_score,
                "checked_rows": result.checked_rows,
                "total_rows": result.total_rows,
                "ref_url": f"/files/refs/{urllib.parse.quote(ref_file)}.png",
                "need_confirm": result.ref_saved,   # 首跑新建参考图，需要用户肉眼确认
            }
        finally:
            self._resolve_lock.release()

    def contact_discard_ref(self, body: dict) -> dict:
        """丢弃「首次识别」新建的参考图（用户没确认就关掉了表单时调用）。

        安全约束：
        - 只删除 assets/refs/<消毒后名字>.png；
        - 若该名字正在被 config.yaml 的 targets 使用，则拒绝删除（保护正式配置）。
        """
        name = str(body.get("name", "")).strip()
        if not name:
            raise contacts_mod.ValidationError("缺少联系人名字")
        cfg = self._require_cfg()
        in_use = {str(t.get("name", "")).strip() for t in (cfg.data.get("targets") or [])}
        if name in in_use:
            raise PermissionError(f"「{name}」正在被发送目标使用，不能删除其参考图")
        path = self._ref_path(name)
        removed = False
        if os.path.isfile(path):
            try:
                os.remove(path)
                removed = True
            except OSError as exc:
                raise PermissionError(f"参考图删除失败：{exc}") from None
        if self.logger:
            self.logger.info(f"[网页] 已丢弃未确认的参考图：{name}" + ("" if removed else "（文件不存在，跳过）"))
        return {"name": name, "removed": removed}

    def contact_update(self, index: int, body: dict):
        renamed = None  # (old, new)：联系人改名后需要同步关联的发送目标
        with self.lock:
            self.store.load()
            if not 1 <= index <= len(self.store.contacts):
                raise contacts_mod.ValidationError(f"编号 {index} 不存在（当前共 {len(self.store)} 条）")
            # 先整体校验，避免改到一半才报错
            for field in ("name", "contact", "datetime"):
                if field in body:
                    contacts_mod.validate_field(field, str(body[field]))
            record = self.store.get(index)
            old_name = record["name"]  # store.get 返回的是引用，update 会原地改名，必须先留快照
            for field in ("name", "contact", "datetime"):
                if field in body:
                    self.store.update(index, field, str(body[field]))
            new_rec = self.store.get(index)
            if "name" in body and new_rec["name"] != old_name:
                renamed = (old_name, new_rec["name"], new_rec.get("id", ""))
        if renamed:
            self._sync_linked_target_names(*renamed)
        if self.logger:
            self.logger.info(f"[网页] 更新联系人 {record['name']}")
        return record

    def _sync_linked_target_names(self, old_name: str, new_name: str, cid: str):
        """联系人改名 → 关联它的发送目标自动改名（两处数据保持一致）。

        复用 target_update 的参考图提醒口径：旧参考图不再匹配时记日志，要求重新演练。
        """
        if not cid or not self.cfg:
            return
        try:
            self.cfg.reload()
            targets = self._raw_targets()
            hit = False
            for t in targets:
                if str(t.get("contact_id") or "").strip() == cid:
                    old_t = t.get("name")
                    t["name"] = new_name
                    hit = True
                    if old_t != new_name and os.path.exists(self._ref_path(old_t)) \
                            and not os.path.exists(self._ref_path(new_name)) and self.logger:
                        self.logger.warning(
                            f"[网页] 联系人改名同步：发送目标 {old_t} → {new_name}，"
                            "旧参考图不再匹配，需重新演练生成")
            if hit:
                self._save_targets(targets, f"联系人改名自动同步发送目标 {old_name} → {new_name}")
        except Exception as exc:  # 同步失败不回滚联系人改名，但要说出问题
            if self.logger:
                self.logger.error(f"[网页] 联系人改名同步发送目标失败：{exc}（请到发送任务页手动改名）")

    def contact_delete(self, index: int):
        with self.lock:
            self.store.load()
            if not 1 <= index <= len(self.store.contacts):
                raise contacts_mod.ValidationError(f"编号 {index} 不存在（当前共 {len(self.store)} 条）")
            record = self.store.get(index)
            # 关联保护：还有发送目标挂着这个联系人时，先解除关联才能删（防误删导致任务悬空）
            if self.cfg is not None:
                self.cfg.reload()
                cid = str(record.get("id") or "")
                linked = [t.get("name", "?") for t in (self.cfg.data.get("targets") or [])
                          if str(t.get("contact_id") or "").strip() == cid]
                if linked:
                    raise PermissionError(
                        f"联系人「{record['name']}」正被发送任务关联（{', '.join(linked)}），"
                        "请先到「发送任务」编辑该目标并解除关联，再回来删除")
            record = self.store.remove(index)
        if self.logger:
            self.logger.info(f"[网页] 删除联系人 {record['name']}")
        return record

    # ---------- 配置与发送目标（config.yaml） ----------
    def _require_cfg(self):
        if self.cfg is None:
            raise PermissionError("当前为独立浏览模式，不能修改发送配置——请启动主程序")
        return self.cfg

    def _notify_config_change(self, what: str):
        if self.logger:
            self.logger.info(f"[网页] 配置已更新：{what}")
        self.last_action = {"time": time.strftime("%H:%M:%S"), "text": f"配置已更新：{what}"}
        if self.on_config_change:
            try:
                self.on_config_change()
            except Exception as exc:
                if self.logger:
                    self.logger.error(f"[网页] 重建调度失败：{exc}")

    @staticmethod
    def _check_times(values) -> list:
        if not isinstance(values, list):
            raise contacts_mod.ValidationError("时间点必须是列表")
        out = []
        for v in values:
            text = str(v).strip()
            if not TIME_RE.match(text):
                raise contacts_mod.ValidationError(f"时间点 {text!r} 无效，应为 HH:MM（如 08:30）")
            hh, mm = text.split(":")
            out.append(f"{int(hh):02d}:{mm}")
        return out

    @staticmethod
    def _check_weekdays(values) -> list:
        if not isinstance(values, list):
            raise contacts_mod.ValidationError("生效星期必须是列表")
        out = []
        for v in values:
            try:
                d = int(v)
            except (TypeError, ValueError):
                raise contacts_mod.ValidationError(f"星期 {v!r} 无效，应为 1~7") from None
            if not 1 <= d <= 7:
                raise contacts_mod.ValidationError("星期取值 1=周一 … 7=周日")
            if d not in out:
                out.append(d)
        return sorted(out) or [1, 2, 3, 4, 5, 6, 7]

    def config_view(self) -> dict:
        cfg = self._require_cfg()
        cfg.reload()
        return {
            "path": cfg.path,
            "schedule": {
                "times": [str(x) for x in cfg.schedule.get("times", [])],
                "weekdays": list(cfg.schedule.get("weekdays", [1, 2, 3, 4, 5, 6, 7])),
                "jitter_minutes": int(cfg.schedule.get("jitter_minutes", 3)),
            },
            "safety": {
                "dry_run": bool(cfg.safety.get("dry_run", True)),
                "verify_mode": cfg.safety.get("verify_mode", "strict"),
            },
        }

    def config_update_schedule(self, body: dict) -> dict:
        cfg = self._require_cfg()
        times = self._check_times(body.get("times", []))
        if not times:
            raise contacts_mod.ValidationError("至少需要一个发送时间点")
        weekdays = self._check_weekdays(body.get("weekdays", [1, 2, 3, 4, 5, 6, 7]))
        try:
            jitter = int(body.get("jitter_minutes", 3))
        except (TypeError, ValueError):
            raise contacts_mod.ValidationError("随机抖动应为 0~30 的分钟数") from None
        if not 0 <= jitter <= 30:
            raise contacts_mod.ValidationError("随机抖动应为 0~30 的分钟数")

        def verify(data):
            sched = data.get("schedule") or {}
            if not sched.get("times"):
                raise config_editor.ConfigEditError("校验失败：schedule.times 为空")

        changed = config_editor.edit_config(
            cfg.path,
            lambda t: config_editor.set_scalar(
                config_editor.set_scalar(
                    config_editor.set_block_list(t, "schedule", "times", times),
                    "schedule", "weekdays", weekdays),
                "schedule", "jitter_minutes", jitter),
            verify,
        )
        if changed:
            self._notify_config_change(
                f"调度 → {len(times)} 个时间点 / {len(weekdays)} 个生效日 / 抖动 {jitter} 分钟"
            )
        return self.config_view()

    def config_update_safety(self, body: dict) -> dict:
        cfg = self._require_cfg()
        dry_run = bool(body.get("dry_run"))
        if not dry_run and str(body.get("confirm", "")).strip() != "正式发送":
            raise PermissionError("切换到正式发送模式需要输入确认词「正式发送」")

        def verify(data):
            if "dry_run" not in (data.get("safety") or {}):
                raise config_editor.ConfigEditError("校验失败：safety.dry_run 缺失")

        changed = config_editor.edit_config(
            cfg.path,
            lambda t: config_editor.set_scalar(t, "safety", "dry_run", dry_run),
            verify,
        )
        if changed:
            mode = "正式发送" if not dry_run else "演练（安全）"
            self._notify_config_change(f"发送模式 → {mode}")
            if self.logger and not dry_run:
                self.logger.warning("[网页] 已解除 dry_run 保险：此后定时任务将真实发送")
        return self.config_view()

    # ----- targets -----
    def _raw_targets(self) -> list:
        return list(self.cfg.data.get("targets") or [])

    def targets_list(self) -> dict:
        cfg = self._require_cfg()
        cfg.reload()
        rows = []
        for i, t in enumerate(self._raw_targets(), start=1):
            rows.append(self._target_view(i, t))
        return {"targets": rows, "count": len(rows)}

    def _find_contact(self, cid: str):
        """按稳定 id 查联系人；没有则 None（实时重读 contacts.json，跨页签改动即时可见）。"""
        with self.lock:
            self.store.load()
            return self.store.find_by_id(cid)

    def _target_view(self, index: int, t: dict) -> dict:
        name = t.get("name", "")
        cid = str(t.get("contact_id") or "").strip()
        c = self._find_contact(cid) if cid else None
        return {
            "index": index,
            "name": name,
            "enabled": bool(t.get("enabled")),
            "approved": bool(t.get("approved")),
            "has_ref": os.path.exists(self._ref_path(name)),
            "times": [str(x) for x in (t.get("times") or [])],
            "messages": [m for m in t.get("messages", []) if m],
            # 关联的联系人（来自联系人管理台）：null = 未关联；contact_missing = 配置里有 id 但联系人已不存在
            "contact_id": cid or None,
            "contact_missing": bool(cid and not c),
            "contact": None if not c else {
                "id": c.get("id", ""),
                "name": c.get("name", ""),
                "contact": c.get("contact", ""),
                "contact_type": c.get("contact_type", ""),
                "datetime": c.get("datetime", ""),
            },
        }

    def _save_targets(self, targets: list, what: str):
        cfg = self._require_cfg()

        def verify(data):
            names = [t.get("name") for t in (data.get("targets") or [])]
            if len(names) != len(set(names)):
                raise config_editor.ConfigEditError("校验失败：存在重名联系人")
            for t in data.get("targets") or []:
                if not t.get("messages"):
                    raise config_editor.ConfigEditError(f"校验失败：{t.get('name')} 缺少消息模板")
                # 关联外键必须是真实存在的联系人：防止手改配置留下悬空 id
                cid = str(t.get("contact_id") or "").strip()
                if cid and not self._find_contact(cid):
                    raise config_editor.ConfigEditError(
                        f"校验失败：{t.get('name')} 关联的联系人（{cid}）不存在")

        changed = config_editor.edit_config(
            cfg.path, lambda t: config_editor.replace_targets(t, targets), verify)
        if changed:
            self._notify_config_change(what)

    def _check_target_body(self, body: dict, partial=False):
        out = {}
        if "name" in body or not partial:
            name = str(body.get("name", "")).strip()
            if not name:
                raise contacts_mod.ValidationError("姓名（微信备注名）不能为空")
            if len(name) > 30:
                raise contacts_mod.ValidationError("姓名过长，最多 30 个字符")
            out["name"] = name
        # 关联联系人："" / null = 解除关联；关联后姓名强制取联系人姓名，保证两处一致
        if "contact_id" in body or not partial:
            cid = str(body.get("contact_id") or "").strip()
            if cid:
                c = self._find_contact(cid)
                if not c:
                    raise contacts_mod.ValidationError("关联的联系人不存在，请刷新联系人列表后重试")
                if "name" in out and out["name"] != c.get("name", ""):
                    raise contacts_mod.ValidationError(
                        f"已关联联系人「{c.get('name', '')}」：姓名自动与联系人保持一致，"
                        "如需改名请先解除关联（或到联系人页改名，会自动同步过来）")
                out["name"] = c.get("name", out.get("name", ""))
                out["contact_id"] = cid
            else:
                out["contact_id"] = ""
        if "times" in body or not partial:
            out["times"] = WebConsole._check_times(body.get("times") or [])
        if "messages" in body or not partial:
            msgs = [str(m).strip() for m in (body.get("messages") or []) if str(m).strip()]
            if not msgs:
                raise contacts_mod.ValidationError("至少需要一条消息模板")
            for m in msgs:
                if len(m) > 500:
                    raise contacts_mod.ValidationError("单条消息模板不能超过 500 字")
            out["messages"] = msgs
        if "enabled" in body or not partial:
            out["enabled"] = bool(body.get("enabled"))
        return out

    def target_add(self, body: dict):
        cfg = self._require_cfg()
        cfg.reload()
        fields = self._check_target_body(body, partial=False)
        targets = self._raw_targets()
        # 新目标默认未批准：必须演练核对参考图后再手动打开
        entry = {"name": fields["name"], "enabled": fields["enabled"], "approved": False,
                 "times": fields["times"], "messages": fields["messages"]}
        if fields.get("contact_id"):
            entry["contact_id"] = fields["contact_id"]
        targets.append(entry)
        self._save_targets(targets, f"新增发送目标 {fields['name']}"
                                    + (f"（关联联系人 {fields['contact_id']}）" if fields.get("contact_id") else ""))
        cfg.reload()
        return self._target_view(len(self._raw_targets()), self._raw_targets()[-1])

    def target_update(self, index: int, body: dict):
        cfg = self._require_cfg()
        cfg.reload()
        targets = self._raw_targets()
        if not 1 <= index <= len(targets):
            raise contacts_mod.ValidationError(f"目标编号 {index} 不存在（当前共 {len(targets)} 个）")
        fields = self._check_target_body(body, partial=True)
        # contact_id 特殊处理：空串 = 解除关联（从配置里删掉这个键，而不是留下空值）
        if "contact_id" in fields:
            cid = fields.pop("contact_id")
            if cid:
                targets[index - 1]["contact_id"] = cid
            else:
                targets[index - 1].pop("contact_id", None)
        # 改名会让旧参考图失效：提醒而不是静默
        old_name = targets[index - 1].get("name")
        targets[index - 1].update(fields)
        if "name" in fields and fields["name"] != old_name:
            if os.path.exists(self._ref_path(old_name)) and not os.path.exists(self._ref_path(fields["name"])):
                if self.logger:
                    self.logger.warning(
                        f"[网页] 目标改名 {old_name} → {fields['name']}：旧参考图不再匹配，需重新演练生成")
        what = f"更新发送目标 {targets[index - 1]['name']}"
        if "contact_id" in body:
            what += "（已更新关联联系人）" if str(body.get("contact_id") or "").strip() else "（已解除关联联系人）"
        self._save_targets(targets, what)
        cfg.reload()
        return self._target_view(index, self._raw_targets()[index - 1])

    def target_gate(self, index: int, body: dict):
        """approved 闸门：打开需要确认词，关闭随时可以。"""
        cfg = self._require_cfg()
        cfg.reload()
        approved = bool(body.get("approved"))
        if approved and str(body.get("confirm", "")).strip() != "我已核对参考图":
            raise PermissionError("打开批准闸门需要输入确认词「我已核对参考图」")
        if approved:
            name = (self._raw_targets()[index - 1] if 1 <= index <= len(self._raw_targets()) else {}).get("name", "")
            if not os.path.exists(self._ref_path(name)):
                raise PermissionError(
                    f"{name} 还没有参考图（先「立即演练一次」生成并人工核对），不能批准")
        targets = self._raw_targets()
        if not 1 <= index <= len(targets):
            raise contacts_mod.ValidationError(f"目标编号 {index} 不存在")
        targets[index - 1]["approved"] = approved
        name = targets[index - 1]["name"]
        self._save_targets(targets, f"{name} 批准闸门 → {'已批准' if approved else '未批准'}")
        if self.logger and approved:
            self.logger.warning(f"[网页] {name} 已批准：满足条件时将真实发送")
        cfg.reload()
        return self._target_view(index, self._raw_targets()[index - 1])

    def target_delete(self, index: int):
        cfg = self._require_cfg()
        cfg.reload()
        targets = self._raw_targets()
        if not 1 <= index <= len(targets):
            raise contacts_mod.ValidationError(f"目标编号 {index} 不存在")
        name = targets.pop(index - 1)["name"]
        self._save_targets(targets, f"删除发送目标 {name}")
        cfg.reload()
        return {"deleted": name}

    # ---------- 校准 ----------
    def calibrate_start(self) -> dict:
        if self.calibrating:
            raise PermissionError("校准正在进行中，请等它跑完")
        script = os.path.join(self.root, "tools", "calibrate.py")
        if not os.path.exists(script):
            raise FileNotFoundError(
                "tools/calibrate.py 不存在——重新打包客户端即可恢复"
            )
        self.calibrating = True
        if self.logger:
            self.logger.info("[网页] 已触发位置校准（会短暂激活微信窗口，只截图不发送）")

        def worker():
            # P1-3：打包后 sys.executable 指向「微信定时发送.exe」本身，原实现
            # subprocess.run([sys.executable, script]) 等价于"再启动一个客户端实例"，
            # calibrate.py 根本不会被执行（点「重新校准」只会看到一句"已完成"）。
            # 改用 runpy 在当前进程内按脚本执行，源码运行与打包运行同一条路径。
            argv_backup = sys.argv
            sys.argv = [script]
            try:
                runpy.run_path(script, run_name="__main__")
            except SystemExit as exc:
                if exc.code not in (0, None) and self.logger:
                    self.logger.warning(f"[网页] 校准脚本以退出码 {exc.code} 结束")
            except Exception as exc:
                if self.logger:
                    self.logger.error(f"[网页] 校准执行失败：{exc}")
            finally:
                sys.argv = argv_backup
                self.calibrating = False
                self.calibrate_done_at = time.strftime("%H:%M:%S")
                if self.logger:
                    self.logger.info("[网页] 校准完成，结果图在 logs/calibrate.png")

        threading.Thread(target=worker, daemon=True, name="web-calibrate").start()
        self.last_action = {"time": time.strftime("%H:%M:%S"), "text": "已触发位置校准"}
        return {"started": True}

    # ---------- 调度控制 ----------
    def toggle_pause(self) -> dict:
        if self.controller is None:
            raise PermissionError("常驻调度未运行（当前为独立浏览模式），暂停/恢复请先启动主程序")
        paused = self.controller.toggle_pause()
        self.last_action = {
            "time": time.strftime("%H:%M:%S"),
            "text": "已暂停定时调度" if paused else "已恢复定时调度",
        }
        return {"paused": paused}

    def trigger_run(self, body: dict) -> dict:
        real = bool(body.get("real"))
        if real and str(body.get("confirm", "")).strip() != "正式发送":
            raise PermissionError("真实发送需要输入确认词「正式发送」")
        if self.run_now_cb is None:
            raise PermissionError("常驻调度未运行（当前为独立浏览模式），请从主程序触发发送")
        if os.path.exists(self._kill_path()):
            raise PermissionError("急停 STOP 文件生效中，请先解除急停再触发")
        # P2-4：网页连点两次、或与定时任务撞车时直接拒绝，而不是排队后并发驱动键鼠
        with self.lock:
            if self.running:
                raise PermissionError("已有发送任务正在执行，请等它跑完再触发")
            self.running = True
        mode = "真实发送" if real else "演练（不发送）"
        self.last_action = {"time": time.strftime("%H:%M:%S"), "text": f"已触发：立即{mode}"}

        def worker():
            try:
                self.run_now_cb(real=real)
            except Exception as exc:  # 后台线程必须自己兜住
                if self.logger:
                    self.logger.error(f"[网页] 触发执行失败：{exc}")
            finally:
                with self.lock:
                    self.running = False

        try:
            threading.Thread(target=worker, daemon=True, name="web-run").start()
        except Exception:
            with self.lock:
                self.running = False
            raise
        return {"started": True, "real": real}

    # ---------- 急停 ----------
    def kill_switch(self, on: bool) -> dict:
        path = self._kill_path()
        if on:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(f"created by web console {time.strftime('%Y-%m-%d %H:%M:%S')}")
            if self.logger:
                self.logger.warning("[网页] 急停已触发：创建 STOP 文件，全部任务停止")
            self.last_action = {"time": time.strftime("%H:%M:%S"), "text": "急停已触发（STOP 文件已创建）"}
        else:
            try:
                os.remove(path)
            except FileNotFoundError:
                pass
            if self.logger:
                self.logger.info("[网页] 急停已解除：STOP 文件已删除")
            self.last_action = {"time": time.strftime("%H:%M:%S"), "text": "急停已解除"}
        return {"kill_active": os.path.exists(path)}

    # ---------- 日志 ----------
    def logs(self, lines: int = 300) -> dict:
        path = os.path.join(self.root, "logs", "run.log")
        rows = []
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    rows = [line.rstrip("\n") for line in fh]
            except OSError:
                pass
        return {"lines": rows[-max(50, min(lines, 1000)):]}

    # ---------- 客户端设置（开机自启 / 关闭行为 / 启动最小化） ----------
    def settings_view(self) -> dict:
        if self.settings is None:
            # 非客户端模式（浏览器/控制台）：只读回默认值，前端禁用开关
            return {"settings": None, "client_mode": False}
        data = self.settings.view()
        data["client_mode"] = True
        return data

    def settings_update(self, body: dict) -> dict:
        if self.settings is None:
            raise PermissionError("设置仅在桌面客户端模式下可用（当前为浏览器控制台模式）")
        if not isinstance(body, dict):
            raise contacts_mod.ValidationError("请求体必须是 JSON 对象")
        with self.lock:
            self.settings.update(body)
        if self.logger and "auto_start" in body:
            self.logger.info(
                f"[网页] 开机自启已{'开启' if self.settings.is_auto_start() else '关闭'}"
                + (f"（注册表写入失败：{self.settings.auto_start_error}）" if self.settings.auto_start_error else ""))
        return self.settings_view()


# ---------- HTTP 层 ----------
def _make_handler(console: WebConsole):
    class Handler(BaseHTTPRequestHandler):
        server_version = "WeChatAutoWeb/1.0"
        protocol_version = "HTTP/1.1"   # 长连接：轮询场景少建 TCP

        # 安静：默认访问日志不打进 stderr
        def log_message(self, fmt, *args):
            pass

        # ----- 请求来源闸门（P1-1）-----
        # 本控制台能触发真实发送、也能急停，属于「有副作用的本地接口」。浏览器里任何
        # 一个恶意网页都能向 127.0.0.1:8788 发 POST（简单请求不触发 CORS 预检），而原实现
        # 连 Origin / Host 都不看——等于把发送按钮开放给全网页面。现在两道闸门：
        #   ① 所有请求：Host 必须是回环地址（挡 DNS rebinding）；Origin 存在时必须是本机控制台
        #   ② 写操作：必须带自定义头 X-Requested-With（跨站表单无法伪造；跨站 fetch 会先发
        #      预检 OPTIONS，而本服务未实现 OPTIONS → 直接 404 阻断）
        ALLOWED_HOSTS = {"127.0.0.1", "localhost", "[::1]"}
        CSRF_HEADER = "X-Requested-With"
        CSRF_VALUE = "wechat-auto-console"

        def _drain_body(self):
            """闸门拦截时丢弃未读请求体，避免 HTTP/1.1 长连接被残留字节打乱。"""
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = 0
            if 0 < length <= 64 * 1024:
                try:
                    self.rfile.read(length)
                except Exception:
                    pass

        def _check_origin(self) -> bool:
            host = (self.headers.get("Host") or "").strip().lower()
            hostname = host.rsplit(":", 1)[0] if ":" in host else host
            if hostname and hostname not in self.ALLOWED_HOSTS:
                self._drain_body()
                self._err("拒绝访问：Host 不是本机回环地址", 403)
                return False
            origin = (self.headers.get("Origin") or "").strip().lower()
            if origin and not origin.startswith(
                ("http://127.0.0.1:", "http://localhost:", "http://[::1]:")
            ):
                self._drain_body()
                self._err("拒绝访问：请求来源不是本机控制台页面（防跨站触发发送）", 403)
                return False
            return True

        def _check_token(self) -> bool:
            if (self.headers.get(self.CSRF_HEADER) or "").strip() != self.CSRF_VALUE:
                self._drain_body()
                self._err("缺少控制台请求标识，已拒绝该写操作（防跨站触发发送）", 403, code="csrf")
                return False
            return True

        # ----- 响应工具 -----
        def _json(self, payload: dict, status: int = 200):
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _ok(self, data=None):
            self._json({"ok": True, "data": data if data is not None else {}})

        def _err(self, message: str, status: int = 400, code: str = "", hint: str = ""):
            payload = {"ok": False, "error": message}
            if code:
                payload["code"] = code
            if hint:
                payload["hint"] = hint
            self._json(payload, status)

        def _body(self) -> dict:
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = 0
            if length <= 0 or length > 64 * 1024:
                return {}
            try:
                return json.loads(self.rfile.read(length).decode("utf-8"))
            except Exception:
                return {}

        def _index(self):
            path = os.path.join(console.root, "web", "index.html")
            try:
                with open(path, "rb") as fh:
                    body = fh.read()
            except OSError:
                self._err("页面文件缺失：web/index.html", 500)
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _image(self, path: str):
            """受控图片：只允许 console.root 下已存在的 png，防路径穿越。"""
            real = os.path.realpath(path)
            root_real = os.path.realpath(console.root)
            if not real.startswith(root_real + os.sep) or not real.endswith(".png"):
                return self._err("非法路径", 403)
            try:
                with open(real, "rb") as fh:
                    body = fh.read()
            except OSError:
                return self._err("图片不存在（先跑一次演练/校准生成）", 404)
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _dispatch(self, method: str):
            try:
                self._route(method)
            except contacts_mod.ValidationError as exc:
                self._err(str(exc))
            except PermissionError as exc:
                self._err(str(exc), 403)
            except FileNotFoundError as exc:
                self._err(f"资源不存在：{exc}", 404)
            except Exception as exc:  # 任何未知异常都转成 JSON，页面不至于白屏
                # 自动识别有专门定义 ResolveError，优先按它的 code/hint 上抛
                if exc.__class__.__name__ == "ResolveError":
                    self._err(str(exc), 400, code=getattr(exc, "code", ""), hint=getattr(exc, "hint", ""))
                else:
                    self._err(f"服务器内部错误：{exc}", 500)

        def _route(self, method: str):
            path = urllib.parse.unquote(self.path.split("?", 1)[0])
            if method == "GET" and path in ("/", "/index.html"):
                return self._index()

            if path == "/api/overview" and method == "GET":
                return self._ok(console.overview())
            if path == "/api/contacts":
                if method == "GET":
                    return self._ok(console.contacts())
                if method == "POST":
                    return self._ok(console.contact_add(self._body()))
            if path.startswith("/api/contacts/") and path[len("/api/contacts/"):].isdigit():
                index = int(path[len("/api/contacts/"):])
                if method == "PUT":
                    return self._ok(console.contact_update(index, self._body()))
                if method == "DELETE":
                    return self._ok(console.contact_delete(index))
            if path == "/api/contacts/resolve" and method == "POST":
                return self._ok(console.contact_resolve(self._body()))
            if path == "/api/contacts/discard-ref" and method == "POST":
                return self._ok(console.contact_discard_ref(self._body()))
            if path == "/api/pause" and method == "POST":
                return self._ok(console.toggle_pause())
            if path == "/api/run" and method == "POST":
                return self._ok(console.trigger_run(self._body()))
            if path == "/api/kill":
                if method == "POST":
                    return self._ok(console.kill_switch(True))
                if method == "DELETE":
                    return self._ok(console.kill_switch(False))
            if path == "/api/logs" and method == "GET":
                query = self.path.split("?", 1)[1] if "?" in self.path else ""
                lines = 300
                for pair in query.split("&"):
                    if pair.startswith("lines="):
                        try:
                            lines = int(pair[6:])
                        except ValueError:
                            pass
                return self._ok(console.logs(lines))

            # ----- 客户端设置 -----
            if path == "/api/settings":
                if method == "GET":
                    return self._ok(console.settings_view())
                if method == "PUT":
                    return self._ok(console.settings_update(self._body()))

            # ----- 配置与发送目标 -----
            if path == "/api/config" and method == "GET":
                return self._ok(console.config_view())
            if path == "/api/config/schedule" and method == "PUT":
                return self._ok(console.config_update_schedule(self._body()))
            if path == "/api/config/safety" and method == "PUT":
                return self._ok(console.config_update_safety(self._body()))
            if path == "/api/targets" and method == "GET":
                return self._ok(console.targets_list())
            if path == "/api/targets" and method == "POST":
                return self._ok(console.target_add(self._body()))
            if path.startswith("/api/targets/"):
                rest = path[len("/api/targets/"):]
                if rest.isdigit():
                    index = int(rest)
                    if method == "PUT":
                        return self._ok(console.target_update(index, self._body()))
                    if method == "DELETE":
                        return self._ok(console.target_delete(index))
                elif rest.endswith("/gate") and rest[: -len("/gate")].isdigit():
                    if method == "PUT":
                        return self._ok(console.target_gate(int(rest[: -len("/gate")]), self._body()))
            if path == "/api/calibrate" and method == "POST":
                return self._ok(console.calibrate_start())
            if path == "/api/calibrate/status" and method == "GET":
                return self._ok({"running": console.calibrating, "done_at": console.calibrate_done_at})

            # ----- 受控静态文件（校准图 / 参考图） -----
            if method == "GET":
                if path == "/files/calibrate.png":
                    return self._image(os.path.join(console.root, "logs", "calibrate.png"))
                if path.startswith("/files/refs/"):
                    name = os.path.basename(path[len("/files/refs/"):])
                    if name.lower().endswith(".png"):
                        name = name[: -len(".png")]
                    return self._image(console._ref_path(name))
            self._err(f"未知接口：{method} {path}", 404)

        # ----- 动词入口 -----
        def do_GET(self):
            if self._check_origin():
                self._dispatch("GET")

        def do_POST(self):
            if self._check_origin() and self._check_token():
                self._dispatch("POST")

        def do_PUT(self):
            if self._check_origin() and self._check_token():
                self._dispatch("PUT")

        def do_DELETE(self):
            if self._check_origin() and self._check_token():
                self._dispatch("DELETE")

    return Handler


def main():
    """独立运行：python wechat_auto/webapp.py [--port 8899] [--open]

    只提供联系人管理与只读状态（不接管调度、不触发发送），适合快速查看。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--open", action="store_true", help="启动后自动打开浏览器")
    args = parser.parse_args()

    from contacts import ContactStore
    from wechat_auto.config_loader import Config

    cfg = Config(ROOT)
    store = ContactStore(os.path.join(ROOT, "data", "contacts.json"))
    console = WebConsole(ROOT, store, cfg=cfg)
    port = console.start(args.port, open_browser=args.open)
    print(f"网页控制台（独立浏览模式）：{console.url}")
    print("此模式只管理联系人与只读状态；暂停/发送请启动主程序 app.py")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        console.stop()


if __name__ == "__main__":
    main()
