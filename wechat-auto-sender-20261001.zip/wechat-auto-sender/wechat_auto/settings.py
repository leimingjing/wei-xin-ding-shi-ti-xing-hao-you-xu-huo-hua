# -*- coding: utf-8 -*-
"""客户端设置：data/settings.json 持久化 + 开机自启（HKCU Run 注册表）。

只管客户端级的三件事：开机自启、关闭窗口行为、启动时是否最小化到托盘。
发送相关的安全闸门（dry_run / approved / 参考图）一律留在 config.yaml，两类配置不混。
"""
import copy
import json
import os
import sys

try:
    import winreg  # 仅 Windows；打包/跨平台兜底
except ImportError:  # pragma: no cover
    winreg = None

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_NAME = "WeChatAutoSender"

# 关闭窗口行为：minimize = 最小化到托盘；exit = 直接退出程序
CLOSE_CHOICES = ("minimize", "exit")

DEFAULTS = {
    "auto_start": False,          # 开机自启（写 HKCU Run）
    "close_behavior": "minimize", # 关闭窗口时的行为
    "start_minimized": False,     # 启动时自动最小化到托盘
    "window": {"width": 1280, "height": 860},  # 记忆窗口尺寸
}

MIN_WINDOW = (980, 640)


class SettingsError(Exception):
    """设置读写失败（权限 / 磁盘），调用方决定要不要打断用户。"""


def _default_startup_command() -> str:
    """开机自启命令：打包后用 exe 本体；源码模式用 pythonw（无控制台）跑 client.py。"""
    if getattr(sys, "frozen", False):  # PyInstaller 打包
        return f'"{sys.executable}" --startup'
    # 源码模式：优先 pythonw.exe（无黑窗），找不到再退回当前解释器
    exe_dir = os.path.dirname(sys.executable)
    pythonw = os.path.join(exe_dir, "pythonw.exe")
    if not os.path.exists(pythonw):
        pythonw = sys.executable
    here = os.path.dirname(os.path.abspath(__file__))
    client = os.path.normpath(os.path.join(here, "..", "client.py"))
    return f'"{pythonw}" "{client}" --startup'


class Settings:
    """三开关的持久化 + 注册表开机自启，全部同步 IO（调用方都在锁内或启动期）。"""

    def __init__(self, path: str, startup_command=None):
        self.path = path
        self.data = copy.deepcopy(DEFAULTS)
        self.startup_command = startup_command or _default_startup_command()
        self.auto_start_error = ""   # 最近一次注册表操作失败原因（UI 可展示）
        self.load()

    # ---------- 持久化 ----------
    def load(self):
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    stored = json.load(f)
                if isinstance(stored, dict):
                    self.data.update(self._sanitize(stored))
            except (OSError, ValueError):
                # 损坏就回默认值：宁可丢开关也不能起不来
                self.data = copy.deepcopy(DEFAULTS)
        return self.data

    def save(self):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)
        except OSError as exc:
            raise SettingsError(f"设置保存失败：{exc}") from None

    # ---------- 校验 ----------
    @staticmethod
    def _sanitize(patch: dict) -> dict:
        out = {}
        if "auto_start" in patch:
            out["auto_start"] = bool(patch["auto_start"])
        if "close_behavior" in patch:
            out["close_behavior"] = str(patch["close_behavior"]) if str(patch["close_behavior"]) in CLOSE_CHOICES else DEFAULTS["close_behavior"]
        if "start_minimized" in patch:
            out["start_minimized"] = bool(patch["start_minimized"])
        if isinstance(patch.get("window"), dict):
            w = patch["window"]
            try:
                width = max(MIN_WINDOW[0], int(w.get("width", DEFAULTS["window"]["width"])))
                height = max(MIN_WINDOW[1], int(w.get("height", DEFAULTS["window"]["height"])))
                out["window"] = {"width": width, "height": height}
            except (TypeError, ValueError):
                pass
        return out

    def update(self, patch: dict) -> dict:
        """合并补丁 → 落盘 → 同步注册表 → 返回最新值。"""
        self.data.update(self._sanitize(patch or {}))
        self.save()
        if "auto_start" in (patch or {}):
            self.apply_auto_start()
        return self.data

    # ---------- 开机自启（注册表） ----------
    @property
    def auto_start_supported(self) -> bool:
        return winreg is not None

    def _run_value(self):
        if winreg is None:
            return None
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
                value, _ = winreg.QueryValueEx(key, RUN_NAME)
                return value
        except OSError:
            return None

    def is_auto_start(self) -> bool:
        """注册表里实际有没有这条（以此为准，settings.json 只是意图）。"""
        return self._run_value() is not None

    def apply_auto_start(self):
        """把 settings.auto_start 的意图落到注册表；返回是否成功。"""
        self.auto_start_error = ""
        if not self.auto_start_supported:
            self.auto_start_error = "当前环境不支持注册表操作"
            return False
        want = bool(self.data.get("auto_start"))
        try:
            if want:
                with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
                    winreg.SetValueEx(key, RUN_NAME, 0, winreg.REG_SZ, self.startup_command)
            else:
                try:
                    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
                        winreg.DeleteValue(key, RUN_NAME)
                except FileNotFoundError:
                    pass  # 本来就没有，视为成功
            return True
        except OSError as exc:
            self.auto_start_error = str(exc)
            return False

    def sync_auto_start_on_boot(self):
        """启动期自愈：exe 换了位置 / 手动删过注册表值，按 settings 意图重写一次。"""
        if not self.auto_start_supported:
            return
        want = bool(self.data.get("auto_start"))
        current = self._run_value()
        if want and current != self.startup_command:
            self.apply_auto_start()
        elif not want and current is not None:
            self.apply_auto_start()

    # ---------- 视图（给 /api/settings） ----------
    def view(self) -> dict:
        return {
            "settings": copy.deepcopy(self.data),
            "auto_start_active": self.is_auto_start(),
            "auto_start_supported": self.auto_start_supported,
            "auto_start_error": self.auto_start_error,
            "startup_command": self.startup_command,
            "close_choices": list(CLOSE_CHOICES),
        }
