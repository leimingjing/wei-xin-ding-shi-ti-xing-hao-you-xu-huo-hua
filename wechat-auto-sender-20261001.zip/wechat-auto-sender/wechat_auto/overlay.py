# -*- coding: utf-8 -*-
"""任务执行状态悬浮窗（纯 Win32 / ctypes 实现，零新增第三方依赖）。

沿用项目既有的 Win32 风格（与 wechat/window.py 一致），不引入 tkinter/Qt，
也不占用主流程：窗口在独立线程里跑自己的消息循环，主线程只 PostMessage。

对外只暴露四个动作：
    show(seconds, detail, title)  开始；已存在则复用并刷新倒计时（需求 5）
    set_detail(text)              改副标题，例如「正在处理 示例联系人A（1/2）」
    stop()                        关闭并释放窗口 / 计时器 / 线程
    task_window(...)              上下文管理器：正常结束、取消、报错都保证收尾

关键实现点：
  · WS_EX_TOPMOST           → 始终置顶（需求 2）
  · WS_EX_NOACTIVATE        → 不抢焦点，避免打断正在被自动化操作的微信窗口
  · WS_EX_TOOLWINDOW        → 不进任务栏、不进 Alt+Tab
  · WM_TIMER 200ms 轮询     → 每秒刷新 mm:ss / hh:mm:ss（需求 3）
  · 归零 → WM_CLOSE         → 自动销毁 + KillTimer + 退出消息循环（需求 4）
  · 右上角 ×（SS_NOTIFY）   → 手动关闭（需求 6）
"""
import atexit
import ctypes
import ctypes.wintypes as wt
import threading
import time
from contextlib import contextmanager

_u = ctypes.windll.user32
_g = ctypes.windll.gdi32
_k = ctypes.windll.kernel32

CLASS_NAME = "WeChatAutoTaskOverlay"
DEFAULT_TITLE = "续火花任务正在执行中"

# ---------------- 窗口样式 / 消息常量 ----------------
WS_POPUP = 0x80000000
WS_CHILD = 0x40000000
WS_VISIBLE = 0x10000000
WS_EX_TOPMOST = 0x00000008
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_NOACTIVATE = 0x08000000
WS_EX_LAYERED = 0x00080000
SS_CENTER = 0x0001
SS_CENTERIMAGE = 0x0200
SS_NOTIFY = 0x0100

WM_CLOSE = 0x0010
WM_DESTROY = 0x0002
WM_TIMER = 0x0113
WM_COMMAND = 0x0111
WM_CTLCOLORSTATIC = 0x0138
WM_APP = 0x8000
WM_REFRESH = WM_APP + 1  # 复用窗口时刷新倒计时 / 副标题

SW_SHOWNOACTIVATE = 4
HWND_TOPMOST = -1
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010
SWP_SHOWWINDOW = 0x0040
LWA_ALPHA = 0x00000002
TRANSPARENT = 1
SPI_GETWORKAREA = 0x0030
MONITOR_DEFAULTTOPRIMARY = 1
IDT_COUNTDOWN = 1
ID_CLOSE = 1001
IDC_ARROW = 32512
CLEARTYPE_QUALITY = 5
DEFAULT_CHARSET = 1
ERROR_CLASS_ALREADY_EXISTS = 1410

# ---------------- 配色（COLORREF = 0x00BBGGRR） ----------------
C_BG = 0x00241914        # 面板底色 #141924
C_TITLE = 0x00F4F8FF     # 主标题 近白
C_TIME = 0x0060C107      # 倒计时 微信绿 #07C160
C_MUTED = 0x00B2A49A     # 副标题 灰蓝 #9AA4B2

# ---------------- 结构体 ----------------
LRESULT = ctypes.c_ssize_t
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)


class WNDCLASSW(ctypes.Structure):
    _fields_ = [
        ("style", wt.UINT),
        ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wt.HINSTANCE),
        ("hIcon", wt.HICON),
        ("hCursor", wt.HANDLE),
        ("hbrBackground", wt.HBRUSH),
        ("lpszMenuName", wt.LPCWSTR),
        ("lpszClassName", wt.LPCWSTR),
    ]


class MONITORINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wt.DWORD),
        ("rcMonitor", wt.RECT),
        ("rcWork", wt.RECT),
        ("dwFlags", wt.DWORD),
    ]


# ---------------- Win32 原型（显式声明，避免 64 位句柄被截断） ----------------
_u.CreateWindowExW.argtypes = [wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD,
                               ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                               wt.HWND, wt.HMENU, wt.HINSTANCE, wt.LPVOID]
_u.CreateWindowExW.restype = wt.HWND
_u.RegisterClassW.argtypes = [ctypes.POINTER(WNDCLASSW)]
_u.RegisterClassW.restype = wt.ATOM
_u.DefWindowProcW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
_u.DefWindowProcW.restype = LRESULT
_u.DestroyWindow.argtypes = [wt.HWND]
_u.IsWindow.argtypes = [wt.HWND]
_u.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
_u.SetWindowPos.argtypes = [wt.HWND, wt.HWND, ctypes.c_int, ctypes.c_int,
                            ctypes.c_int, ctypes.c_int, wt.UINT]
_u.SetWindowTextW.argtypes = [wt.HWND, wt.LPCWSTR]
_u.PostMessageW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
_u.SetTimer.argtypes = [wt.HWND, ctypes.c_size_t, wt.UINT, ctypes.c_void_p]
_u.KillTimer.argtypes = [wt.HWND, ctypes.c_size_t]
_u.SetLayeredWindowAttributes.argtypes = [wt.HWND, wt.COLORREF, ctypes.c_ubyte, wt.DWORD]
_u.GetForegroundWindow.restype = wt.HWND
_u.MonitorFromWindow.argtypes = [wt.HWND, wt.DWORD]
_u.MonitorFromWindow.restype = wt.HMONITOR
_u.GetMonitorInfoW.argtypes = [wt.HMONITOR, ctypes.POINTER(MONITORINFO)]
_u.GetMessageW.argtypes = [ctypes.POINTER(wt.MSG), wt.HWND, wt.UINT, wt.UINT]
_u.TranslateMessage.argtypes = [ctypes.POINTER(wt.MSG)]
_u.DispatchMessageW.argtypes = [ctypes.POINTER(wt.MSG)]
_u.GetWindowRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
_u.GetWindowTextW.argtypes = [wt.HWND, wt.LPCWSTR, ctypes.c_int]
_u.GetWindowTextLengthW.argtypes = [wt.HWND]
_u.FindWindowW.argtypes = [wt.LPCWSTR, wt.LPCWSTR]
_u.FindWindowW.restype = wt.HWND
_u.LoadCursorW.argtypes = [wt.HINSTANCE, wt.LPCWSTR]
_u.LoadCursorW.restype = wt.HANDLE

_g.CreateSolidBrush.argtypes = [wt.COLORREF]
_g.CreateSolidBrush.restype = wt.HBRUSH
_g.CreateFontW.argtypes = [ctypes.c_int] * 13 + [wt.LPCWSTR]
_g.CreateFontW.restype = wt.HFONT
_g.SetBkMode.argtypes = [wt.HDC, ctypes.c_int]
_g.SetTextColor.argtypes = [wt.HDC, wt.COLORREF]


# ---------------- 单例状态 ----------------
_lock = threading.RLock()
_ready = threading.Event()
_thread = None
_hwnd = None
_h_title = None
_h_time = None
_h_detail = None
_h_close = None
_brush = None
_font_title = None
_font_time = None
_font_small = None
_proc_ref = None  # WNDPROC 回调必须长期持有，否则被 GC 后窗口类里留下野指针 → 0xC000001D

_deadline = 0.0
_detail = ""
_title = DEFAULT_TITLE
_last_time_text = ""
_last_detail_text = ""

# 窗口类 / 回调：一个进程只注册一次。
# 反例（实测踩过）：每次建窗都新建 WNDPROC 覆盖 _proc_ref → 旧的被 GC，
# 已注册窗口类里留下野指针，第二次建窗必崩（0xC000001D / access violation）。
_class_ready = False
_cls_ref = None


# ---------------- 工具 ----------------
def _dpi_scale() -> float:
    try:
        dpi = int(_u.GetDpiForSystem())
    except Exception:
        dpi = 96
    if dpi <= 0:
        dpi = 96
    return max(1.0, min(2.5, dpi / 96.0))


def _work_rect() -> wt.RECT:
    """优先取「当前前台窗口所在显示器」的工作区，取不到再退回主显示器。"""
    mi = MONITORINFO()
    mi.cbSize = ctypes.sizeof(MONITORINFO)
    try:
        hmon = _u.MonitorFromWindow(_u.GetForegroundWindow(), MONITOR_DEFAULTTOPRIMARY)
        if hmon and _u.GetMonitorInfoW(hmon, ctypes.byref(mi)):
            return mi.rcWork
    except Exception:
        pass
    rect = wt.RECT()
    try:
        if _u.SystemParametersInfoW(SPI_GETWORKAREA, 0, ctypes.byref(rect), 0):
            return rect
    except Exception:
        pass
    return wt.RECT(0, 0, _u.GetSystemMetrics(0), _u.GetSystemMetrics(1))


def _anchor(w: int, h: int):
    """右上角定位（留 16px 边距）。"""
    r = _work_rect()
    margin = int(16 * _dpi_scale())
    x = max(0, int(r.right) - w - margin)
    y = max(0, int(r.top) + margin)
    return x, y


def _fmt(seconds: float) -> str:
    total = max(0, int(seconds + 0.999))  # 向上取整，避免一开始就少一秒
    hh, rem = divmod(total, 3600)
    mm, ss = divmod(rem, 60)
    if hh:
        return f"{hh:02d}:{mm:02d}:{ss:02d}"
    return f"{mm:02d}:{ss:02d}"


def _ensure_resources():
    """画笔 / 字体按进程只创建一次，避免反复创建泄漏 GDI 对象。"""
    global _brush, _font_title, _font_time, _font_small
    if _brush is None:
        _brush = _g.CreateSolidBrush(C_BG)
    if _font_title is None:
        s = _dpi_scale()
        _font_title = _g.CreateFontW(-int(14 * s), 0, 0, 0, 700, 0, 0, 0,
                                     DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, "微软雅黑")
        _font_time = _g.CreateFontW(-int(30 * s), 0, 0, 0, 700, 0, 0, 0,
                                    DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, "Consolas")
        _font_small = _g.CreateFontW(-int(12 * s), 0, 0, 0, 400, 0, 0, 0,
                                     DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, "微软雅黑")


def _set_font(ctrl, font):
    if ctrl and font:
        _u.SendMessageW(ctrl, 0x0030, font, 1)  # WM_SETFONT


_u.SendMessageW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
_u.SendMessageW.restype = LRESULT


# ---------------- 窗口过程 ----------------
def _wndproc(hwnd, msg, wparam, lparam):
    try:
        if msg == WM_TIMER:
            _tick(hwnd)
            return 0
        if msg == WM_COMMAND:
            if (wparam & 0xFFFF) == ID_CLOSE:  # 右上角 ×
                _u.PostMessageW(hwnd, WM_CLOSE, 0, 0)
                return 0
        if msg == WM_REFRESH:
            _render(hwnd, force=True)
            return 0
        if msg == WM_CTLCOLORSTATIC:
            _g.SetBkMode(wparam, TRANSPARENT)
            ctl = lparam
            if ctl == _h_time:
                _g.SetTextColor(wparam, C_TIME)
            elif ctl in (_h_detail, _h_close):
                _g.SetTextColor(wparam, C_MUTED)
            else:
                _g.SetTextColor(wparam, C_TITLE)
            return int(_brush or 0)
        if msg == WM_DESTROY:
            try:
                _u.KillTimer(hwnd, IDT_COUNTDOWN)
            except Exception:
                pass
            _u.PostQuitMessage(0)
            _release()
            return 0
    except Exception:
        pass
    return _u.DefWindowProcW(hwnd, msg, wparam, lparam)


def _tick(hwnd):
    left = _deadline - time.monotonic()
    if left <= 0:
        _u.SetWindowTextW(_h_time, "00:00")
        _u.PostMessageW(hwnd, WM_CLOSE, 0, 0)  # 倒计时归零 → 自动关闭（需求 4）
        return
    _render(hwnd)


def _render(hwnd, force=False):
    """只在文本变化时写控件，顺带每秒重新声明一次置顶（防止被全屏窗口压下去）。"""
    global _last_time_text, _last_detail_text
    left = _deadline - time.monotonic()
    text = _fmt(left)
    if force or text != _last_time_text:
        _last_time_text = text
        _u.SetWindowTextW(_h_time, text)
        _u.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                        SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)
    detail = _detail
    if force or detail != _last_detail_text:
        _last_detail_text = detail
        _u.SetWindowTextW(_h_detail, detail)


def _release():
    """线程侧：窗口已被销毁，清掉单例标记。"""
    global _hwnd, _thread, _h_title, _h_time, _h_detail, _h_close
    with _lock:
        _hwnd = None
        _thread = None
        _h_title = _h_time = _h_detail = _h_close = None


def _static(parent, text, x, y, w, h, ctrl_id=None, style=SS_CENTERIMAGE):
    hwnd = _u.CreateWindowExW(
        0, "STATIC", text,
        WS_CHILD | WS_VISIBLE | style,
        x, y, w, h, parent,
        wt.HMENU(ctrl_id) if ctrl_id else None,
        None, None,
    )
    return hwnd


def _ensure_class(hinst) -> bool:
    """注册窗口类（进程内只做一次；回调与结构体全程持有，保证窗口类里的指针有效）。"""
    global _proc_ref, _class_ready, _cls_ref
    if _class_ready:
        return True
    cls = WNDCLASSW()
    if _proc_ref is None:  # 只创建一次，之后永不覆盖
        _proc_ref = WNDPROC(_wndproc)
    cls.lpfnWndProc = _proc_ref
    cls.hInstance = wt.HINSTANCE(hinst)
    cls.lpszClassName = CLASS_NAME
    cls.hbrBackground = _brush
    try:
        cls.hCursor = _u.LoadCursorW(None, wt.LPCWSTR(IDC_ARROW))
    except Exception:
        cls.hCursor = None
    ok = bool(_u.RegisterClassW(ctypes.byref(cls)))
    if not ok and _k.GetLastError() != ERROR_CLASS_ALREADY_EXISTS:
        return False
    _cls_ref = cls  # 保持结构体存活
    _class_ready = True
    return True


def _run():
    """悬浮窗线程主体：建窗 → 消息循环 → 退出即释放。"""
    global _hwnd, _h_title, _h_time, _h_detail, _h_close
    global _last_time_text, _last_detail_text
    try:
        _ensure_resources()
        _last_time_text = ""
        _last_detail_text = ""
        hinst = _k.GetModuleHandleW(None)
        if not _ensure_class(hinst):
            return

        s = _dpi_scale()
        w, h = int(272 * s), int(104 * s)
        x, y = _anchor(w, h)
        hwnd = _u.CreateWindowExW(
            WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_LAYERED,
            CLASS_NAME, _title, WS_POPUP,
            x, y, w, h, None, None, wt.HINSTANCE(hinst), None,
        )
        if not hwnd:
            return
        _hwnd = hwnd

        pad = int(14 * s)
        _h_title = _static(hwnd, _title, pad, int(11 * s),
                           w - pad - int(34 * s), int(20 * s))
        _h_time = _static(hwnd, "00:00", pad, int(32 * s),
                          w - pad * 2, int(38 * s))
        _h_detail = _static(hwnd, _detail, pad, int(74 * s),
                            w - pad * 2, int(18 * s))
        _h_close = _static(hwnd, "×", w - int(30 * s), int(8 * s),
                           int(22 * s), int(20 * s),
                           ctrl_id=ID_CLOSE, style=SS_CENTER | SS_CENTERIMAGE | SS_NOTIFY)

        _set_font(_h_title, _font_title)
        _set_font(_h_time, _font_time)
        _set_font(_h_detail, _font_small)
        _set_font(_h_close, _font_title)

        try:
            _u.SetLayeredWindowAttributes(hwnd, 0, 248, LWA_ALPHA)
        except Exception:
            pass
        _u.ShowWindow(hwnd, SW_SHOWNOACTIVATE)
        _u.SetWindowPos(hwnd, HWND_TOPMOST, x, y, 0, 0,
                        SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW)
        _render(hwnd, force=True)
        _u.SetTimer(hwnd, IDT_COUNTDOWN, 200, None)

        msg = wt.MSG()
        while _u.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            _u.TranslateMessage(ctypes.byref(msg))
            _u.DispatchMessageW(ctypes.byref(msg))
    finally:
        _ready.set()
        _release()


# ---------------- 对外 API ----------------
def show(seconds: float, detail: str = "", title: str = DEFAULT_TITLE) -> bool:
    """显示悬浮窗。返回 True=新建窗口；False=复用了已有窗口（只刷新倒计时）。"""
    global _deadline, _detail, _title, _thread
    seconds = max(1, int(seconds or 0))
    with _lock:
        _title = title
        _detail = detail
        _deadline = time.monotonic() + seconds

        if _hwnd and _u.IsWindow(_hwnd):
            _u.PostMessageW(_hwnd, WM_REFRESH, 0, 0)
            return False
        if _thread is not None and _thread.is_alive():
            return False  # 正在创建，共享状态已更新，线程起来后会读到

        _ready.clear()
        _thread = threading.Thread(target=_run, name="TaskOverlay", daemon=True)
        _thread.start()
        _ready.wait(1.0)  # 等句柄就绪（通常几十毫秒），超时也不阻塞主流程
        return True


def set_detail(text: str):
    """更新副标题（如「正在处理 示例联系人A（1/2）」），不影响倒计时。"""
    global _detail
    with _lock:
        _detail = text
        if _hwnd and _u.IsWindow(_hwnd):
            _u.PostMessageW(_hwnd, WM_REFRESH, 0, 0)


def stop():
    """关闭悬浮窗并释放窗口 / 计时器 / 线程。线程安全，可重复调用。"""
    with _lock:
        hwnd, th = _hwnd, _thread
    try:
        if hwnd and _u.IsWindow(hwnd):
            _u.PostMessageW(hwnd, WM_CLOSE, 0, 0)
    except Exception:
        pass
    if th is not None and th.is_alive():
        th.join(timeout=2.0)


def is_active() -> bool:
    with _lock:
        return bool(_hwnd and _u.IsWindow(_hwnd))


@contextmanager
def task_window(seconds: float, detail: str = "", title: str = DEFAULT_TITLE):
    """任务执行期的悬浮窗作用域：正常结束 / 取消 / 抛异常都会关闭窗口。"""

    class _H:
        def detail(self, text):
            set_detail(text)

        def close(self):
            stop()

    handle = _H()
    try:
        show(seconds, detail=detail, title=title)
        yield handle
    finally:
        stop()


def _atexit_stop():  # pragma: no cover - 进程退出兜底
    try:
        stop()
    except Exception:
        pass


atexit.register(_atexit_stop)
