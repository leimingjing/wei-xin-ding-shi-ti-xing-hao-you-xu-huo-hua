# -*- coding: utf-8 -*-
"""配置加载、消息模板渲染与发送状态记录。"""
import datetime as _dt
import json
import os
import random
import re

import yaml

WEEKDAY_CN = {1: "周一", 2: "周二", 3: "周三", 4: "周四", 5: "周五", 6: "周六", 7: "周日"}

GREETINGS = {
    "morning": ["早上好", "新的一天开始了", "愿你今天顺利", "记得吃早饭"],
    "noon": ["中午好", "记得午休", "别忘了喝水"],
    "afternoon": ["下午好", "加油", "稍作休息"],
    "evening": ["晚上好", "今天辛苦了", "早点休息", "晚安"],
}

_DEFAULTS = {
    "wechat": {"exe_path": "", "window_class": "WeChatMainWndForPC", "launch_timeout": 40},
    "schedule": {"enabled": True, "times": [], "jitter_minutes": 3, "weekdays": [1, 2, 3, 4, 5, 6, 7]},
    "targets": [],
    "behavior": {
        "step_delay": [1.2, 4.5],
        "mouse_curve": True,
        "mouse_steps": [14, 30],
        "segment_paste": True,
        "segment_delay": [0.5, 2.0],
    },
    "safety": {
        "dry_run": True,
        "max_retry": 2,
        "abort_on_user_input": True,
        "snapshot": True,
        "log_retention_days": 30,
        "kill_switch_file": "STOP",
        "verify_mode": "strict",
        # 发送成功判据：发送前后消息区变化比例下限（P3-4，可在 config.yaml 覆盖）
        "message_diff_threshold": 0.005,
    },
    "ui": {
        # 任务执行状态悬浮窗：右上角置顶显示「续火花任务正在执行中」+ 剩余时间倒计时
        "task_overlay": True,
        # 每个联系人的预估耗时（秒），用于换算倒计时的总时长；
        # 任务提前结束会立刻关闭，估长了不会拖住流程（归零也会自动关闭）
        "seconds_per_target": 45,
    },
}


def _merge(base, override):
    out = dict(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


def _greeting(now: _dt.datetime) -> str:
    hour = now.hour
    if hour < 11:
        pool = GREETINGS["morning"]
    elif hour < 14:
        pool = GREETINGS["noon"]
    elif hour < 18:
        pool = GREETINGS["afternoon"]
    else:
        pool = GREETINGS["evening"]
    return random.choice(pool)


class Config:
    def __init__(self, root: str, path: str = None):
        self.root = root
        self.path = path or os.path.join(root, "config", "config.yaml")
        if not os.path.isfile(self.path):
            # P2-1：源码目录里的 config.yaml 已改名为 config.example.yaml（模板），
            # 只有 dist 运行时目录才带 config.yaml。直接跑源码时回退到模板，
            # 避免"以为在用活配置、其实读到模板"这类静默错配。
            example = os.path.join(os.path.dirname(self.path), "config.example.yaml")
            if os.path.isfile(example):
                self.path = example
        with open(self.path, "r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
        self.data = _merge(_DEFAULTS, raw)
        self.state_path = os.path.join(root, "logs", "state.json")
        self.state = self._load_state()

    # ---------- 基础访问 ----------
    @property
    def wechat(self):
        return self.data["wechat"]

    @property
    def schedule(self):
        return self.data["schedule"]

    @property
    def behavior(self):
        return self.data["behavior"]

    @property
    def safety(self):
        return self.data["safety"]

    @property
    def ui(self):
        return self.data["ui"]

    @property
    def targets(self):
        return [t for t in self.data.get("targets", []) if t.get("enabled")]

    def reload(self):
        with open(self.path, "r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
        self.data = _merge(_DEFAULTS, raw)

    # ---------- 状态 ----------
    def _load_state(self):
        try:
            with open(self.state_path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return {}

    def _save_state(self):
        """原子写状态文件（P2-4）。

        定时任务线程与网页触发的线程都可能调用本方法；直接覆盖写存在被中断后
        留下半截 JSON 的可能，而 _load_state 遇到损坏文件会整体退回 {}，
        last_sent / last_index 一起丢失。改为「写临时文件 + os.replace」原子替换。
        """
        os.makedirs(os.path.dirname(self.state_path), exist_ok=True)
        tmp = f"{self.state_path}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.state, fh, ensure_ascii=False, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, self.state_path)

    # ---------- 消息 ----------
    def render(self, template: str, name: str, now: _dt.datetime = None) -> str:
        now = now or _dt.datetime.now()
        mapping = {
            "name": name,
            "date": f"{now.year}年{now.month}月{now.day}日",
            "weekday": WEEKDAY_CN.get(now.isoweekday(), ""),
            "time": now.strftime("%H:%M"),
            "greeting": _greeting(now),
        }
        result = template
        for key, value in mapping.items():
            result = result.replace("{" + key + "}", value)
        result = re.sub(r"\{(\w+)\}", "", result)
        return result.strip()

    def pick_message(self, target: dict, now: _dt.datetime = None) -> str:
        """随机取一条模板，并尽量避开上一次用过的那条。"""
        messages = [m for m in target.get("messages", []) if m]
        if not messages:
            return ""
        state = self.state.setdefault(target["name"], {})
        last = state.get("last_index", -1)
        candidates = [i for i in range(len(messages)) if i != last] or list(range(len(messages)))
        index = random.choice(candidates)
        state["last_index"] = index
        self._save_state()
        return self.render(messages[index], target["name"], now)

    def mark_sent(self, target_name: str):
        state = self.state.setdefault(target_name, {})
        state["last_sent"] = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self._save_state()

    def already_sent(self, target_name: str, within_seconds: int = 300) -> bool:
        """最近 within_seconds 秒内是否已成功发送过（幂等保护的依据，P0-2）。

        只在「消息已经进到对方会话、但收尾阶段抛异常」时用于阻止重试重发；
        正常路径下不参与任何决策，因此不会误伤"用户就想再发一次"的场景。
        """
        state = self.state.get(target_name) or {}
        last = state.get("last_sent") or state.get("_last_ok")
        if not last:
            return False
        try:
            sent_at = _dt.datetime.strptime(str(last), "%Y-%m-%d %H:%M:%S")
        except Exception:
            return False
        return (_dt.datetime.now() - sent_at).total_seconds() <= max(1, int(within_seconds))

    def target_times(self, target: dict):
        return target.get("times") or self.schedule.get("times") or []

    def validate(self):
        """返回 (错误列表, 警告列表)。"""
        errors, warns = [], []
        for target in self.targets:
            if not target.get("name"):
                errors.append("存在未填写 name 的联系人配置")
            if not target.get("messages"):
                errors.append(f"联系人 {target.get('name')} 未配置 messages")
            if not self.target_times(target):
                warns.append(f"联系人 {target.get('name')} 没有可用的发送时间点")
            if self.safety.get("verify_mode") != "strict":
                warns.append("verify_mode 非 strict，存在发错人的风险")
        if self.safety.get("dry_run"):
            warns.append("当前为 dry_run 演练模式，不会真正发送")
        return errors, warns
