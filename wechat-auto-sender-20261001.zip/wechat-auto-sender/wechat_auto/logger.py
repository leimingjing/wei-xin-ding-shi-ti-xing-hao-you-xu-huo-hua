# -*- coding: utf-8 -*-
"""日志与截图存证。"""
import datetime as _dt
import logging
import os
import re
from logging.handlers import RotatingFileHandler

_SAFE = re.compile(r'[\\/:*?"<>|\s]+')

# 控制台侧的暂存区：界面接管前先攒着，接管后由界面统一重放，
# 这样启动信息不会跟菜单混在一起，也不会丢。
_BUFFER = []
_BUFFER_LIMIT = 200
_SINK = None


class ConsoleHandler(logging.Handler):
    """控制台输出：默认只放 WARNING 及以上，一行一条，去掉时间戳噪声。

    文件日志不受影响（仍是全量 INFO），所以审计信息一条不少。
    """

    def emit(self, record):
        try:
            message = record.getMessage()
        except Exception:
            return
        _BUFFER.append((record.levelname, message))
        if len(_BUFFER) > _BUFFER_LIMIT:
            del _BUFFER[0]
        if _SINK is not None:
            try:
                _SINK(record.levelname, message)
                return
            except Exception:
                pass
        marker = {"ERROR": "[x]", "CRITICAL": "[x]", "WARNING": "[!]"}.get(record.levelname, "[i]")
        try:
            print(f"{marker} {message}", flush=True)
        except UnicodeEncodeError:
            enc = getattr(__import__("sys").stdout, "encoding", None) or "utf-8"
            print(f"{marker} {message}".encode(enc, "replace").decode(enc, "replace"), flush=True)


def attach_console_sink(fn):
    """界面接管控制台：返回并清空启动期暂存记录，供界面统一展示。"""
    global _SINK
    _SINK = fn
    pending = list(_BUFFER)
    _BUFFER.clear()
    return pending


def detach_console_sink():
    global _SINK
    _SINK = None


def console_level() -> int:
    """可用 WECHAT_CONSOLE_LOG=INFO|DEBUG 临时提高控制台详细度。"""
    name = (os.environ.get("WECHAT_CONSOLE_LOG") or "WARNING").strip().upper()
    return getattr(logging, name, logging.WARNING)


def setup(root: str, retention_days: int = 30, level=logging.INFO):
    log_dir = os.path.join(root, "logs")
    snap_dir = os.path.join(log_dir, "snapshots")
    os.makedirs(snap_dir, exist_ok=True)

    logger = logging.getLogger("wechat_auto")
    logger.setLevel(level)
    logger.handlers.clear()
    logger.propagate = False

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")

    fh = RotatingFileHandler(
        os.path.join(log_dir, "run.log"), maxBytes=2 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    sh = ConsoleHandler()
    sh.setLevel(console_level())
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    _cleanup(snap_dir, retention_days)
    return logger


def _cleanup(directory: str, days: int):
    if days <= 0:
        return
    deadline = _dt.datetime.now() - _dt.timedelta(days=days)
    try:
        for name in os.listdir(directory):
            path = os.path.join(directory, name)
            if not os.path.isfile(path):
                continue
            if _dt.datetime.fromtimestamp(os.path.getmtime(path)) < deadline:
                os.remove(path)
    except Exception:
        pass


def snapshot(root: str, tag: str, region=None) -> str:
    """截图存证。region=(left, top, width, height)，None 表示全屏。"""
    try:
        from PIL import ImageGrab

        stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        name = f"{stamp}_{_SAFE.sub('_', tag)}.png"
        path = os.path.join(root, "logs", "snapshots", name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if region:
            left, top, width, height = region
            box = (left, top, left + width, top + height)
            ImageGrab.grab(bbox=box, all_screens=True).save(path)
        else:
            ImageGrab.grab(all_screens=True).save(path)
        return path
    except Exception as exc:
        return f"<截图失败: {exc}>"
