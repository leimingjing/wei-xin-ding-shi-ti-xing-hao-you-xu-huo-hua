# -*- coding: utf-8 -*-
"""安全护栏：单实例锁、急停、用户活动检测。"""
import ctypes
import os
import time


class Abort(Exception):
    """任何一步不达标就抛出，立即终止本次任务。"""


class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_ulong)]


def last_input_tick() -> int:
    info = LASTINPUTINFO()
    info.cbSize = ctypes.sizeof(LASTINPUTINFO)
    ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info))
    return info.dwTime


def _process_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        return False
    code = ctypes.c_ulong()
    ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
    ctypes.windll.kernel32.CloseHandle(handle)
    return code.value == 259  # STILL_ACTIVE


class SingleInstance:
    """防止重复触发导致并发狂发。

    2026-09-19 修复（P1-2）：原实现 release() 无条件删锁文件，而 acquire() 在
    「锁里的 pid == 本进程」时直接放行（app.py 持锁启动 + Sender.run_once 再拿一次）。
    两者叠加的后果：任务跑完 → 锁被下层调用删掉 → 第二个客户端实例又能拿到锁 →
    两个进程同时驱动键鼠（最坏把 A 的消息粘进 B 的会话）。现在用 _created 记录
    「这把锁是不是本次调用创建的」，只有创建者才有资格删除，且删前再核对 pid。
    """

    def __init__(self, root: str, name: str = "wechat_auto.lock"):
        self.path = os.path.join(root, "logs", name)
        self.owner_pid = 0
        self._created = False

    def acquire(self) -> bool:
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as fh:
                    pid = int(fh.read().strip() or 0)
            except Exception:
                pid = 0
            if _process_alive(pid):
                # 同一个进程重复获取要放行：app.py 持锁启动，Sender.run_once 还会再拿一次，
                # 否则 --run-now / 定时任务都会被自己挡住（永远发不出去）。
                if pid == os.getpid():
                    self._created = False   # 锁由上层持有着，本次调用无权删除它
                    return True
                self.owner_pid = pid
                return False
        with open(self.path, "w", encoding="utf-8") as fh:
            fh.write(str(os.getpid()))
        self._created = True
        return True

    def release(self):
        if not self._created:
            return          # 非创建者不删锁，避免把别人的互斥锁删掉（互斥失效的根因）
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                if int(fh.read().strip() or 0) != os.getpid():
                    return  # 锁文件已易主（pid 变了），绝不删别人的锁
        except FileNotFoundError:
            return
        except Exception:
            pass
        try:
            os.remove(self.path)
        except Exception:
            pass
        self._created = False


class Guard:
    """执行期间的守卫：kill switch + 用户活动检测。"""

    def __init__(self, root: str, kill_switch_file: str = "STOP", watch_user: bool = True):
        self.kill_path = os.path.join(root, kill_switch_file)
        self.watch_user = watch_user
        try:
            self.baseline = last_input_tick()
        except Exception:
            # 若 GetLastInputInfo 失败（罕见：驱动问题等），默认不检测用户活动
            self.watch_user = False
            self.baseline = 0
        self.started = time.time()

    def kill_triggered(self) -> bool:
        return os.path.exists(self.kill_path)

    def user_active(self) -> bool:
        if not self.watch_user:
            return False
        return last_input_tick() != self.baseline

    def check(self, stage: str = ""):
        if self.kill_triggered():
            raise Abort(f"检测到急停文件 {self.kill_path}，任务中止（阶段：{stage}）")
        if self.user_active():
            raise Abort(f"检测到用户正在使用键鼠，为避免干扰主动中止（阶段：{stage}）")
