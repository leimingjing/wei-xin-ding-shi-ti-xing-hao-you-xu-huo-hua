# -*- coding: utf-8 -*-
"""底层键鼠输入：走系统级 SendInput / mouse_event，与真实键鼠同一通道。"""
import ctypes
import random
import time

# 开启 DPI 感知，否则高分屏下坐标会偏移
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

import win32api  # noqa: E402
import win32con  # noqa: E402

VK_MAP = {
    "ctrl": 0x11,
    "control": 0x11,
    "alt": 0x12,
    "shift": 0x10,
    "enter": 0x0D,
    "return": 0x0D,
    "esc": 0x1B,
    "escape": 0x1B,
    "tab": 0x09,
    "back": 0x08,
    "delete": 0x2E,
    "space": 0x20,
    "home": 0x24,
    "end": 0x23,
    "up": 0x26,
    "down": 0x28,
    "left": 0x25,
    "right": 0x27,
    "win": 0x5B,
}


def vk_of(name) -> int:
    if isinstance(name, int):
        return name
    key = str(name).lower()
    if key in VK_MAP:
        return VK_MAP[key]
    if len(key) == 1:
        code = win32api.VkKeyScan(key[0])
        return code & 0xFF
    raise ValueError(f"未知按键: {name}")


def key_down(vk: int):
    win32api.keybd_event(vk, 0, 0, 0)


def key_up(vk: int):
    win32api.keybd_event(vk, 0, win32con.KEYEVENTF_KEYUP, 0)


def press(name, hold: float = 0.03):
    vk = vk_of(name)
    key_down(vk)
    time.sleep(hold)
    key_up(vk)


def combo(*names, gap: float = 0.05):
    """组合键，如 combo('ctrl', 'v')。"""
    codes = [vk_of(n) for n in names]
    for vk in codes:
        key_down(vk)
        time.sleep(0.02)
    time.sleep(0.02)
    for vk in reversed(codes):
        key_up(vk)
        time.sleep(gap)


def cursor_pos():
    return win32api.GetCursorPos()


# SetCursorPos 的输入结构（用于兜底）
class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]


class _INPUT(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("mi", _MOUSEINPUT)]


def _send_input_move(x: int, y: int) -> bool:
    """用 SendInput 绝对坐标移动光标。

    比 SetCursorPos 更可靠：不要求线程有消息队列，也不受 pywin32 包装层
    误报上次 GetLastError 的影响（曾遇到 stderr 报 14007 但坐标其实可用）。
    绝对坐标要按虚拟桌面（多显示器）归一化，否则副屏会偏。
    """
    user32 = ctypes.windll.user32
    vx = user32.GetSystemMetrics(76)   # SM_XVIRTUALSCREEN
    vy = user32.GetSystemMetrics(77)   # SM_YVIRTUALSCREEN
    vw = user32.GetSystemMetrics(78)   # SM_CXVIRTUALSCREEN
    vh = user32.GetSystemMetrics(79)   # SM_CYVIRTUALSCREEN
    if vw <= 0 or vh <= 0:
        return False
    nx = int(round((x - vx) * 65535 / max(1, vw - 1)))
    ny = int(round((y - vy) * 65535 / max(1, vh - 1)))
    flags = 0x0001 | 0x8000 | 0x4000      # MOVE | ABSOLUTE | VIRTUALDESK
    inp = _INPUT(type=0, mi=_MOUSEINPUT(dx=nx, dy=ny, mouseData=0, dwFlags=flags, time=0, dwExtraInfo=None))
    sent = user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT))
    return bool(sent)


def set_cursor(x: int, y: int):
    """把光标移到 (x, y)，带两级兜底。

    优先 SetCursorPos（最快）；若返回失败或 pywin32 抛错，改用 SendInput 绝对移动。
    不依赖调用线程是否有消息队列，因此在网页控制台的 HTTP 工作线程里也稳定。
    """
    x, y = int(x), int(y)
    try:
        if ctypes.windll.user32.SetCursorPos(x, y):
            return
    except Exception:
        pass
    try:
        win32api.SetCursorPos((x, y))
        return
    except Exception:
        pass
    try:
        _send_input_move(x, y)
    except Exception:
        # 最后仍失败就交给调用方；点击本身还有 mouse_event 兜底
        pass


def mouse_down(button: str = "left"):
    flag = win32con.MOUSEEVENTF_LEFTDOWN if button == "left" else win32con.MOUSEEVENTF_RIGHTDOWN
    win32api.mouse_event(flag, 0, 0, 0, 0)


def mouse_up(button: str = "left"):
    flag = win32con.MOUSEEVENTF_LEFTUP if button == "left" else win32con.MOUSEEVENTF_RIGHTUP
    win32api.mouse_event(flag, 0, 0, 0, 0)


def click_at(x: int, y: int, button: str = "left", hold: float = None):
    set_cursor(x, y)
    time.sleep(0.03 + random.random() * 0.05)
    mouse_down(button)
    time.sleep(hold if hold is not None else 0.04 + random.random() * 0.06)
    mouse_up(button)


def wheel(clicks: int, x: int = None, y: int = None, step: int = 120):
    """滚轮：正数向上、负数向下；鼠标会先移到 (x, y) 以保证滚到目标控件。"""
    if x is not None and y is not None:
        set_cursor(x, y)
        time.sleep(0.08)
    direction = 1 if clicks > 0 else -1
    for _ in range(abs(int(clicks))):
        win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, direction * step, 0)
        time.sleep(random.uniform(0.05, 0.12))


def clipboard_set(text: str):
    import pyperclip

    pyperclip.copy(text)


def clipboard_paste(pause: float = 0.15):
    """执行 Ctrl+V；调用方需先写入剪贴板。"""
    time.sleep(0.05)
    combo("ctrl", "v")
    time.sleep(pause)
