# -*- coding: utf-8 -*-
"""拟人化输入层：随机间隔、贝塞尔鼠标轨迹、分段粘贴。"""
import math
import random
import time

import pyperclip

from . import kbdmouse as km


def _rand_range(pair, default=(1.0, 2.0)):
    try:
        low, high = float(pair[0]), float(pair[1])
    except Exception:
        low, high = default
    if high < low:
        low, high = high, low
    return random.uniform(low, high)


class Human:
    def __init__(self, behavior: dict):
        self.behavior = behavior or {}
        self.curve = bool(self.behavior.get("mouse_curve", True))
        self.steps = self.behavior.get("mouse_steps", [14, 30])
        self.expected_pos = None
        self._clip_saved = None   # 首次粘贴前保存的用户剪贴板内容，任务结束还原（P2-3）

    def user_moved_mouse(self, tol: int = 3) -> bool:
        """脚本自己移动后光标位置是已知的，若不一致说明用户介入。"""
        if not self.expected_pos:
            return False
        cur = km.cursor_pos()
        return abs(cur[0] - self.expected_pos[0]) > tol or abs(cur[1] - self.expected_pos[1]) > tol

    # ---------- 节奏 ----------
    def sleep(self, scale: float = 1.0):
        delay = _rand_range(self.behavior.get("step_delay", [1.2, 4.5])) * scale
        time.sleep(delay)
        return delay

    def pause(self, pair, default=(0.5, 1.5)):
        delay = _rand_range(pair, default)
        time.sleep(delay)
        return delay

    # ---------- 鼠标 ----------
    def move_to(self, x: int, y: int):
        if not self.curve:
            km.set_cursor(x, y)
            self.expected_pos = (int(x), int(y))
            return
        start = km.cursor_pos()
        steps = int(_rand_range(self.steps, (14, 30)))
        # 两个随机控制点，形成轻微弯曲的轨迹
        cx1 = start[0] + (x - start[0]) * random.uniform(0.1, 0.4) + random.uniform(-30, 30)
        cy1 = start[1] + (y - start[1]) * random.uniform(0.1, 0.4) + random.uniform(-30, 30)
        cx2 = start[0] + (x - start[0]) * random.uniform(0.6, 0.9) + random.uniform(-25, 25)
        cy2 = start[1] + (y - start[1]) * random.uniform(0.6, 0.9) + random.uniform(-25, 25)

        for i in range(1, steps + 1):
            t = i / steps
            mt = 1 - t
            px = mt ** 3 * start[0] + 3 * mt ** 2 * t * cx1 + 3 * mt * t ** 2 * cx2 + t ** 3 * x
            py = mt ** 3 * start[1] + 3 * mt ** 2 * t * cy1 + 3 * mt * t ** 2 * cy2 + t ** 3 * y
            km.set_cursor(px, py)
            time.sleep(random.uniform(0.004, 0.016))
        # 落点轻微抖动，避免每次像素级一致
        km.set_cursor(x + random.uniform(-3, 3), y + random.uniform(-3, 3))
        time.sleep(random.uniform(0.02, 0.08))
        km.set_cursor(x, y)
        self.expected_pos = (int(x), int(y))

    def click(self, x: int, y: int, button: str = "left"):
        self.move_to(x, y)
        time.sleep(random.uniform(0.05, 0.2))
        km.mouse_down(button)
        time.sleep(random.uniform(0.04, 0.1))
        km.mouse_up(button)
        self.expected_pos = (int(x), int(y))

    def double_click(self, x: int, y: int):
        self.click(x, y)
        time.sleep(random.uniform(0.08, 0.18))
        self.click(x, y)

    def wheel(self, clicks: int, x: int = None, y: int = None):
        """滚轮：正数向上、负数向下；给出坐标可先把鼠标移过去。"""
        if x is not None and y is not None:
            self.move_to(x, y)
            self.expected_pos = (int(x), int(y))
        km.wheel(clicks, x, y)

    # ---------- 键盘 ----------
    def hotkey(self, *names):
        km.combo(*names)
        time.sleep(random.uniform(0.08, 0.25))

    def press(self, name):
        km.press(name)
        time.sleep(random.uniform(0.08, 0.25))

    def paste(self, text: str):
        """中文一律走剪贴板，绕开输入法不确定性。

        剪贴板是系统级共享资源：首次写入前先保存用户原有内容，任务结束由
        restore_clipboard() 还原——否则用户之后任何一次粘贴都会带出自动消息内容
        （2026-09-19 审查 P2-3：既是体验问题，也存在把私聊内容粘到别处的泄露面）。
        """
        if self._clip_saved is None:
            try:
                self._clip_saved = pyperclip.paste()
            except Exception:
                self._clip_saved = ""
        pyperclip.copy(text)
        time.sleep(random.uniform(0.05, 0.15))
        km.combo("ctrl", "v")
        time.sleep(random.uniform(0.1, 0.3))

    def _split_segments(self, text: str):
        if not self.behavior.get("segment_paste", True):
            return [text]
        length = len(text)
        if length <= 12:
            return [text]
        parts, buf = [], ""
        for ch in text:
            buf += ch
            if ch in "，。！？；、\n" or len(buf) >= random.randint(8, 16):
                parts.append(buf)
                buf = ""
        if buf:
            parts.append(buf)
        return parts or [text]

    def restore_clipboard(self):
        """还原本次任务开始前的剪贴板内容（幂等，可重复调用）。"""
        if self._clip_saved is None:
            return
        saved, self._clip_saved = self._clip_saved, None
        try:
            pyperclip.copy(saved)
        except Exception:
            pass

    def type_text(self, text: str):
        """分段粘贴 + 随机停顿，模拟真人打字节奏；结束后还原剪贴板。"""
        segments = self._split_segments(text)
        for i, segment in enumerate(segments):
            self.paste(segment)
            if i < len(segments) - 1:
                self.pause(self.behavior.get("segment_delay", [0.5, 2.0]))
        time.sleep(random.uniform(0.3, 0.9))
        self.restore_clipboard()
