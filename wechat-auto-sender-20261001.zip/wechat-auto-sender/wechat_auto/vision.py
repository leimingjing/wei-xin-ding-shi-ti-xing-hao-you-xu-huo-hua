# -*- coding: utf-8 -*-
"""图像匹配兜底：当 UI 自动化识别不到控件时，用模板匹配定位 / 校验。"""
import os
import re

import numpy as np

_SAFE = re.compile(r'[\\/:*?"<>|\s]+')


def ref_path_for(root: str, name: str) -> str:
    """参考图路径的唯一权威实现（P2-2）：联系人名不可信，统一消毒后再拼路径。

    原实现散落在 vision / webapp / app 多处，各自用 name 直接拼
    assets\\refs\\{name}.png；名字里若含 \\ / : * ? " < > | 或 .. ，
    读写就会被引到 refs 目录之外（路径穿越）。现在收敛为一处：
    非法字符换成下划线、首尾的点与空格去掉、空名兜底 unnamed。
    """
    safe = _SAFE.sub("_", str(name or "")).strip("._ ")
    return os.path.join(root, "assets", "refs", f"{safe or 'unnamed'}.png")


def _to_bgr(image):
    arr = np.array(image.convert("RGB"))
    return arr[:, :, ::-1].copy()


def imread_bgr(path: str):
    """读图（BGR）。

    注意：不能用 cv2.imread —— 它在**中文路径**下会静默返回 None，
    参考图（按联系人命名，含中文）会因此永远读不到。这里统一走 PIL。
    """
    try:
        from PIL import Image

        with Image.open(path) as image:
            return np.array(image.convert("RGB"))[:, :, ::-1].copy()
    except Exception:
        return None


def imwrite_bgr(path: str, image) -> bool:
    """写图。同样要走 PIL，cv2.imwrite 在中文路径下会静默失败（返回 False 且不报错）。"""
    try:
        from PIL import Image

        Image.fromarray(np.asarray(image)[:, :, ::-1]).save(path)
        return True
    except Exception:
        return False


class Vision:
    def __init__(self, root: str, logger=None, threshold: float = 0.85):
        self.root = root
        self.logger = logger
        self.threshold = threshold
        self.ref_dir = os.path.join(root, "assets", "refs")
        self.tpl_dir = os.path.join(root, "assets", "templates")
        os.makedirs(self.ref_dir, exist_ok=True)
        os.makedirs(self.tpl_dir, exist_ok=True)
        # 最近一次标题参考图比对的相似度，供上层展示/记录
        self.last_score = None

    def _cv2(self):
        import cv2

        return cv2

    def grab(self, region=None):
        """region = (left, top, width, height)"""
        from PIL import ImageGrab

        if region:
            left, top, width, height = region
            image = ImageGrab.grab(bbox=(left, top, left + width, top + height), all_screens=True)
        else:
            image = ImageGrab.grab(all_screens=True)
        return _to_bgr(image)

    # ---------- 联系人标题参考图 ----------
    def ref_path(self, name: str) -> str:
        return ref_path_for(self.root, name)

    def has_ref(self, name: str) -> bool:
        return os.path.isfile(self.ref_path(name))

    def save_ref(self, name: str, region) -> str:
        path = self.ref_path(name)
        if not imwrite_bgr(path, self.grab(region)):
            raise RuntimeError(f"参考图写入失败：{path}")
        return path

    def compare_ref(self, name: str, region, threshold: float = None) -> bool:
        path = self.ref_path(name)
        if not os.path.isfile(path):
            return False
        cv2 = self._cv2()
        threshold = threshold if threshold is not None else 0.9
        ref = imread_bgr(path)
        screen = self.grab(region)
        if ref is None or screen is None:
            return False
        if ref.shape[0] != screen.shape[0] or ref.shape[1] != screen.shape[1]:
            # 尺寸不符直接判负会让“点对人也恒失败”，进而把流程推回重搜循环；
            # 改为等比缩放到可匹配范围后再比对，差异过大才跳过。
            scale = min(screen.shape[0] / ref.shape[0], screen.shape[1] / ref.shape[1])
            if scale < 0.5 or scale > 2.0:
                if self.logger:
                    self.logger.warning(
                        f"参考图尺寸 {ref.shape[1]}x{ref.shape[0]} 与屏幕区 "
                        f"{screen.shape[1]}x{screen.shape[0]} 差异过大，跳过比对"
                    )
                return False
            ref = cv2.resize(ref, (int(ref.shape[1] * scale), int(ref.shape[0] * scale)))
        result = cv2.matchTemplate(screen, ref, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, _ = cv2.minMaxLoc(result)
        self.last_score = float(max_val)
        if self.logger:
            self.logger.info(f"标题区图像比对相似度 {max_val:.3f}（阈值 {threshold}）")
        return max_val >= threshold

    @staticmethod
    def diff_ratio(before, after, noise: int = 24) -> float:
        """比较两张图的变化比例，用于发送前后的内容区比对。

        noise：单个像素被判为「变化」的灰度差下限（默认 24）。
        旧签名里的 threshold=0.02 从未被使用（无效参数，改它没有任何效果），
        现替换为真正生效的 noise；是否算「发送成功」由调用方按
        config.yaml 的 safety.message_diff_threshold 判定（2026-09-19 修复 P3-4）。
        """
        if before is None or after is None:
            return 0.0
        if before.shape != after.shape:
            return 0.0
        cv2 = None
        try:
            import cv2 as _cv2

            cv2 = _cv2
        except Exception:
            return 0.0
        delta = cv2.absdiff(before, after)
        gray = cv2.cvtColor(delta, cv2.COLOR_BGR2GRAY)
        changed = int((gray > noise).sum())
        return changed / max(1, gray.size)

    # ---------- 通用模板定位 ----------
    def locate(self, template_name: str, region=None, threshold: float = None):
        cv2 = self._cv2()
        path = template_name if os.path.isabs(template_name) else os.path.join(self.tpl_dir, template_name)
        if not os.path.isfile(path):
            return None
        template = imread_bgr(path)
        screen = self.grab(region)
        if template is None or screen is None:
            return None
        if template.shape[0] > screen.shape[0] or template.shape[1] > screen.shape[1]:
            return None
        threshold = threshold if threshold is not None else self.threshold
        result = cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)
        if max_val < threshold:
            return None
        offset_x, offset_y = (region[0], region[1]) if region else (0, 0)
        h, w = template.shape[:2]
        return (offset_x + max_loc[0] + w // 2, offset_y + max_loc[1] + h // 2, max_val)
