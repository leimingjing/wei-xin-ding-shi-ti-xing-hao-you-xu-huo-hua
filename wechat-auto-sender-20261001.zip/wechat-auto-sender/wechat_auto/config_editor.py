# -*- coding: utf-8 -*-
"""config.yaml 的文本级安全编辑：改值不丢注释。

为什么不直接 yaml.dump：pyyaml 重写文件会把多年的使用说明注释全部抹掉，
而这份注释本身就是操作手册（实测要点、首次使用四步）。

策略：只动"必须动"的行——
- 标量：在 section 块内定位 `  key: old` 行，只替换值部分（保留行内尾注释）；
- 列表（schedule.times / weekdays）：替换 key 下连续的 `- x` 行；
- targets：整块替换为带标准注释的模板（结构固定，逐行动态补丁反而脆弱）。

每次编辑后先用 yaml.safe_load 验证仍可解析、关键字段存在，验证不过就不落盘。
"""
from __future__ import annotations

import os
import re
import tempfile

import yaml


class ConfigEditError(Exception):
    """编辑失败：找不到锚点、解析失败或校验不过，文件不会被改动。"""


# ---------- 基础 ----------

def _read(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read()
    except OSError as exc:
        raise ConfigEditError(f"读取配置失败：{exc}") from None


def _write_atomic(path: str, text: str):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path) or ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except Exception:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise


def _fmt(value) -> str:
    """按 yaml 习惯输出标量。"""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    # 统一走双引号，转义反斜杠（Windows 路径），避免歧义
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


# ---------- section 定位 ----------

def _section_range(text: str, section: str):
    """返回 section 块的 [起始行号, 结束行号)（顶格 `section:` 到下一个顶格 key 之前）。"""
    lines = text.split("\n")
    start = None
    for i, line in enumerate(lines):
        if re.match(rf"^{section}:\s*$", line):
            start = i
            break
    if start is None:
        raise ConfigEditError(f"配置里找不到段 `{section}:`")
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if lines[j] and not lines[j][0].isspace() and not lines[j].startswith("#"):
            end = j
            break
    return lines, start, end


# ---------- 标量 ----------

def set_scalar(text: str, section: str, key: str, value) -> str:
    """替换 section 块内的 `  key: old` 为新值。支持 bool/int/float/str/list(inline)。"""
    lines, start, end = _section_range(text, section)
    pat = re.compile(rf"^(\s+){re.escape(key)}:\s*(.*)$")
    for i in range(start + 1, end):
        m = pat.match(lines[i])
        if not m:
            continue
        indent, old_value = m.group(1), m.group(2)
        # 保留行内尾注释（` # ...`）
        comment = ""
        hash_at = old_value.find(" #")
        if hash_at >= 0:
            comment = old_value[hash_at:]
        if isinstance(value, list):
            rendered = "[" + ", ".join(_fmt(v) for v in value) + "]"
        else:
            rendered = _fmt(value)
        lines[i] = f"{indent}{key}: {rendered}" + (f"  {comment}" if comment else "")
        return "\n".join(lines)
    raise ConfigEditError(f"`{section}:` 段里找不到键 `{key}`")


def get_scalar(text: str, section: str, key: str):
    lines, start, end = _section_range(text, section)
    pat = re.compile(rf"^\s+{re.escape(key)}:\s*(.+)$")
    for i in range(start + 1, end):
        m = pat.match(lines[i])
        if m:
            raw = m.group(1)
            hash_at = raw.find(" #")
            if hash_at >= 0:
                raw = raw[:hash_at]
            try:
                return yaml.safe_load(raw)
            except yaml.YAMLError:
                return raw.strip().strip('"').strip("'")
    raise ConfigEditError(f"`{section}:` 段里找不到键 `{key}`")


# ---------- 列表（块状） ----------

def set_block_list(text: str, section: str, key: str, values: list) -> str:
    """替换 `  key:` 下连续的 `- x` 块。空列表写成 `key: []`。"""
    lines, start, end = _section_range(text, section)
    pat = re.compile(rf"^(\s+){re.escape(key)}:\s*(.*)$")
    for i in range(start + 1, end):
        m = pat.match(lines[i])
        if not m:
            continue
        indent, old_inline = m.group(1), m.group(2).strip()
        # 收集该 key 之后连续的列表项行（比 key 多一层缩进）
        item_indent = indent + "  "
        j = i + 1
        while j < len(lines) and lines[j].startswith(item_indent + "- "):
            j += 1
        has_block = j > i + 1
        if not values:
            new_lines = [f"{indent}{key}: []"]
        elif has_block:
            new_lines = [f"{indent}{key}:"] + [f"{item_indent}- {_fmt(v)}" for v in values]
        else:
            new_lines = [f"{indent}{key}: [" + ", ".join(_fmt(v) for v in values) + "]"]
        lines[i:j] = new_lines
        return "\n".join(lines)
    raise ConfigEditError(f"`{section}:` 段里找不到键 `{key}`")


# ---------- targets 整块替换 ----------

_TARGET_TEMPLATE = """\
targets:
  # 可配置多个联系人，每个联系人可单独指定时间点
{entries}
"""

_ENTRY_TEMPLATE = """\
  - name: {name}            # 微信里的备注名，必须完全一致
    enabled: {enabled}
    # 首次必须先跑 dry_run 演练、人工核对截图确认后，再改为 true
    approved: {approved}
{contact_id}    # 留空 = 使用全局 schedule.times；填写则只在这些时间点发送
    times: {times}
    # 支持变量：{{name}} {{date}} {{weekday}} {{time}} {{greeting}}
    messages:
{messages}
"""


def _format_target(t: dict) -> str:
    name = t.get("name") or ""
    if not name or len(name) > 60 or any(c in name for c in '\n\r"'):
        raise ConfigEditError(f"联系人名不合法：{name!r}")
    times = "[" + ", ".join(f'"{x}"' for x in (t.get("times") or [])) + "]"
    messages = t.get("messages") or []
    if not messages:
        raise ConfigEditError(f"联系人 {name} 至少需要一条消息模板")
    msg_lines = "\n".join(f'      - {_fmt(m)}' for m in messages)
    # 关联联系人（可选）：有 id 才写行，保持老配置的 YAML 干净不动
    cid = str(t.get("contact_id") or "").strip()
    contact_line = (
        f"    contact_id: {_fmt(cid)}   # 关联「联系人」管理台的稳定 id，改名自动同步\n"
        if cid else ""
    )
    return _ENTRY_TEMPLATE.format(
        name=_fmt(name), enabled=_fmt(bool(t.get("enabled"))),
        approved=_fmt(bool(t.get("approved"))), contact_id=contact_line,
        times=times, messages=msg_lines,
    )


def replace_targets(text: str, targets: list) -> str:
    """整块替换 targets: 段（保留段外的全部注释）。"""
    lines, start, end = _section_range(text, "targets")
    entries = "\n".join(_format_target(t) for t in targets)
    block = _TARGET_TEMPLATE.format(entries=entries if entries else "  []")
    if not targets:
        block = "targets: []\n"
    new_lines = lines[:start] + block.rstrip("\n").split("\n") + lines[end:]
    return "\n".join(new_lines)


# ---------- 对外主入口 ----------

def edit_config(path: str, mutate, verify):
    """读原文 → mutate(text) 改文本 → verify(dict) 校验 → 原子落盘。

    mutate: fn(text) -> new_text（失败抛 ConfigEditError，文件不动）
    verify: fn(data_dict)（抛异常则拒绝落盘）
    """
    text = _read(path)
    new_text = mutate(text)
    if new_text == text:
        return False  # 无变化
    try:
        data = yaml.safe_load(new_text)
    except yaml.YAMLError as exc:
        raise ConfigEditError(f"编辑后的配置无法解析，已拒绝写入：{exc}") from None
    if not isinstance(data, dict):
        raise ConfigEditError("编辑后的配置不是合法结构，已拒绝写入")
    verify(data)
    _write_atomic(path, new_text)
    return True


def config_targets(data: dict) -> list:
    return data.get("targets") or []
