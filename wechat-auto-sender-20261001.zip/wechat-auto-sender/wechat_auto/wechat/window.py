# -*- coding: utf-8 -*-
"""微信窗口管理：探测、拉起、激活。只使用标准 Win32 API。"""
import ctypes
import os
import string
import subprocess
import time

import uiautomation as auto
import win32con
import win32gui
import win32process

TARGET_PROCS = ("wechat.exe", "weixin.exe")
# 微信内置浏览器 / 小程序宿主进程：这些窗口会盖住主窗口，属于“遮挡窗口”
OVERLAY_PROCS = ("wechatappex.exe", "weixin.exe", "wechat.exe")
# 微信 4.x 的窗口类名以 mmui:: 开头（如 mmui::MainWindow / mmui::LoginWindow）
CLASS_HINTS = ("wechat", "weixin", "mmui")
LOGIN_HINTS = ("loginwindow", "login")

_pid_cache = {}
# 缓存上界：pid 会被系统复用，缓存里如果留着已退出进程的旧名字，就会把新进程误判成
# "微信/其它"，进而影响窗口筛选。超过上限时先剔除已退出的 pid，仍超限则整体清空。
_PID_CACHE_LIMIT = 128


def _sweep_pid_cache():
    """剔除已退出进程的缓存条目（P3-4：原实现无上界、且 pid 复用会读到过期名字）。"""
    for pid in list(_pid_cache):
        handle = 0
        try:
            handle = ctypes.windll.kernel32.OpenProcess(
                win32con.PROCESS_QUERY_INFORMATION, False, pid
            )
        except Exception:
            handle = 0
        if handle:
            try:
                ctypes.windll.kernel32.CloseHandle(handle)
            except Exception:
                pass
        else:
            _pid_cache.pop(pid, None)


def _wechat_process_running() -> bool:
    """是否已有微信进程在运行（P3-1：避免重试时反复 Popen 多开并抢前台）。"""
    try:
        for pid in win32process.EnumProcesses():
            if pid and _proc_name(pid) in TARGET_PROCS:
                return True
    except Exception:
        pass
    return False


def _proc_name(pid: int) -> str:
    if pid in _pid_cache:
        return _pid_cache[pid]
    name = ""
    try:
        handle = ctypes.windll.kernel32.OpenProcess(
            win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_READ, False, pid
        )
        if handle:
            try:
                name = os.path.basename(win32process.GetModuleFileNameEx(handle, 0)).lower()
            finally:
                ctypes.windll.kernel32.CloseHandle(handle)
    except Exception:
        name = ""
    if len(_pid_cache) >= _PID_CACHE_LIMIT:
        _sweep_pid_cache()
        if len(_pid_cache) >= _PID_CACHE_LIMIT:
            _pid_cache.clear()
    _pid_cache[pid] = name
    return name


# 微信 4.x 的辅助窗口，全部排除
CLASS_BLACKLIST = (
    "ime",
    "msctfime ui",
    "sopy_",
    "base_powermessagewindow",
    "displayicc_systemmessagewindow",
    "chrome_systemmessagewindow",
    "trayicon",
    "sogou_tsf_ui",
    "default ime",
)


def _enum_top_windows():
    """用 EnumWindows 枚举顶层窗口，比 UI 自动化遍历快得多。

    注意：不能依赖 IsWindowVisible——微信最小化到托盘时该值为 0。
    """
    hwnds = []

    def callback(hwnd, _):
        try:
            if win32gui.GetParent(hwnd) != 0:
                return True
            if win32gui.GetWindow(hwnd, win32con.GW_OWNER) != 0:
                return True
        except Exception:
            return True
        hwnds.append(hwnd)
        return True

    win32gui.EnumWindows(callback, None)
    return hwnds


def _registry_exe():
    candidates = []
    try:
        import winreg

        for root, path in (
            (winreg.HKEY_CURRENT_USER, r"Software\Tencent\WeChat"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Tencent\WeChat"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Tencent\WeChat"),
        ):
            try:
                key = winreg.OpenKey(root, path)
            except OSError:
                continue
            for value in ("InstallPath", "InstallLocation", "Path"):
                try:
                    val, _ = winreg.QueryValueEx(key, value)
                except OSError:
                    continue
                if not val:
                    continue
                if os.path.isdir(val):
                    candidates.append(os.path.join(val, "WeChat.exe"))
                elif os.path.isfile(val):
                    candidates.append(val)
    except Exception:
        pass
    return candidates


def _uninstall_exe():
    """从卸载表查找，兼容性最好（微信 4.x 常见）。"""
    candidates = []
    try:
        import winreg

        roots = (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER)
        paths = (
            r"Software\Microsoft\Windows\CurrentVersion\Uninstall",
            r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
        )
        for root in roots:
            for path in paths:
                for flag in (0, winreg.KEY_WOW64_32KEY):
                    try:
                        key = winreg.OpenKey(root, path, 0, winreg.KEY_READ | flag)
                    except OSError:
                        continue
                    index = 0
                    while True:
                        try:
                            sub = winreg.EnumKey(key, index)
                            index += 1
                        except OSError:
                            break
                        try:
                            subkey = winreg.OpenKey(key, sub)
                            display, _ = winreg.QueryValueEx(subkey, "DisplayName")
                        except OSError:
                            continue
                        if not any(t in str(display) for t in ("微信", "WeChat", "Weixin")):
                            continue
                        for value in ("DisplayIcon", "InstallLocation"):
                            try:
                                val, _ = winreg.QueryValueEx(subkey, value)
                            except OSError:
                                continue
                            val = str(val).strip().strip('"').split(",")[0].strip()
                            if os.path.isfile(val):
                                candidates.append(val)
                            elif os.path.isdir(val):
                                for exe in ("Weixin.exe", "WeChat.exe"):
                                    full = os.path.join(val, exe)
                                    if os.path.isfile(full):
                                        candidates.append(full)
    except Exception:
        pass
    return candidates


def _common_exe():
    env = os.environ
    roots = [
        env.get("ProgramFiles(x86)", ""),
        env.get("ProgramFiles", ""),
        env.get("LOCALAPPDATA", ""),
        env.get("APPDATA", ""),
    ]
    out = []
    for root in roots:
        if not root:
            continue
        out.append(os.path.join(root, "Tencent", "WeChat", "WeChat.exe"))
    # 微信 4.x 常装在盘符根目录
    for letter in string.ascii_uppercase:
        for folder, exe in (("Weixin", "Weixin.exe"), ("WeChat", "WeChat.exe"), ("微信", "Weixin.exe")):
            path = os.path.join(f"{letter}:\\", folder, exe)
            if os.path.isfile(path):
                out.append(path)
    return out


class _WorkArea(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def work_area():
    """主屏工作区矩形（不含任务栏），(left, top, right, bottom)。"""
    rect = _WorkArea()
    ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rect), 0)  # SPI_GETWORKAREA
    return (rect.left, rect.top, rect.right, rect.bottom)


def ensure_on_screen(hwnd, log=None) -> bool:
    """窗口完整落在屏幕工作区内；越界则拉回来，返回是否移动过。

    场景：从最小化还原 / 换过显示器或分辨率后，微信会恢复到历史位置，
    结果标题栏的关闭、最小化按钮落在屏幕之外，用户点不到 —— 表现为
    “关不掉、缩不小”，像是被锁死，其实是窗口跑到屏幕外了（2026-09-13 实际遇到）。
    自动执行前后都该调用一次，保证用户随时能操作窗口。
    """
    if not hwnd:
        return False
    try:
        if win32gui.IsIconic(hwnd):        # 最小化时矩形是占位值，不做判断
            return False
        left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    except Exception:
        return False

    wl, wt, wr, wb = work_area()
    if wr - wl < 200 or wb - wt < 200:     # 取不到合理工作区就别乱动
        return False

    width, height = right - left, bottom - top
    new_w, new_h = min(width, wr - wl), min(height, wb - wt)
    new_x = min(max(left, wl), max(wl, wr - new_w))
    new_y = min(max(top, wt), max(wt, wb - new_h))
    if (new_x, new_y, new_w, new_h) == (left, top, width, height):
        return False
    try:
        win32gui.SetWindowPos(
            hwnd, 0, new_x, new_y, new_w, new_h,
            win32con.SWP_NOZORDER | win32con.SWP_NOACTIVATE,
        )
        if log:
            log(f"窗口有部分在屏幕外，已拉回可见区：({left}, {top}) {width}x{height}"
                f" → ({new_x}, {new_y}) {new_w}x{new_h}")
        return True
    except Exception:
        return False


class WeChatWindow:
    def __init__(self, cfg: dict, logger):
        self.cfg = cfg or {}
        self.logger = logger
        self.control = None
        self._was_minimized = False
        self._prev_foreground = None

    # ---------- 查找 ----------
    def _score_windows(self):
        """在微信进程的所有顶层窗口中挑出主窗口（按打分）。"""
        cls_hint = (self.cfg.get("window_class") or "").strip().lower()
        best = None
        for hwnd in _enum_top_windows():
            try:
                class_name = win32gui.GetClassName(hwnd) or ""
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
            except Exception:
                continue
            if _proc_name(pid) not in TARGET_PROCS:
                continue
            low = class_name.lower()
            if any(b in low for b in CLASS_BLACKLIST):
                continue
            try:
                r = win32gui.GetWindowRect(hwnd)
            except Exception:
                continue
            width, height = r[2] - r[0], r[3] - r[1]
            if width < 300 or height < 200:
                # 微信最小化（含最小化到托盘）时 GetWindowRect 返回占位小矩形，
                # 主窗口会被尺寸过滤误杀 → 改用「还原后的位置」判断。
                normal = None
                try:
                    if win32gui.IsIconic(hwnd):
                        normal = win32gui.GetWindowPlacement(hwnd)[4]
                except Exception:
                    normal = None
                if normal:
                    width, height = normal[2] - normal[0], normal[3] - normal[1]
                if width < 300 or height < 200:
                    continue
            try:
                title = win32gui.GetWindowText(hwnd) or ""
            except Exception:
                title = ""

            score = width * height / 1_000_000.0
            if "微信" in title or "wechat" in title.lower() or "weixin" in title.lower():
                score += 100
            if "mmui" in low:
                score += 50
            if "qwindow" in low:
                score += 20
            if cls_hint and cls_hint in low:
                score += 50
            if "login" in low:
                score -= 60
            if best is None or score > best[0]:
                best = (score, hwnd, class_name)
        return best

    def find(self, timeout: float = 3.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            best = self._score_windows()
            if best:
                hwnd, class_name = best[1], best[2]
                control = None
                try:
                    control = auto.ControlFromHandle(hwnd)
                except Exception:
                    control = None
                if control is None:
                    try:
                        candidate = auto.WindowControl(searchDepth=1, ClassName=class_name)
                        if candidate.Exists(maxSearchSeconds=1):
                            control = candidate
                    except Exception:
                        control = None
                if control:
                    return control
            time.sleep(0.5)
        return None

    def _locate_exe(self):
        configured = (self.cfg.get("exe_path") or "").strip()
        if configured and os.path.isfile(configured):
            return configured
        for path in _uninstall_exe() + _registry_exe() + _common_exe():
            if path and os.path.isfile(path):
                return path
        return None

    @staticmethod
    def _is_login(control) -> bool:
        try:
            cls = (control.ClassName or "").lower()
        except Exception:
            return False
        return any(h in cls for h in LOGIN_HINTS)

    def is_login_window(self) -> bool:
        return bool(self.control) and self._is_login(self.control)

    # ---------- 生命周期 ----------
    def ensure_running(self):
        """确保拿到可用的主窗口。

        注意：微信冷启动会先闪出一个登录/加载窗口，必须等主窗口出现再继续，
        否则会把登录窗口当成主窗口。
        """
        control = self.find(timeout=3)
        launched = False
        if not control or self._is_login(control):
            exe = self._locate_exe()
            if not exe:
                raise RuntimeError("未找到微信可执行文件，请在 config.yaml 的 wechat.exe_path 中手动指定")
            # P3-1：微信进程其实还在（最小化到托盘、或停在登录页）时再 Popen 只会多开一个
            # 实例并反复抢前台——9-19 凌晨的"未登录"就是这样被放大成 3 人 × 3 轮的空转与打扰。
            if _wechat_process_running():
                self.logger.info("检测到微信进程已在运行，不再重复拉起，等待其窗口就绪")
            else:
                self.logger.info(f"启动/唤醒微信：{exe}")
                subprocess.Popen([exe], shell=False)
                launched = True

        timeout = float(self.cfg.get("launch_timeout", 40))
        deadline = time.time() + timeout
        last = None
        while time.time() < deadline:
            last = self.find(timeout=1)
            if last and not self._is_login(last):
                self.control = last
                time.sleep(2.0 if launched else 0.5)
                return self.control
            time.sleep(0.5)

        self.control = last
        if last is not None and self._is_login(last):
            raise RuntimeError("微信停留在登录窗口，请先手动登录并保持在线")
        raise RuntimeError(f"{timeout} 秒内未取得微信主窗口，请手动打开微信后重试")

    # ---------- 激活 ----------
    def activate(self) -> bool:
        if not self.control:
            return False
        hwnd = self.control.NativeWindowHandle
        if not hwnd:
            return False
        self._prev_foreground = ctypes.windll.user32.GetForegroundWindow()

        self._was_minimized = False
        try:
            win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
            placement = win32gui.GetWindowPlacement(hwnd)
            self._was_minimized = placement[1] == win32con.SW_SHOWMINIMIZED
            if self._was_minimized:
                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            time.sleep(0.6)
        except Exception:
            pass

        # 还原/显示后窗口可能落在屏幕之外（历史位置残留、换过显示器或分辨率），
        # 标题栏的关闭与最小化按钮会跟着跑到屏幕外，用户点不到 —— 先拉回可见区。
        ensure_on_screen(hwnd, getattr(self.logger, "info", None))

        user32 = ctypes.windll.user32
        for _ in range(3):
            try:
                win32gui.SetForegroundWindow(hwnd)
            except Exception:
                pass
            time.sleep(0.4)
            if user32.GetForegroundWindow() == hwnd:
                self.logger.info("微信窗口已激活到前台")
                return True
            # 兜底：借助 Alt 键绕过前台锁定
            user32.keybd_event(0x12, 0, 0, 0)
            user32.keybd_event(0x12, 0, 0x0002, 0)
            time.sleep(0.3)
        self.logger.warning("微信窗口激活失败，后续操作可能不可靠")
        return False

    def restore(self):
        """尽量恢复到执行前的窗口状态。

        无论执行成败都要保证用户能正常操作微信：只要窗口完整落在屏幕内，
        关闭/最小化按钮就点得到（见 ensure_on_screen 的场景说明）。

        P3-4：`_prev_foreground` 过去只写不读（死字段）。这里让它真正发挥作用——
        把前台焦点还给执行前用户正在用的窗口，避免任务结束后微信一直霸占前台
        （半夜醒来第一眼看到聊天窗口，容易引起误会）。
        """
        try:
            if self.control:
                hwnd = self.control.NativeWindowHandle
                ensure_on_screen(hwnd, getattr(self.logger, "info", None))
                if self._was_minimized:
                    win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
        except Exception:
            pass
        prev = self._prev_foreground
        self._prev_foreground = None
        if prev:
            try:
                if prev != win32gui.GetForegroundWindow():
                    win32gui.SetForegroundWindow(prev)
            except Exception:
                # 前台锁定（Windows 限制后台进程抢焦点）时静默放弃，不影响任务结果
                pass

    # ---------- 微信内置窗口（内置浏览器 / 小程序）----------
    def overlay_windows(self):
        """列出微信内置的 CEF 窗口（内置浏览器、小程序），不含主窗口。"""
        out = []

        def callback(hwnd, _):
            try:
                if not win32gui.IsWindowVisible(hwnd):
                    return True
                cls = win32gui.GetClassName(hwnd)
                if cls not in ("Chrome_WidgetWin_0", "Chrome_WidgetWin_1"):
                    return True
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                if _proc_name(pid) not in OVERLAY_PROCS:
                    return True
                out.append(hwnd)
            except Exception:
                pass
            return True

        win32gui.EnumWindows(callback, None)
        return out

    def overlay_snapshot(self):
        """执行前记录已有的内置窗口，便于只关掉“本次执行期间新弹出来的”。"""
        return set(self.overlay_windows())

    def close_new_overlays(self, before):
        """关掉本次执行期间新出现的微信内置窗口（如误点「搜索网络结果」弹出的网页）。"""
        closed = []
        for hwnd in self.overlay_windows():
            if hwnd in (before or set()):
                continue
            try:
                win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                closed.append(hwnd)
            except Exception:
                pass
        return closed

    @property
    def rect(self):
        if not self.control:
            return None
        return self.control.BoundingRectangle

    # ---------- 位置稳定性 ----------
    def snapshot_rect(self):
        """实时读取窗口矩形，用于检测窗口是否被拖动/缩放（比例坐标会因此失效）。"""
        if not self.control:
            return None
        try:
            r = self.control.BoundingRectangle
            return (int(r.left), int(r.top), int(r.width()), int(r.height()))
        except Exception:
            return None

    @staticmethod
    def rect_moved(a, b, tol: int = 4) -> bool:
        if not a or not b or len(a) != len(b):
            return False
        return any(abs(int(x) - int(y)) > tol for x, y in zip(a, b))
