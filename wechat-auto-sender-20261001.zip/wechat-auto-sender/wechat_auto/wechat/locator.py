# -*- coding: utf-8 -*-
"""控件定位。

微信 4.x 是 Qt 应用，不暴露 UI 自动化控件树（实测主窗口只有 1~2 个节点），
因此这里以「坐标点击 + 键盘 + 图像匹配」为主：
  - 坐标：搜索框 / 输入框 / 标题区 / 消息区，见下面两种定位模型
  - 键盘：Ctrl+V 粘贴中文、Enter 打开结果或发送、Esc 关闭面板
  - 图像：会话标题区与参考图比对，确保没有找错人

两种定位模型（layout 优先，ratios 为旧配置兼容回退）：
  1) layout：以**窗口边缘**为基准的像素偏移，窗口被拖动/缩放都不会跑偏。
     实测于 1645x1006 的窗口（显示缩放 150%），单位为物理像素。
       x: {left: 距左边缘} / {right: 距右边缘}；两边都给 = 该区间的左右界
       y: {top: 距上边缘} / {bottom: 距下边缘}
     点元素每轴只给一边（给两边则取中点）；矩形元素每轴给两边。
  2) ratios：相对窗口宽高的比例（旧配置），仅当 layout 里没有该元素时使用。
"""
import random
import time

from ..vision import Vision

# 旧版比例模型（保留兼容）
DEFAULT_RATIOS = {
    "search_box": [0.135, 0.062],
    "input_box": [0.600, 0.940],
    "title_band": [0.240, 0.035, 0.360, 0.060],
    "message_area": [0.240, 0.100, 0.700, 0.780],
}

# 锚定偏移模型：2026-09-12 在本机实测（窗口 1645x1006，显示缩放 150%）
# 若更换显示器/缩放比例，请重跑 tools/calibrate.py 并修正这里的数值
#
# 取值方式：left/top 给起点，right/bottom 给“距末端”的偏移（两边都写 = 随窗口拉伸），
# width/height 给**固定尺寸**（配合 left/top 用，不随窗口缩放变化）。
DEFAULT_LAYOUT = {
    # 搜索框中心（实测矩形 x 120~387、y 64~103）
    "search_box": {"x": {"left": 253}, "y": {"top": 83}},
    # 搜索框下方的候选面板（实测面板区 x107~609, y91~929）
    # 右边界必须**贴着搜索面板的右沿**：留太宽会把右侧聊天区的内容也算进来，
    # 导致「行右侧是否有时间戳」的判断全部误判（联系人行被误杀）。
    "search_results": {"x": {"left": 100, "right": 1065}, "y": {"top": 88, "bottom": 75}},
    # 会话标题区：含联系人名，用于与参考图比对（实测文字 y 73~91、起点 x≈493）
    # ⚠ 必须用固定 height：标题条本身是定高横条，若写成 top+bottom 拉伸，
    #   窗口一旦变矮（1006→988）裁出来的条就只剩 24px，比参考图(42px)还矮，
    #   compare_ref 会直接判 False → 误报「找错人」。已踩过一次。
    "title_band": {"x": {"left": 475, "right": 445}, "y": {"top": 62, "height": 42}},
    # 消息内容区：上到标题下方，下到输入框上沿（实测输入框 y 779~975）
    "message_area": {"x": {"left": 461, "right": 25}, "y": {"top": 100, "bottom": 231}},
    # 消息输入框中心（实测矩形 x 472~1614、y 779~975）
    "input_box": {"x": {"left": 1043}, "y": {"bottom": 129}},
}


def rect_tuple(control):
    """把 uiautomation 的 Rect 转成 (left, top, width, height)。"""
    r = control.BoundingRectangle
    return (int(r.left), int(r.top), int(r.width()), int(r.height()))


def avatar_mask(img):
    """搜索面板里的「头像前景掩码」（find_contact_rows 与 tools/test_row_filter.py 共用）。

    双通道取并集，再限定在左侧头像列：
      a. HSV 彩色通道（s>60 且 v>60）——彩色头像/图标；
      b. 底色对比度通道——与面板纯色底的逐像素色差 >90。
        头像不一定是彩色图（白底人像、黑白合影饱和度很低，纯 HSV 会漏检：
        2026-09-13 实测「示例联系人A」头像只有 8% 像素过得了 s>60）。
        文字虽然也是前景，但高度 <30 会被后续轮廓过滤掉。
    """
    try:
        import cv2
        import numpy as np
    except Exception:
        return None
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    _, s, v = cv2.split(hsv)
    colorful = ((s > 60) & (v > 60)).astype(np.uint8) * 255
    bg = np.median(img.reshape(-1, 3), axis=0)
    contrast = np.abs(img.astype(np.int16) - bg.reshape(1, 1, 3)).sum(axis=2)
    foreground = (contrast > 90).astype(np.uint8) * 255
    mask = cv2.bitwise_or(colorful, foreground)
    keep = np.zeros_like(mask)
    keep[:, 30:150] = 255
    mask = cv2.bitwise_and(mask, keep)
    return cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((11, 11), np.uint8))


class WeChatLocator:
    def __init__(self, window_rect, human, logger, vision=None, cfg=None, verify_mode="strict"):
        self.rect = tuple(window_rect)
        self.human = human
        self.logger = logger
        self.vision = vision
        self.verify_mode = (verify_mode or "strict").lower()

        cfg = cfg or {}
        self.ratios = dict(DEFAULT_RATIOS)
        self.ratios.update(cfg.get("ratios") or {})
        self.layout = {k: dict(v) for k, v in DEFAULT_LAYOUT.items()}
        for key, spec in (cfg.get("layout") or {}).items():
            if isinstance(spec, dict):
                self.layout[key] = spec
        self.search_hotkey = tuple((cfg.get("search_hotkey") or "ctrl+f").lower().split("+"))
        self.cfg_search_click = bool(cfg.get("search_click", False))
        # 最近一次“面板开着时”的截图，用于判断面板是否还开着
        self._panel_img = None
        # 最近一次 filter_contact_rows 的分类结果：True=纯联系人行（与返回列表对齐）
        self._row_flags = []
        # 第一次 grab_results_area 的结果缓存，用于 panel_open(baseline=None) 场景：
        # 调用方没传 baseline 时，用最近一次面板内容作为基线，避免把「面板刚打开」误判为关着。

    # ---------- 坐标换算 ----------
    def _span(self, spec, start, end):
        """把 {left/right} 或 {top/bottom} 解析成绝对区间；只给一边时两端相同。

        另外支持固定尺寸：
        - ``{"left": 475, "width": 725}`` → [start+475, start+475+725]
        - ``{"top": 62, "height": 42}``   → [start+62, start+62+42]

        固定尺寸对**定高/定宽**的元素必须用（例如会话标题条）：写成
        top+bottom 会随窗口高度拉伸，窗口一变矮裁出来的条就比参考图还小，
        比对必然失败（表现为误报「找错人」）。
        """
        lo = hi = None
        if "left" in spec:
            lo = start + float(spec["left"])
        elif "top" in spec:
            lo = start + float(spec["top"])
        fixed = spec.get("width") if "width" in spec else spec.get("height")
        if fixed is not None:
            if lo is None:
                return None
            return (lo, lo + float(fixed))
        if "right" in spec:
            hi = end - float(spec["right"])
        elif "bottom" in spec:
            hi = end - float(spec["bottom"])
        if lo is None:
            lo = hi
        if hi is None:
            hi = lo
        if lo is None:
            return None
        return (lo, hi)

    def _layout_span(self, key):
        spec = self.layout.get(key) or {}
        xs, ys = spec.get("x"), spec.get("y")
        if not xs or not ys:
            return None
        left, top, width, height = self.rect
        return self._span(xs, left, left + width), self._span(ys, top, top + height)

    def point(self, key):
        span = self._layout_span(key)
        if span:
            (x0, x1), (y0, y1) = span
            return (int((x0 + x1) / 2), int((y0 + y1) / 2))
        rx, ry = self.ratios[key][:2]
        left, top, width, height = self.rect
        return (int(left + width * rx), int(top + height * ry))

    def band(self, key):
        span = self._layout_span(key)
        if span:
            (x0, x1), (y0, y1) = span
            if x1 < x0:
                x0, x1 = x1, x0
            if y1 < y0:
                y0, y1 = y1, y0
            return (int(x0), int(y0), max(20, int(x1 - x0)), max(16, int(y1 - y0)))
        rx, ry, rw, rh = self.ratios[key]
        left, top, width, height = self.rect
        return (
            int(left + width * rx),
            int(top + height * ry),
            max(20, int(width * rw)),
            max(16, int(height * rh)),
        )

    def _template_center(self, name):
        if not self.vision:
            return None
        try:
            hit = self.vision.locate(name, region=self.rect)
        except Exception as exc:
            self.logger.warning(f"模板匹配 {name} 失败：{exc}")
            return None
        return (hit[0], hit[1]) if hit else None

    # ---------- 搜索 ----------
    def open_search(self) -> bool:
        """打开搜索并聚焦搜索框。

        微信 4.x 实测 Ctrl+F 无效（按键后画面零变化），因此默认改为**点击搜索框**：
        搜索框常驻左侧栏顶部，点击比快捷键可靠，也不会误切右侧会话。
        """
        if self.cfg_search_click:
            pos = self._template_center("search_box.png") or self.point("search_box")
            self.human.click(*pos)
            self.logger.info(f"已点击搜索框：{pos}")
        else:
            self.human.hotkey(*self.search_hotkey)
        self._panel_img = None      # 旧的面板截图作废
        time.sleep(random.uniform(0.6, 1.2))
        self.human.hotkey("ctrl", "a")  # 清掉可能残留的搜索词
        return True

    def type_query(self, name: str):
        self.human.paste(name)

    def wait_results(self):
        time.sleep(random.uniform(1.2, 2.5))

    def grab_results_area(self):
        """搜索框下方结果区的截图，用于判断搜索是否真的生效。"""
        if not self.vision:
            return None
        try:
            return self.vision.grab(self.band("search_results"))
        except Exception:
            return None

    @staticmethod
    def results_appeared(before, after, threshold: float = 0.01) -> bool:
        """结果区是否出现明显变化（弹出候选列表）。"""
        if before is None or after is None:
            return False
        return Vision.diff_ratio(before, after) >= threshold

    def select_result(self, name: str, allow_capture: bool = False):
        """兼容旧调用：点击第一个候选联系人行并校验。"""
        rows = self.find_contact_rows()
        if not rows:
            return False, self.band("title_band")
        self.click_row(rows[0])
        time.sleep(random.uniform(1.0, 1.6))
        return self.verify_conversation(name, allow_capture=allow_capture)

    # ---------- 搜索面板里的候选联系人行 ----------
    def scroll_results_to_top(self, notches: int = 8):
        """把候选面板滚回顶部。

        实测：面板的滚动位置会保留上一次的（滚到底后，联系人行会跑到最上面），
        所以每次搜索后先归位，候选行的相对位置才稳定。

        **滚轮点必须落在面板内部**：面板短的时候（例如只有 2 条结果），
        如果按"面板高度 1/4"取点会落到面板**下方**的聊天列表上，
        结果滚的是聊天列表，反而把整个列表滚乱、让候选行位置漂移。
        这里固定在面板顶部往下 24px —— 任何高度的面板都盖得住这里。
        """
        band = self.band("search_results")
        x = band[0] + int(band[2] * 0.5)
        y = band[1] + 24
        self.human.wheel(notches, x, y)
        time.sleep(random.uniform(0.4, 0.8))

    def find_contact_rows(self, band=None):
        """在搜索面板里找出候选“联系人行”，返回 [(x, y, 饱和度)]，按“最可能是目标”排序。

        面板里各行用图标区分：联系人行左侧是**彩色头像**（好友/群/功能图标），
        而“搜索网络结果”用搜一搜红标、下拉建议用灰色放大镜。
        因此这里先按“左侧彩色图标”抓出候选行，再交给 filter_contact_rows() 做二次分类：
        真正的联系人行（单行名字）排最前，群聊/聊天记录行（带副标题）只做兜底，
        由上层逐个点击并用会话标题参考图确认到底是不是目标联系人。
        """
        if not self.vision:
            return []
        try:
            import cv2
            import numpy as np
        except Exception as exc:
            self.logger.warning(f"缺少图像库，无法识别候选行：{exc}")
            return []

        region = band or self.band("search_results")
        img = self.vision.grab(region)
        if img is None:
            return []
        self._panel_img = img     # 留档：用于判断面板是否还开着
        mask = avatar_mask(img)
        if mask is None:
            self.logger.warning("缺少图像库，无法识别候选行")
            return []
        sat = cv2.split(cv2.cvtColor(img, cv2.COLOR_BGR2HSV))[1]   # 头像“彩色程度”留档用

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        rows = []
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            if h < 30 or w < 30:      # 头像约为 50x50，太小的多半是文字碎块
                continue
            if h > 120 or w > 200:    # 太高太宽，多半是多个元素粘连
                continue
            rows.append((region[0] + x + w // 2, region[1] + y + h // 2, int(sat[y:y + h, x:x + w].mean())))
        rows.sort(key=lambda r: r[1])
        return self.filter_contact_rows(rows)

    # ---------- 候选行分类 ----------
    def row_text_lines(self, row, min_run: int = 5, gap: int = 3) -> int:
        """候选行头像右侧的文字条带数（主题无关，靠与背景的对比度检测文字）。

        这是区分「搜索面板里的联系人行」和「群聊 / 聊天记录 / 最常使用行」的关键：
          - 联系人行（联系人分区）：头像 + 一行名字                    → 1 条带
          - 群聊行 / 最常使用行：名字下面还有一行灰色“包含:xxx”副标题   → 2 条带
          - 聊天记录结果行：名字下面还有消息摘要                        → 2 条带
        返回值：条带数；图像不可用等异常情况返回 -1（表示未知，调用方不应据此过滤）。
        """
        img = self._panel_img
        if img is None:
            return -1
        try:
            import numpy as np
        except Exception:
            return -1

        bx, by, bw, bh = self.band("search_results")
        local_y = int(row[1]) - by
        cx = int(row[0]) - bx      # 头像中心的 band 局部 x
        if local_y < 0 or local_y >= img.shape[0]:
            return -1
        # 文字区：头像右缘之外 → 面板右沿留 6% 余量（避开滚动条）
        x0 = min(max(cx + 30, 0), bw - 10)
        x1 = max(int(bw * 0.94), x0 + 20)
        y0 = max(0, local_y - 26)
        y1 = min(img.shape[0], local_y + 26)
        strip = img[y0:y1, x0:x1]
        if strip.size == 0:
            return -1
        gray = strip.max(axis=2) if strip.ndim == 3 else strip
        # 背景取中位数，文字 = 与背景对比明显的像素（深色/浅色主题都成立）
        bg = float(np.median(gray))
        text_px = (np.abs(gray.astype(int) - bg) > 40).sum(axis=1)   # 每行像素数
        on = text_px >= 4                     # 一整行里至少 4 个文字像素才算“有字”
        # 先填补 ≤gap 的空隙（汉字上下留白），再数 ≥min_run 的连续段
        on = on.astype(int)
        i = 0
        while i < len(on):
            if on[i] == 0:
                j = i
                while j < len(on) and on[j] == 0:
                    j += 1
                if i > 0 and j < len(on) and (j - i) <= gap:
                    on[i:j] = 1
                i = j
            else:
                i += 1
        bands, run = 0, 0
        for val in on:
            if val:
                run += 1
            else:
                if run >= min_run:
                    bands += 1
                run = 0
        if run >= min_run:
            bands += 1
        return bands

    def row_is_contact(self, index0: int) -> bool:
        """filter_contact_rows 之后，第 index0（0 起）个候选行是否为“纯联系人行”。

        上层在**首次捕获参考图**前必须检查这一位：群聊/聊天记录行兜底点击没关系
        （会被参考图比对拦下），但绝不能把它们的标题存成参考图——那会永久污染
        该联系人的身份校验（2026-09-12 实际发生过：错把「闲鱼教程」群存成参考图）。
        """
        return 0 <= index0 < len(getattr(self, "_row_flags", [])) and bool(self._row_flags[index0])

    def filter_contact_rows(self, rows):
        """把头像候选行分成「纯联系人行」与「疑似群聊/记录行」，返回 clean + dirty。

        判据（全部来自截图可观测特征，与主题无关）：
          a. 右侧有时间戳/日期（row_has_right_text）→ 聊天列表行或聊天记录行，不干净；
          b. 头像右侧有 ≥2 条文字带（row_text_lines）→ 名字下还有副标题/摘要，
             是群聊 / 最常使用 / 聊天记录行，不干净；
          c. 其余（只有一行名字）→ 视为真正的联系人行，排最前。
        每个分组内部再把位于面板最顶部的一行（通常是“搜索网络结果”，点了会开
        微信内置浏览器）排到最后。顺序：cleanpreferred + cleanfallback + dirty…。
        """
        clean, dirty = [], []
        for r in rows:
            try:
                bad = self.row_has_right_text(r) or self.row_text_lines(r) >= 2
            except Exception:
                bad = False
            (dirty if bad else clean).append(r)

        # 不再按“离面板顶部距离”降级：真正的第一个联系人行就贴着面板顶，
        # 而原本想压的「搜索网络结果」行没有彩色头像、根本进不了候选（原逻辑是无效代码）。
        self._row_flags = [True] * len(clean) + [False] * len(dirty)
        if self.logger and rows:
            self.logger.info(
                f"候选行共 {len(rows)} 个：纯联系人行 {len(clean)} 个，"
                f"疑似群聊/记录行 {len(dirty)} 个（仅作兜底，排后）"
            )
        return clean + dirty

    def click_row(self, pos, dx: int = 100):
        """点击候选行：落在头像右侧的文字区域，避免点开头像弹出资料卡。"""
        x, y = int(pos[0]) + dx, int(pos[1])
        self.human.click(x, y)
        time.sleep(random.uniform(0.9, 1.5))
        return (x, y)

    def row_has_right_text(self, row, min_pixels: int = 60) -> bool:
        """该候选行右侧是否有内容（时间戳 / 日期 / 免打扰图标）。

        这是区分「搜索面板里的联系人行」和「聊天列表行 / 聊天记录行」的关键：
          - 搜索面板里的**联系人行**：头像 + 名字，右侧整片是空的
          - 聊天列表行：右侧一定有时间戳（"昨天 17:44"、"星期三"）
          - 聊天记录结果行：右侧有日期（"07/10"）
        实测（band 宽 515）：
          - 联系人行  右侧 62%~100% 亮像素 = 0
          - 聊天记录行 右侧 62%~100% 亮像素 = 763
        微信里查无此人时，搜索面板只是顶部一小块下拉，**下面露出的就是聊天列表**；
        仅凭"左侧彩色头像"会把整列聊天当候选人，进而点错人 —— 必须用这个特征剔除。
        """
        img = self._panel_img
        if img is None:
            return False
        try:
            import numpy as np
        except Exception:
            return False

        bx, by, bw, bh = self.band("search_results")
        local_y = int(row[1]) - by
        if local_y < 0 or local_y >= img.shape[0]:
            return False
        x0 = int(bw * 0.78)   # 只取最右 22%：时间戳/日期贴右沿，64% 处的详情图标不再误伤
        y0 = max(0, local_y - 18)
        y1 = min(img.shape[0], local_y + 18)
        strip = img[y0:y1, x0:bw]
        if strip.size == 0:
            return False
        gray = strip.max(axis=2) if strip.ndim == 3 else strip
        # 阈值改为“与背景中位数的对比度差”，深色/浅色主题通用
        bg = float(np.median(gray))
        on = np.abs(gray.astype(int) - bg) > 60
        if int(on.sum()) < min_pixels:
            return False
        # 再看内容水平跨度：时间戳/日期是宽文本（实测 ~16% 带宽），
        # 「最常使用」行右侧的 ⓘ 详情图标是窄圆环（实测 ~4% 带宽、64 个亮像素，
        # 恰好能骗过 min_pixels=60），按跨度剔除，避免把目标联系人行误杀。
        cols = np.flatnonzero(on.any(axis=0))
        if cols.size == 0:
            return False
        return int(cols[-1] - cols[0] + 1) >= max(24, int(bw * 0.06))

    def panel_open(self, baseline=None, threshold: float = 0.02) -> bool:
        """搜索面板是否还开着。

        优先与「面板开着时」的截图（find_contact_rows 顺手存的）比对：
        与搜索前的底图比会误判——面板一关，侧栏内容也会变，看起来"差异很大"。
        """
        current = self.grab_results_area()
        if current is None:
            return False
        if self._panel_img is not None and self._panel_img.shape == current.shape:
            return Vision.diff_ratio(self._panel_img, current) < threshold
        if baseline is not None:
            return self.results_appeared(baseline, current, 0.01)
        # 没有 baseline 也没存过 _panel_img 时，退回“面板还在就认为开着”的保守判断
        return current is not None

    def clear_search(self, baseline=None):
        """关闭搜索面板。

        只在「结果面板仍开着」时才按 Esc：正常聊天界面上乱按 Esc
        可能触发别的行为，这里用结果区截图来判断。
        """
        if baseline is not None:
            try:
                if not self.panel_open(baseline):
                    return False
            except Exception:
                pass
        else:
            try:
                if not self.panel_open():
                    return False
            except Exception:
                pass
        self.human.press("esc")
        time.sleep(random.uniform(0.3, 0.6))
        self.human.press("esc")
        time.sleep(random.uniform(0.3, 0.6))
        return True

    # ---------- 校验 ----------
    def verify_conversation(self, name: str, allow_capture: bool = False):
        """返回 (是否通过, 标题区矩形)。

        - 有参考图：与参考图比对，相似度不达标即判定找错人
        - 无参考图：演练模式下先保存参考图供人工核对；正式发送一律拒绝
        """
        band = self.band("title_band")
        if self.verify_mode == "off":
            self.logger.warning("verify_mode=off，跳过会话校验（存在发错人风险）")
            return True, band
        if not self.vision:
            self.logger.error("图像模块不可用，无法校验会话，拒绝发送")
            return False, band

        if not self.vision.has_ref(name):
            if allow_capture:
                path = self.vision.save_ref(name, band)
                self.logger.warning(
                    f"首次运行，已保存会话标题参考图：{path}"
                    "  ——请打开该图确认是目标联系人，确认后再把 approved 改为 true"
                )
                return True, band
            self.logger.error(f"缺少联系人「{name}」的标题参考图，请先执行一次演练")
            return False, band

        ok = self.vision.compare_ref(name, band)
        if not ok:
            self.logger.error("会话标题与参考图不一致，判定为找错人，拒绝发送")
        return ok, band

    # ---------- 输入框 ----------
    def focus_input(self):
        pos = self._template_center("input_box.png") or self.point("input_box")
        self.human.click(*pos)
        time.sleep(random.uniform(0.4, 0.9))
        return pos

    # ---------- 发送后比对 ----------
    def grab_message_area(self):
        if not self.vision:
            return None
        try:
            return self.vision.grab(self.band("message_area"))
        except Exception:
            return None
