# -*- coding: utf-8 -*-
"""按昵称/备注名查找微信联系人。

设计目标：让网页端的「联系人」表单不再要求用户手输手机号/微信号——
只用昵称或备注名，系统自动激活微信窗口、在搜索框输入、点击候选行、
用会话标题参考图核对身份，把「目标联系人」自动选中返回。

安全约束：
- 复用既有 Locator 与 WeChatWindow，不引入新的发送路径；
- 校验阶段复用 verify_conversation()（首跑自动保存参考图，二跑比对）；
- 整个流程用 try/finally 收尾，无论中途出任何异常都不会留下搜索面板、
  不会修改微信会话（最多让面板短暂停留一下，最后都关掉）。
"""
from __future__ import annotations

import random
import time
from dataclasses import dataclass, field
from typing import List

from ..config_loader import Config
from ..input.human import Human
from ..vision import Vision
from .locator import WeChatLocator, rect_tuple
from .window import WeChatWindow


# ---------- 线程 COM 初始化 ----------
def _init_com():
    """在线程里调 uiautomation / win32 之前必须先 CoInitialize。

    BaseHTTPRequestHandler 的工作线程没自动初始化 COM，
    否则会一直刷「[WinError -2147221008] 尚未调用 CoInitialize」。
    """
    try:
        import pythoncom
        pythoncom.CoInitialize()
        return pythoncom
    except Exception:
        # 没装 pywin32 的 pythoncom 时退化为 ctypes
        import ctypes
        ctypes.windll.ole32.CoInitialize(None)
        return None


# ---------- 业务异常 ----------
class ResolveError(Exception):
    """查找联系人失败。code 用于前端区分错误类型并给出明确提示。"""

    def __init__(self, code: str, message: str, hint: str = ""):
        super().__init__(message)
        self.code = code
        self.message = message
        self.hint = hint


@dataclass
class ResolveResult:
    matched_name: str
    ref_saved: bool             # 本次是否新建了参考图（用户首次识别时为 True）
    checked_rows: int = 0       # 实际尝试过几次候选行
    total_rows: int = 0         # 候选面板里共有多少个彩色头像行
    verify_score: float = None  # 与既有参考图的相似度（首跑无参考图时为 None）
    had_ref_before: bool = False  # 查找前是否已有参考图
    snapshots: List[str] = field(default_factory=list)


class ContactResolver:
    """一次性的「按昵称找联系人」操作。

    用法：
        resolver = ContactResolver(cfg, logger)
        result = resolver.resolve("张三")    # → ResolveResult
    """

    # 最多尝试 4 个候选行；超过说明找错人或面板异常，安全中止
    MAX_ROWS = 3
    # 「搜索面板真的弹出来了」的最小画面差异。
    # 面板背景色和聊天列表完全一样，差异只来自文字/头像，所以数值偏低：
    #   真有结果的查询 ≈ 22%~69%（取决于面板内容与背后列表的差异程度）
    #   微信里查无此人 → 面板不弹，band 里还是聊天列表 → 0%~8%
    # 取 15% 落在两者之间；再叠加 locator.row_has_right_text 做第二道闸。
    SEARCH_PANEL_MIN_DIFF = 0.08

    def __init__(self, cfg: Config, logger):
        self.cfg = cfg
        self.logger = logger
        self.window = WeChatWindow(cfg.wechat, logger)
        self.vision = Vision(cfg.root, logger)
        self.behavior = cfg.behavior
        # 真实的控件/视觉实例在 resolve() 内按需创建，避免冷启动做无谓工作

    # ---------- 入口 ----------
    def resolve(self, query: str, allow_save_ref: bool = True) -> ResolveResult:
        query = (query or "").strip()
        if not query:
            raise ResolveError(
                "empty_query", "昵称不能为空",
                "请输入微信里的备注名或昵称（与你微信里看到的完全一致）",
            )

        # uiautomation / win32 在工作线程里需要显式 CoInitialize
        com = _init_com()
        try:
            return self._resolve_impl(query, allow_save_ref)
        finally:
            try:
                if com is not None:
                    com.CoUninitialize()
            except Exception:
                pass

    def _resolve_impl(self, query: str, allow_save_ref: bool) -> ResolveResult:
        # 1) 找到微信主窗口（必要时冷启动）；登录窗口 → 明确错误
        self.window.ensure_running()
        if self.window.is_login_window():
            raise ResolveError(
                "not_logged_in",
                "微信停留在登录窗口",
                "请先在电脑上登录微信（扫码或确认登录），保持在线后再试",
            )

        # 2) 激活窗口（不在前台就拉上来）；拿坐标用
        if not self.window.activate():
            raise ResolveError(
                "activate_failed",
                "无法把微信窗口激活到前台",
                "请检查微信窗口是否被遮挡，或手动点击微信图标后再试",
            )
        rect = self.window.snapshot_rect()
        if not rect or rect[2] < 600 or rect[3] < 400:
            raise ResolveError(
                "window_too_small",
                "微信窗口尺寸异常",
                "请确认微信窗口未被最小化，窗口至少 600×400 像素",
            )

        # 3) 检查窗口是否在执行前就被拖动过 —— 与执行期间变化则停止
        rect_before = rect

        human = Human(self.behavior)
        locator = WeChatLocator(
            rect, human, self.logger, vision=self.vision,
            cfg=self.cfg.wechat, verify_mode=self.cfg.safety.get("verify_mode", "strict"),
        )

        result = ResolveResult(matched_name="", ref_saved=False)
        result.had_ref_before = self.vision.has_ref(query)
        # 抓一下原始面板截图，作为清理判断的基准
        results_before = locator.grab_results_area()

        try:
            # 4) 打开搜索 + 输入 + 等待候选
            locator.open_search()
            locator.type_query(query)
            locator.wait_results()
            after = locator.grab_results_area()
            panel_diff = Vision.diff_ratio(results_before, after)
            if panel_diff < self.SEARCH_PANEL_MIN_DIFF:
                raise ResolveError(
                    "no_results",
                    f"微信里没有找到「{query}」",
                    f"搜索面板未弹出（画面差异 {panel_diff * 100:.1f}%，需≥{self.SEARCH_PANEL_MIN_DIFF * 100:.0f}%）。"
                    "请依次排查：① 微信是否在前台且已登录；② 窗口未被拖动/缩放；"
                    "③ 对方是微信好友且有聊天历史记录（新加好友若从未聊过，搜索可能不返回）；"
                    "④ 备注名与微信里完全一致（含空格、全角/半角）"
                    "，若以上都正常可先用「编辑」手动填名字。",
                )
            self.logger.info(f"搜索面板已弹出（画面差异 {panel_diff * 100:.1f}%）")

            # 5) 滚动到顶后再找行（面板滚动位置会保留上次）
            locator.scroll_results_to_top()
            rows = locator.find_contact_rows()
            result.total_rows = len(rows)

            # 5.1) 二次过滤：只保留「真正的联系人行」。
            # 纯联系人行（单行名字、右侧无时间戳）排最前；
            # 群聊/最常使用/聊天记录行（名字下还有“包含:…”副标题或摘要）只作兜底。
            rows = locator.filter_contact_rows(rows)
            # 标志位必须和 rows 一起快照：_reopen_panel 重建后两者要同步更新，
            # 否则会拿新标志位对旧行号（曾导致群聊标题被存成参考图，reference 被污染）
            flags = list(getattr(locator, "_row_flags", []))
            if rows and not any(locator.row_is_contact(i) for i in range(len(rows))):
                self.logger.info(
                    f"识别到 {len(rows)} 行，但都是群聊/聊天记录行（带副标题或时间戳），判定为未找到联系人"
                )
                rows = []
            result.total_rows = len(rows)

            if not rows:
                raise ResolveError(
                    "no_results",
                    f"微信里没有找到「{query}」",
                    "该昵称可能只出现在聊天记录或群聊里，没有对应的好友/会话；"
                    "请确认备注名是否准确，或先用「编辑」手动填名字",
                )

            # 6) 逐个尝试候选行。
            #
            # 判据全部是「可观测的地面真值」，不靠猜位置：
            #   a. 点下去若弹出微信内置浏览器窗口 → 那是「搜索网络结果」行，跳过；
            #   b. 点下去搜索面板**关掉**了 → 说明真的打开了一个会话；
            #      仍开着则说明只是把文字填进搜索框（功能/建议行），跳过；
            #   c. 通过 (a)(b) 后再用 verify_conversation 校验身份
            #      （有参考图→比对；首跑→存参考图，由用户在页面上肉眼确认）。
            overlays_before = self.window.overlay_snapshot()
            title_before = self._grab_title(locator)
            # 用 while 而非 for：rows 会在循环内被 _reopen_panel 换成新列表，
            # for 的迭代对象在循环开始时就固化，会拿旧坐标点新面板（节点复用式误点）。
            idx = 0
            while idx < len(rows) and idx < self.MAX_ROWS:
                index, row = idx + 1, rows[idx]
                # 窗口若被用户拖动，立即中止
                cur = self.window.snapshot_rect()
                if self.window.rect_moved(rect_before, cur):
                    raise ResolveError(
                        "window_moved",
                        "微信窗口被拖动，自动中止",
                        "请保持微信窗口不动，再次发起自动识别",
                    )

                pos = locator.click_row(row)
                result.checked_rows = index
                self.logger.info(f"已点击第 {index} 个候选行 {pos}，正在核对")

                # (a) 是否点出了微信内置浏览器（= 点了「搜索网络结果」）
                spawned = [h for h in self.window.overlay_windows() if h not in overlays_before]
                if spawned:
                    self.logger.info(f"第 {index} 个候选行是「搜索网络结果」，已关闭弹出窗口并跳过")
                    self.window.close_new_overlays(overlays_before)
                    time.sleep(0.7)
                    self.window.activate()
                    rows, flags = self._reopen_panel(locator, results_before, query, rows)
                    idx += 1
                    continue

                # (b) 搜索面板是否关闭（关掉 = 真的打开了会话）
                panel_closed = not locator.panel_open(results_before)
                changed = Vision.diff_ratio(title_before, self._grab_title(locator))
                self.logger.info(
                    f"第 {index} 行：面板{'已关闭' if panel_closed else '仍开着'}，标题区变化 {changed * 100:.2f}%"
                )
                if not panel_closed:
                    self.logger.info(f"第 {index} 个候选行没有打开会话（多半是功能/建议项），跳过")
                    rows, flags = self._reopen_panel(locator, results_before, query, rows)
                    idx += 1
                    continue

                # (c) 校验身份。参考图只允许从「纯联系人行」捕获——
                #     若兜底点到群聊/记录行，绝不能把它的标题存成参考图（防污染）。
                allow_capture = allow_save_ref and (
                    0 <= index - 1 < len(flags) and bool(flags[index - 1])
                )
                ok, band = locator.verify_conversation(query, allow_capture=allow_capture)
                if ok:
                    # 企微/微信的系统窗口标题里拿不到会话名（永远是「微信」），
                    # 所以名字直接采用用户输入——这也是"昵称/备注名"本身的定义。
                    result.matched_name = query
                    result.ref_saved = not result.had_ref_before
                    result.verify_score = getattr(self.vision, "last_score", None)
                    self.logger.info(f"已确认匹配：{query}（第 {index} 个候选行）")
                    break

                # 不是目标：关掉误开的内置窗口 + 重开搜索面板，继续试下一个
                closed = self.window.close_new_overlays(overlays_before)
                if closed:
                    self.logger.info(f"已关闭 {len(closed)} 个误开的内置窗口")
                    time.sleep(0.8)
                    self.window.activate()
                rows, flags = self._reopen_panel(locator, results_before, query, rows)
                idx += 1

            if not result.matched_name:
                raise ResolveError(
                    "no_exact_match",
                    f"试完 {result.checked_rows} 个候选行都没能把会话切到「{query}」",
                    "可能是好友有同名备注或群成员带相同昵称，请用更精确的备注名重试",
                )

            return result

        finally:
            # 任何分支都会走到这里：关闭搜索面板，恢复窗口前置状态
            try:
                locator.clear_search(results_before)
            except Exception as exc:
                self.logger.warning(f"清理搜索面板失败：{exc}")
            try:
                self.window.restore()
            except Exception:
                pass

    # ---------- 工具 ----------
    def _grab_title(self, locator):
        try:
            return self.vision.grab(locator.band("title_band"))
        except Exception:
            return None

    def _reopen_panel(self, locator, results_before, query, rows):
        """面板被关掉/内容变了时重开并重新找行，返回最新的候选行列表。

        注意：必须重新过一遍 filter_contact_rows —— find_contact_rows 返回的是
        「纯联系人行 + 群聊兜底行」的混合列表，这里要保证 clean 在前、标志位对齐。
        """
        try:
            if not locator.panel_open(results_before):
                locator.open_search()
                locator.type_query(query)
                locator.wait_results()
                locator.scroll_results_to_top()
                new_rows = locator.filter_contact_rows(locator.find_contact_rows())
                return new_rows, list(getattr(locator, "_row_flags", []))
        except Exception as exc:
            self.logger.warning(f"重开搜索面板失败：{exc}")
        return rows, list(getattr(locator, "_row_flags", []))