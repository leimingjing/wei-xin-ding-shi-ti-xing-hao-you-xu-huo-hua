@echo off
chcp 65001 >nul
cd /d "%~dp0"
title WeChat Auto Sender - Workbench
set PY=
if exist "%~dp0.venv\Scripts\python.exe" set PY=%~dp0.venv\Scripts\python.exe
rem 可选：把你的虚拟环境 python 写在这一行前面，例如
rem if "%PY%"=="" if exist "%~dp0.venv\Scripts\python.exe" set PY=%~dp0.venv\Scripts\python.exe
if "%PY%"=="" if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set PY=%LOCALAPPDATA%\Programs\Python\Python311\python.exe
if "%PY%"=="" set PY=python
echo Starting... see logs\run.log for details
"%PY%" app.py %*
if errorlevel 1 (
  echo.
  echo [ERROR] ExitCode=%errorlevel%
  echo See logs\run.log for details.
  pause
)
