# -*- coding: utf-8 -*-
"""把控制台程序渲染到独立窗口并截图，用来肉眼核对终端里的真实排版。

用法：
    python tools/shot_console.py <要跑的脚本> <输出png> [宽] [高]

为什么不用 ImageGrab 直接抓屏：
  1. 新控制台窗口可能被当前窗口遮住，抓到的是别的窗口；
  2. 进程若不是 DPI 感知的，ClientToScreen 返回缩放后的虚拟坐标，图会被裁掉一圈。
本脚本用 PrintWindow(PW_RENDERFULLCONTENT) 让窗口自己渲染到内存位图——不受遮挡影响，
并显式声明 DPI 感知。两条都实测踩过坑，故保留在注释里。
"""
import ctypes
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def make_dpi_aware():
    """必须做，否则 GetClientRect/ClientToScreen 返回虚拟坐标，截图被裁。"""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PER_MONITOR_DPI_AWARE
        return "per-monitor"
    except Exception:
        pass
    try:
        ctypes.windll.user32.SetProcessDPIAware()
        return "system"
    except Exception:
        return "none"


DPI_MODE = make_dpi_aware()

import win32con  # noqa: E402
import win32gui  # noqa: E402
import win32ui  # noqa: E402
from PIL import Image  # noqa: E402
from PIL import ImageGrab  # noqa: E402

HWND_TOPMOST = -1
HWND_NOTOPMOST = -2
PW_RENDERFULLCONTENT = 0x00000002


def new_console_windows(before):
    found = []

    def cb(hwnd, _):
        if win32gui.IsWindowVisible(hwnd) and win32gui.GetParent(hwnd) == 0 and hwnd not in before:
            cls = (win32gui.GetClassName(hwnd) or "").upper()
            if "CASCADIA" in cls or cls == "CONSOLEWINDOWCLASS":
                found.append(hwnd)
        return True

    win32gui.EnumWindows(cb, None)
    return found


def visible_top_windows():
    found = set()

    def cb(hwnd, _):
        if win32gui.IsWindowVisible(hwnd) and win32gui.GetParent(hwnd) == 0:
            found.add(hwnd)
        return True

    win32gui.EnumWindows(cb, None)
    return found


def capture_client(hwnd, path):
    """优先 PrintWindow（不受遮挡），失败再退回抓屏。返回实际用的方式。"""
    rect = win32gui.GetClientRect(hwnd)
    width, height = rect[2] - rect[0], rect[3] - rect[1]
    if width <= 0 or height <= 0:
        return "尺寸无效"

    hdc = win32gui.GetWindowDC(hwnd)
    src = None
    mem = None
    try:
        src = win32ui.CreateDCFromHandle(hdc)
        mem = src.CreateCompatibleDC()
        bmp = win32ui.CreateBitmap()
        bmp.CreateCompatibleBitmap(src, width, height)
        mem.SelectObject(bmp)
        ok = ctypes.windll.user32.PrintWindow(hwnd, mem.GetSafeHdc(), PW_RENDERFULLCONTENT)
        if ok:
            info = bmp.GetInfo()
            data = bmp.GetBitmapBits(True)
            img = Image.frombuffer("RGB", (info["bmWidth"], info["bmHeight"]),
                                   data, "raw", "BGRX", 0, 1)
            img.save(path)
            return f"PrintWindow {width}x{height}"
    except Exception as exc:
        print("PrintWindow 失败：", exc)
    finally:
        try:
            if src:
                win32gui.DeleteDC(src.GetSafeHdc())
            if mem:
                win32gui.DeleteDC(mem.GetSafeHdc())
        except Exception:
            pass
        win32gui.ReleaseDC(hwnd, hdc)

    left, top = win32gui.ClientToScreen(hwnd, (rect[0], rect[1]))
    right, bottom = win32gui.ClientToScreen(hwnd, (rect[2], rect[3]))
    ImageGrab.grab(bbox=(left, top, right, bottom), all_screens=True).save(path)
    return f"抓屏 {right - left}x{bottom - top}"


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    target, out = sys.argv[1], sys.argv[2]
    size = (int(sys.argv[3]), int(sys.argv[4])) if len(sys.argv) >= 5 else None

    before = visible_top_windows()
    proc = subprocess.Popen([sys.executable, target], cwd=ROOT,
                            creationflags=subprocess.CREATE_NEW_CONSOLE)

    hwnd, deadline = None, time.time() + 20
    while time.time() < deadline and not hwnd:
        fresh = new_console_windows(before)
        if fresh:
            hwnd = fresh[0]
        time.sleep(0.4)
    if not hwnd:
        print("没找到新控制台窗口")
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True)
        return 2

    print("控制台窗口:", hwnd, repr(win32gui.GetWindowText(hwnd)), "| DPI:", DPI_MODE)
    try:
        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        if size:
            win32gui.MoveWindow(hwnd, 60, 60, size[0], size[1], True)
        win32gui.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                              win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_SHOWWINDOW)
    except Exception as exc:
        print("置顶失败（不影响 PrintWindow 截图）：", exc)
    time.sleep(2.5)

    path = os.path.join(ROOT, out)
    how = capture_client(hwnd, path)
    print("已截图:", path, "|", how)

    try:
        win32gui.SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0,
                              win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
    except Exception:
        pass
    subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
