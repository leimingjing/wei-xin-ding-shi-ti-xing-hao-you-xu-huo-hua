# -*- coding: utf-8 -*-
"""安全重新打包（P2-1）：只替换 exe + _internal + web + tools，绝不触碰活数据。

背景：2026-09-16 那次重打包把 dist 侧 assets/refs/ 误删（PyInstaller 清理旧 dist 时
连同运行态参考图一起清掉），随后"缺少参考图"→ 点错人。根因是打包直接以 dist 为目标。

本脚本把流程固定为：
  1. 校验 dist 活数据（config/config.yaml、data/、assets/refs/、logs/）存在
  2. 备份现有 exe + _internal 到备份目录（可回滚）
  3. PyInstaller 输出到 dist_new（全程不碰 dist）
  4. 只把新 exe + 新 _internal 搬进 dist；旧 _internal 整体移出（不删除）
  5. 用源码的 web/ tools/ 覆盖 dist 对应目录（页面与工具脚本随版本更新）
  6. 复核活数据仍在原位（config.yaml 大小/时间未变、refs 清单未变）

用法：
    python tools/build_dist.py              # 完整执行
    python tools/build_dist.py --check-only # 只做校验与打印，不动任何文件
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DIST_APP = os.path.join(ROOT, "dist", "微信定时发送")
DIST_NEW = os.path.join(ROOT, "dist_new")
APP_NAME = "微信定时发送"
LIVE_MUST_EXIST = [
    os.path.join(DIST_APP, "config", "config.yaml"),
    os.path.join(DIST_APP, "data"),
    os.path.join(DIST_APP, "assets", "refs"),
    os.path.join(DIST_APP, "logs"),
]
# 备份目录：可用环境变量 WECHAT_PACK_BACKUP 指定（例如会话中间产物目录）
BACKUP_DIR = os.environ.get("WECHAT_PACK_BACKUP") or os.path.join(ROOT, "_pack_backup")


def log(*a):
    print("[build]", *a, flush=True)


def snapshot_live(tag):
    """记录活数据指纹（打包前后比对，防止再次误删/误改）。"""
    info = {"tag": tag}
    cfg = os.path.join(DIST_APP, "config", "config.yaml")
    info["config_size"] = os.path.getsize(cfg) if os.path.exists(cfg) else -1
    info["config_mtime"] = os.path.getmtime(cfg) if os.path.exists(cfg) else -1
    refs = os.path.join(DIST_APP, "assets", "refs")
    info["refs"] = sorted(os.listdir(refs)) if os.path.isdir(refs) else None
    st = os.path.join(DIST_APP, "logs", "state.json")
    info["state_size"] = os.path.getsize(st) if os.path.exists(st) else -1
    return info


def check_live():
    missing = [p for p in LIVE_MUST_EXIST if not os.path.exists(p)]
    if missing:
        raise SystemExit("拒绝打包：dist 活数据缺失 " + "；".join(missing))
    log("活数据校验通过：", "；".join(os.path.relpath(p, ROOT) for p in LIVE_MUST_EXIST))


def run_pyinstaller():
    args = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm", "--clean", "--windowed",
        "--name", APP_NAME,
        "--paths", os.path.join(ROOT, "workbench"),
        # 注意：--specpath 会改变 spec 生成目录，而 --add-data 的相对源路径是按 spec 目录
        # 解析的（不是 cwd），所以源路径必须给绝对路径；目标名保持相对即可。
        "--add-data", os.path.join(ROOT, "web") + os.pathsep + "web",
        "--add-data", os.path.join(ROOT, "tools") + os.pathsep + "tools",
        "--add-data", os.path.join(ROOT, "assets") + os.pathsep + "assets",
        "--hidden-import", "contacts",
        "--hidden-import", "theme",
        "--hidden-import", "comtypes",
        "--hidden-import", "pystray",
        "--hidden-import", "uiautomation",
        "--hidden-import", "apscheduler",
        "--distpath", DIST_NEW,
        "--workpath", os.path.join("build", "work_new"),
        "--specpath", "build",
    ]
    ico = os.path.join(ROOT, "assets", "app.ico")
    if os.path.exists(ico):
        args += ["--icon", ico]
    args.append("client.py")
    log("PyInstaller:", " ".join(args[1:]))
    rc = subprocess.call(args, cwd=ROOT)
    if rc != 0:
        raise SystemExit(f"PyInstaller 失败，返回码 {rc}")
    exe = os.path.join(DIST_NEW, APP_NAME, APP_NAME + ".exe")
    internal = os.path.join(DIST_NEW, APP_NAME, "_internal")
    if not os.path.exists(exe) or not os.path.isdir(internal):
        raise SystemExit("PyInstaller 未产出预期文件：" + exe)
    log(f"打包产物就绪：{exe}（{os.path.getsize(exe)} B）")
    return exe, internal


def replace_exe_and_internal(exe, internal, stamp):
    bak = os.path.join(BACKUP_DIR, f"dist-{stamp}")
    os.makedirs(bak, exist_ok=True)
    old_exe = os.path.join(DIST_APP, APP_NAME + ".exe")
    old_internal = os.path.join(DIST_APP, "_internal")
    if os.path.exists(old_exe):
        shutil.copy2(old_exe, os.path.join(bak, "微信定时发送.exe.bak"))
        log("旧 exe 已备份 →", os.path.join(bak, "微信定时发送.exe.bak"))
    if os.path.isdir(old_internal):
        # 旧 _internal 体积大：整体移出（不删除），保证可回滚
        shutil.move(old_internal, os.path.join(bak, "_internal.bak"))
        log("旧 _internal 已移出 →", os.path.join(bak, "_internal.bak"))
    shutil.copy2(exe, os.path.join(DIST_APP, APP_NAME + ".exe"))
    shutil.move(internal, os.path.join(DIST_APP, "_internal"))
    log("新 exe 与新 _internal 已就位（回滚目录：" + bak + "）")
    return bak


def sync_dir(src_name):
    src = os.path.join(ROOT, src_name)
    dst = os.path.join(DIST_APP, src_name)
    if not os.path.isdir(src):
        log("跳过（源码缺目录）：", src_name)
        return
    os.makedirs(dst, exist_ok=True)
    n = 0
    for dirpath, _dirnames, filenames in os.walk(src):
        rel = os.path.relpath(dirpath, src)
        target_dir = dst if rel == "." else os.path.join(dst, rel)
        os.makedirs(target_dir, exist_ok=True)
        for fn in filenames:
            if fn.endswith(".pyc"):
                continue
            shutil.copy2(os.path.join(dirpath, fn), os.path.join(target_dir, fn))
            n += 1
    log(f"{src_name}/ 已同步到 dist（{n} 个文件，覆盖同名；不删除 dist 独有文件）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check-only", action="store_true")
    args = ap.parse_args()

    check_live()
    before = snapshot_live("before")
    log("打包前活数据指纹：", json.dumps(before, ensure_ascii=False))

    if args.check_only:
        log("--check-only：仅校验，未做任何改动")
        return

    stamp = time.strftime("%Y%m%d_%H%M%S")
    exe, internal = run_pyinstaller()
    replace_exe_and_internal(exe, internal, stamp)
    for d in ("web", "tools"):
        sync_dir(d)

    after = snapshot_live("after")
    log("打包后活数据指纹：", json.dumps(after, ensure_ascii=False))
    ok = (
        before["config_size"] == after["config_size"]
        and before["config_mtime"] == after["config_mtime"]
        and before["refs"] == after["refs"]
    )
    if not ok:
        raise SystemExit("!! 活数据在打包过程中发生变化，请立即用备份回滚并排查")
    log("OK 活数据完好（config.yaml 未变、refs 清单未变）")


if __name__ == "__main__":
    main()
