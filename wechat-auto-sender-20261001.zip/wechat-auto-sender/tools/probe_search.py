# -*- coding: utf-8 -*-
"""搜索链路实证探测：验证「点击搜索框 → 粘贴 → 点候选联系人行」这条路是否成立。

只搜索、只点候选行、只截标题区，**不发送任何消息**；末尾自动收尾。
每点一个候选行就把会话标题区另存一张图，便于人工确认点中的是谁。

用法：
    python tools/probe_search.py                       # 默认用「文件传输助手」自检
    python tools/probe_search.py --query 张三 --rows 3
"""
import argparse
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from PIL import Image, ImageDraw  # noqa: E402

from wechat_auto.config_loader import Config  # noqa: E402
from wechat_auto.input import kbdmouse as km  # noqa: E402,F401  开启 DPI 感知
from wechat_auto.input.human import Human  # noqa: E402
from wechat_auto.vision import Vision  # noqa: E402
from wechat_auto.wechat.locator import WeChatLocator, rect_tuple  # noqa: E402
from wechat_auto.wechat.window import WeChatWindow  # noqa: E402

LOGS = None
SHOTS = []


class Log:
    def info(self, m):
        print("   " + str(m))

    warning = error = info


def save(img_bgr, tag, marks=(), rect=None):
    img = Image.fromarray(img_bgr[:, :, ::-1])
    if marks and rect:
        draw = ImageDraw.Draw(img)
        for (x, y), label, color in marks:
            px, py = int(x - rect[0]), int(y - rect[1])
            draw.line((px - 14, py, px + 14, py), fill=color, width=2)
            draw.line((px, py - 14, px, py + 14), fill=color, width=2)
            draw.text((px + 16, py - 10), label, fill=color)
    path = os.path.join(LOGS, f"probe_search_{tag}.png")
    img.save(path)
    SHOTS.append(path)
    return path


def main():
    global LOGS
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", default="文件传输助手", help="自检用关键词")
    parser.add_argument("--rows", type=int, default=3, help="最多点几个候选行")
    args = parser.parse_args()

    cfg = Config(ROOT)
    logger = Log()
    LOGS = os.path.join(ROOT, "logs")
    os.makedirs(LOGS, exist_ok=True)

    window = WeChatWindow(cfg.wechat, logger)
    window.ensure_running()
    if window.is_login_window():
        print("微信停留在登录窗口，请先登录后再跑本工具")
        return 1
    window.activate()
    time.sleep(1.0)

    rect = rect_tuple(window.control)
    print(f"窗口矩形: left={rect[0]} top={rect[1]} {rect[2]}x{rect[3]}")

    vision = Vision(ROOT, logger)
    human = Human(cfg.behavior)
    locator = WeChatLocator(rect, human, logger, vision, cfg.wechat)

    print(f"搜索框点击点: {locator.point('search_box')}   输入框点击点: {locator.point('input_box')}")
    print(f"标题区: {locator.band('title_band')}   候选区: {locator.band('search_results')}")

    overlays_before = window.overlay_snapshot()
    results_before = locator.grab_results_area()
    save(vision.grab(rect), "1_before")

    # ---------- 1. 点搜索框 + 粘贴 ----------
    print("\n[1] 点击搜索框并粘贴关键词 …")
    locator.open_search()
    locator.type_query(args.query)
    locator.wait_results()
    appeared = locator.results_appeared(results_before, locator.grab_results_area())
    save(vision.grab(rect), "2_typed", marks=[(locator.point("search_box"), "search_box", (255, 60, 60))], rect=rect)
    print(f"   候选列表 → {'✅ 已出现，搜索生效' if appeared else '❌ 未出现，搜索没生效'}")
    if not appeared:
        print("\n搜索没生效，后续无需继续。请检查 config.yaml 的 wechat.layout.search_box")
        return 1

    # ---------- 2. 逐个点候选行 ----------
    rows = locator.find_contact_rows()
    print(f"\n[2] 识别到 {len(rows)} 个候选行（彩色头像行，已排除顶部“搜索网络结果”）")
    for i, row in enumerate(rows, 1):
        print(f"     #{i} 屏幕坐标 ({row[0]}, {row[1]})  饱和度 {row[2]}")

    if not rows:
        print("   ❌ 没有识别到候选行，可能面板结构变了")
        locator.clear_search(results_before)
        return 1

    title_dir = os.path.join(LOGS, "titles")
    os.makedirs(title_dir, exist_ok=True)
    for i, row in enumerate(rows[: args.rows], 1):
        pos = locator.click_row(row)
        print(f"\n[3.{i}] 点击 #{i} 行 → 点击点 {pos}")
        save(vision.grab(rect), f"3_{i}_row", marks=[((pos[0], pos[1]), f"row{i}", (255, 200, 0))], rect=rect)
        band = locator.band("title_band")
        img = Image.fromarray(vision.grab(band)[:, :, ::-1])
        path = os.path.join(title_dir, f"row{i}_title.png")
        img.save(path)
        print(f"   会话标题区已另存：{path}（打开确认是不是「{args.query}」）")
        if not locator.panel_open(results_before):
            print("   搜索面板已关闭（说明这一行点下去是“打开会话”）")
            break
        print("   面板仍开着（这一行不是会话，继续试下一行）")

    closed = window.close_new_overlays(overlays_before)
    if closed:
        print(f"\n[4] 已关闭微信本次新弹出的 {len(closed)} 个内置窗口")
        time.sleep(0.8)
    locator.clear_search(results_before)
    save(vision.grab(rect), "5_closed")

    print("\n结论：看 titles/ 里哪一张标题区就是目标联系人，那张对应 #几 行。")
    print("  正常应命中 #1（若命中不到，说明候选行识别需要调整）。")
    print("  截图：" + "\n        ".join(SHOTS))
    return 0


if __name__ == "__main__":
    sys.exit(main())
