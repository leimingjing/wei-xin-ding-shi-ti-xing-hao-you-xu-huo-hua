# -*- coding: utf-8 -*-
"""联系人 ↔ 发送任务 打通链路自检。

全程在临时目录跑，不碰真实 config.yaml / contacts.json：
  1. 老联系人数据自动补稳定 id（c1、c2…）并落盘
  2. 新建任务关联联系人（姓名自动取联系人姓名；写错名会被拒绝）
  3. 同一联系人不能被第二个任务关联（重名拦截）
  4. 解除关联后 config.yaml 里不再残留 contact_id 键
  5. 换绑另一个联系人 → 任务姓名跟着换
  6. 有关联时删除联系人被拒绝（防悬空）
  7. 联系人改名 → 关联任务自动改名；config 注释保留
  8. 悬空 contact_id 在保存时被校验拦截

用法：python tools/test_contact_link.py
"""
import json
import os
import shutil
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "workbench"))

FAILS = []


def check(cond, label, extra=""):
    tag = "PASS" if cond else "FAIL"
    if not cond:
        FAILS.append(label)
    print(f"  [{tag}] {label}" + (f"  | {extra}" if extra else ""))


def expect_error(fn, key, label):
    try:
        fn()
        check(False, label, "（没有抛出预期异常）")
    except Exception as exc:
        check(key in str(exc), label, f"异常信息：{exc}")


def main():
    tmp = tempfile.mkdtemp(prefix="wxlink_")
    for d in ("config", "data", "logs", "assets/refs"):
        os.makedirs(os.path.join(tmp, d), exist_ok=True)

    # 最小 config.yaml（结构同真实文件，targets 含一条无关联的老目标）
    cfg_text = """# 头部注释必须保留（config_editor 的核心卖点）
schedule:
  enabled: true
  times: ["08:30"]
  jitter_minutes: 0
  weekdays: [1, 2, 3, 4, 5, 6, 7]

targets:
  - name: "老目标"
    enabled: false
    approved: false
    times: []
    messages:
      - "hello {name}"
"""
    with open(os.path.join(tmp, "config", "config.yaml"), "w", encoding="utf-8") as fh:
        fh.write(cfg_text)
    contacts_seed = {"version": 1, "contacts": [
        {"name": "张三", "contact": "13800138000", "contact_type": "手机",
         "datetime": "2026-09-13 08:30", "created_at": "", "updated_at": ""},
        {"name": "示例联系人B", "contact": "", "contact_type": "",
         "datetime": "2026-09-13 21:00", "created_at": "", "updated_at": ""},
    ]}
    with open(os.path.join(tmp, "data", "contacts.json"), "w", encoding="utf-8") as fh:
        json.dump(contacts_seed, fh, ensure_ascii=False)

    from wechat_auto.config_loader import Config
    from wechat_auto.webapp import WebConsole
    import contacts as contacts_mod

    store = contacts_mod.ContactStore(os.path.join(tmp, "data", "contacts.json"))
    cfg = Config(tmp)
    notified = []
    console = WebConsole(tmp, store, cfg=cfg, on_config_change=lambda: notified.append(1))

    print("== 1. 老数据补稳定 id ==")
    ids = [c.get("id") for c in store.contacts]
    check(ids == ["c1", "c2"], f"id 自动补齐 {ids}")
    on_disk = json.load(open(os.path.join(tmp, "data", "contacts.json"), encoding="utf-8"))
    check([c.get("id") for c in on_disk["contacts"]] == ["c1", "c2"], "id 已写回 contacts.json")

    print("== 2. 列表视图带联系人外键 ==")
    rows = console.targets_list()["targets"]
    check(rows[0]["contact_id"] is None and rows[0]["contact"] is None, "未关联目标：contact_id/contact 为空")

    print("== 3. 新建任务关联联系人 ==")
    expect_error(
        lambda: console.target_add({"name": "错名", "times": [], "messages": ["x"], "enabled": False,
                                    "contact_id": "c1"}),
        "姓名自动与联系人保持一致", "关联时姓名不一致被拒绝")
    r = console.target_add({"name": "张三", "times": [], "messages": ["x"], "enabled": False,
                            "contact_id": "c1"})
    check(r["name"] == "张三" and r["contact_id"] == "c1", "关联 c1 → 姓名自动取「张三」")
    check(r["contact"]["contact"] == "13800138000", "联系方式自动带入", str(r["contact"]))
    yaml_text = open(cfg.path, encoding="utf-8").read()
    check('contact_id: "c1"' in yaml_text, "config.yaml 写入 contact_id 键")
    check("头部注释必须保留" in yaml_text, "config 注释未被破坏")

    print("== 4. 防重复：同一联系人不能关联第二个任务 ==")
    expect_error(
        lambda: console.target_add({"name": "张三", "times": [], "messages": ["x"], "enabled": False,
                                    "contact_id": "c1"}),
        "存在重名联系人", "重复关联（同名目标）被拒绝")

    print("== 5. 解除关联 ==")
    r = console.target_update(2, {"contact_id": ""})
    check(r["contact_id"] is None and r["contact"] is None, "解除后视图为空")
    yaml_text = open(cfg.path, encoding="utf-8").read()
    check("contact_id" not in yaml_text.split("targets:")[1], "config.yaml 中 contact_id 键已移除（无空值残留）")

    print("== 6. 换绑另一个联系人（姓名跟随） ==")
    r = console.target_update(2, {"contact_id": "c2"})
    check(r["name"] == "示例联系人B" and r["contact_id"] == "c2", "换绑 c2 → 姓名自动改为「示例联系人B」")
    check(r["contact"]["contact_type"] == "未登记", "未登记号码的联系人同样可关联")

    print("== 7. 有关联时删除联系人被拒绝 ==")
    expect_error(lambda: console.contact_delete(2), "先到「发送任务」", "删除被关联联系人被拒绝")
    check(len(store.contacts) == 2, "联系人未被删除")

    print("== 8. 联系人改名自动同步关联任务 ==")
    console.contact_update(2, {"name": "示例联系人B2"})
    r = console.targets_list()["targets"][1]
    check(r["name"] == "示例联系人B2" and r["contact_id"] == "c2", "任务姓名同步为「示例联系人B2」")
    yaml_text = open(cfg.path, encoding="utf-8").read()
    check('name: "示例联系人B2"' in yaml_text, "config.yaml 目标名已同步")
    check("头部注释必须保留" in yaml_text, "再次确认注释保留")

    print("== 9. 悬空 contact_id 在保存时被拦截 ==")
    dangling = {"name": "悬空目标", "enabled": False, "approved": False,
                "times": [], "messages": ["x"], "contact_id": "c99"}
    expect_error(lambda: console._save_targets([dangling], "t"), "不存在", "悬空 id 被校验拒绝")
    check("c99" not in open(cfg.path, encoding="utf-8").read(), "配置未被污染")

    print("== 10. 老目标（无关联）不受影响 ==")
    rows = console.targets_list()["targets"]
    check(rows[0]["name"] == "老目标" and rows[0]["contact_id"] is None, "无关联目标照常工作")
    # 张三已无任务关联（第 5 步解除了），删除应成功
    try:
        console.contact_delete(1)
        check(True, "未关联联系人可正常删除")
    except Exception as exc:
        check(False, "未关联联系人可正常删除", str(exc))

    shutil.rmtree(tmp, ignore_errors=True)
    print()
    if FAILS:
        print(f"❌ 失败 {len(FAILS)} 项：{FAILS}")
        return 1
    print("✅ 全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
