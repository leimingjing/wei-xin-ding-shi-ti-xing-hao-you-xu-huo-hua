# -*- coding: utf-8 -*-
"""校准工具：把程序将要点击/比对的位置画在截图上，方便调整 config.yaml 里的比例。

用法：
    python tools/calibrate.py
不会发送任何消息，只截图并标注位置。
"""
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from PIL import ImageDraw, ImageGrab  # noqa: E402

from wechat_auto.input import kbdmouse  # noqa: E402,F401  开启 DPI 感知，保证坐标与运行时一致
from wechat_auto.config_loader import Config  # noqa: E402
from wechat_auto.wechat.locator import WeChatLocator, rect_tuple  # noqa: E402
from wechat_auto.wechat.window import WeChatWindow  # noqa: E402


class Log:
    def info(self, m):
        print(m)

    warning = error = info


def main():
    cfg = Config(ROOT)
    logger = Log()
    window = WeChatWindow(cfg.wechat, logger)
    window.ensure_running()
    window.activate()

    rect = rect_tuple(window.control)
    print(f"窗口矩形: left={rect[0]} top={rect[1]} {rect[2]}x{rect[3]}")

    locator = WeChatLocator(rect, None, logger, None, cfg.wechat)
    points = {"search_box": locator.point("search_box"), "input_box": locator.point("input_box")}
    bands = {"title_band": locator.band("title_band"), "message_area": locator.band("message_area")}

    margin = 80
    bbox = (rect[0] - margin, rect[1] - margin, rect[0] + rect[2] + margin, rect[1] + rect[3] + margin)
    image = ImageGrab.grab(bbox=bbox, all_screens=True)
    draw = ImageDraw.Draw(image)
    ox, oy = bbox[0], bbox[1]

    for name, (x, y) in points.items():
        print(f"{name}: 屏幕坐标 ({x}, {y})")
        draw.ellipse((x - ox - 8, y - oy - 8, x - ox + 8, y - oy + 8), outline=(255, 0, 0), width=3)
        draw.text((x - ox + 12, y - oy - 8), name, fill=(255, 0, 0))

    for name, (x, y, w, h) in bands.items():
        print(f"{name}: left={x} top={y} {w}x{h}")
        draw.rectangle((x - ox, y - oy, x - ox + w, y - oy + h), outline=(0, 160, 255), width=3)
        draw.text((x - ox + 4, y - oy - 16), name, fill=(0, 160, 255))

    out_dir = os.path.join(ROOT, "logs")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "calibrate.png")
    image.save(out)
    print(f"\n校准图已保存: {out}")
    print("请打开查看：红点是否落在搜索框 / 输入框上，蓝框是否覆盖会话标题与消息区。")
    print("位置不对就修改 config.yaml 中 wechat.ratios 的对应比例，再重跑本工具。")


if __name__ == "__main__":
    main()
