# -*- coding: utf-8 -*-
"""候选行过滤器离线自检：不用打开微信，拿一张搜索面板截图即可验证。

背景（2026-09-12 事故）：选人逻辑曾只按「左侧彩色头像」抓行，
搜「示例联系人A」时每次都点到面板顶部「最常使用」里的群聊行，
还把「闲鱼教程 (8)」的会话标题污染成了参考图。
修复后联系人行靠「单行名字 vs 名字+副标题（两行文字）」区分，
本脚本用于在改参数后快速回归验证。

用法（在项目根目录）：
    python tools/test_row_filter.py <整窗截图.png> [--crop X0 Y0 X1 Y1]

截图要求：包含微信搜索面板的任意截图（手动在微信里搜一次目标昵称后截屏）。
脚本会裁出面板区、缩放到 search_results band 的实际尺寸
（默认 480x843，与 locator.py 的 DEFAULT_LAYOUT 一致），
然后跑与线上完全相同的「头像检测 + 行分类」，逐行输出判定。
"""
import argparse
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import cv2  # noqa: E402
import numpy as np  # noqa: E402
from PIL import Image  # noqa: E402

from wechat_auto.wechat.locator import WeChatLocator, avatar_mask  # noqa: E402


class _Logger:
    def info(self, msg):
        print(f"[INFO] {msg}")

    def warning(self, msg):
        print(f"[WARN] {msg}")

    def error(self, msg):
        print(f"[ERROR] {msg}")


def detect_avatar_rows(img):
    """与 WeChatLocator.find_contact_rows 相同的头像检测（共用 avatar_mask）。"""
    mask = avatar_mask(img)
    if mask is None:
        print("[ERROR] 缺少 cv2/numpy，无法检测")
        return []
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    s = cv2.split(hsv)[1]
    rows = []
    for c in contours:
        x, y, w, h = cv2.boundingRect(c)
        if h < 30 or w < 30 or h > 120 or w > 200:
            continue
        rows.append((x + w // 2, y + h // 2, int(s[y:y + h, x:x + w].mean())))
    rows.sort(key=lambda r: r[1])
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("screenshot")
    ap.add_argument("--crop", nargs=4, type=int, default=None,
                    metavar=("X0", "Y0", "X1", "Y1"),
                    help="搜索面板在截图里的区域；默认按 1645x1006 窗口比例自动猜")
    ap.add_argument("--band-w", type=int, default=480)
    ap.add_argument("--band-h", type=int, default=843)
    args = ap.parse_args()

    pil = Image.open(args.screenshot).convert("RGB")
    width, height = pil.size
    crop = args.crop or [int(width * 0.06), int(height * 0.14), int(width * 0.36), height]
    pil = pil.crop(tuple(crop)).resize((args.band_w, args.band_h))
    img = np.array(pil)[:, :, ::-1].copy()   # BGR

    loc = WeChatLocator((0, 0, 1645, 1006), None, _Logger(), vision=None)
    bx, by, bw, bh = loc.band("search_results")
    loc._panel_img = img

    rows_local = detect_avatar_rows(img)
    rows = [(bx + x, by + y, sat) for (x, y, sat) in rows_local]
    print(f"截图 {width}x{height}，裁剪 {crop}，缩放到 band {bw}x{bh}")
    print(f"头像检测到 {len(rows)} 个候选行：")
    for r in rows:
        lines = loc.row_text_lines(r)
        right = loc.row_has_right_text(r)
        print(f"  y={r[1]:4d}  文字带数={lines:2d}  右侧有文字={right}")

    ordered = loc.filter_contact_rows(rows)
    flags = loc._row_flags
    print("\n过滤后的点击顺序：")
    for r, clean in zip(ordered, flags):
        mark = "★ 纯联系人行（优先点击）" if clean else "  群聊/记录行（仅兜底）"
        print(f"  y={r[1]:4d}  {mark}")
    clean_n = sum(flags)
    print(f"\n结论：共 {len(ordered)} 行，其中纯联系人行 {clean_n} 个")
    if ordered:
        who = "是" if flags[0] else "否 —— 需要人工检查过滤参数！"
        print(f"第一个将被点击的行 y={ordered[0][1]}，纯联系人行：{who}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
