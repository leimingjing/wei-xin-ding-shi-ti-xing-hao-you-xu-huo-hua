# -*- coding: utf-8 -*-
"""续火花项目修复项自检：P0-1 … P3-4 逐项可执行断言。

用法：
    python tools/verify_fix.py [--root <项目根>] [--work <临时目录>]

特性：
- 只读检查 + 在独立端口上启停内置控制台做 HTTP 闸门测试；
- 不发送任何消息、不修改用户数据（幂等/锁测试全在临时目录里跑）；
- 逐项打印 PASS/FAIL，末尾输出 SUMMARY_JSON{"pass":n,"fail":n}；
  全部通过退出码 0，否则 1。

对应修复清单：
  P0-1 MAX_CANDIDATES 未定义        P0-2 results_before 未初始化 / 重复发送
  P1-1 控制台无来源校验（CSRF）      P1-2 单实例锁被误删
  P1-3 打包后校准失效                P1-4 自检登录页检测恒不执行
  P2-1 配置模板/活配置分叉           P2-2 参考图路径未消毒（穿越）
  P2-3 dist 活数据丢失风险           P2-4 并发触发发送 / 状态文件半截 JSON
  P2-5 窗口基准尺寸无告警            P3-3 日志噪音淹没真实错误
  P3-4 diff_ratio 无效参数
"""
from __future__ import annotations

import argparse
import ast
import http.client
import json
import os
import shutil
import sys
import tempfile

RESULTS = []


def check(group: str, name: str, cond: bool, detail: str = "") -> bool:
    ok = bool(cond)
    RESULTS.append({"group": group, "name": name, "ok": ok, "detail": detail})
    print(f"[{'PASS' if ok else 'FAIL'}] {group} · {name}" + (f" ｜ {detail}" if detail else ""))
    return ok


def read(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        return fh.read()


# ---------------------------------------------------------------- 静态检查
def static_checks(root: str):
    g = "静态"
    sender = read(os.path.join(root, "wechat_auto", "sender.py"))
    webapp = read(os.path.join(root, "wechat_auto", "webapp.py"))
    safety = read(os.path.join(root, "wechat_auto", "safety.py"))
    vision = read(os.path.join(root, "wechat_auto", "vision.py"))
    loader = read(os.path.join(root, "wechat_auto", "config_loader.py"))
    app = read(os.path.join(root, "app.py"))
    client = read(os.path.join(root, "client.py"))
    human = read(os.path.join(root, "wechat_auto", "input", "human.py"))
    index = read(os.path.join(root, "web", "index.html"))

    check(g, "P0-1 常量 CANDIDATE_LIMIT 已定义", "CANDIDATE_LIMIT = 3" in sender)
    check(g, "P0-1 搜索候选已限流", "[:CANDIDATE_LIMIT]" in sender)
    _names = {n.id for n in ast.walk(ast.parse(sender)) if isinstance(n, ast.Name)}
    check(g, "P0-1 未定义名 MAX_CANDIDATES 已清除（AST 层）", "MAX_CANDIDATES" not in _names)
    check(g, "P0-2 results_before 前置初始化", "results_before = None" in sender)
    check(g, "P0-2 收尾统一 finally", "finally:" in sender)
    check(g, "P0-2 幂等保护接入 sender", ("already_sent" in sender) and ("mark_sent" in sender))
    check(g, "P1-1 自定义头闸门存在", "CSRF_HEADER" in webapp)
    check(g, "P1-1 来源校验 _check_origin", "def _check_origin" in webapp)
    check(g, "P1-1 令牌校验 _check_token", "def _check_token" in webapp)
    check(g, "P1-1 前端已带 X-Requested-With", "X-Requested-With" in index)
    check(g, "P1-2 锁创建者标记 _created", "self._created" in safety)
    check(g, "P1-3 校准改用 runpy.run_path", "runpy.run_path" in webapp)
    check(g, "P1-4 自检改问窗口对象", ("win.control = found" in app) and ("win.is_login_window()" in app))
    check(g, "P2-1 配置回退 config.example.yaml", "config.example.yaml" in loader)
    check(g, "P2-2 参考图路径唯一实现", "def ref_path_for" in vision)
    check(g, "P2-2 各调用方统一导入",
          ("from wechat_auto.vision import ref_path_for" in webapp)
          and ("from wechat_auto.vision import ref_path_for" in app))
    check(g, "P2-4 触发发送互斥", "self.running" in webapp)
    check(g, "P2-4 状态文件原子写", "os.replace" in loader)
    check(g, "P2-5 窗口基准参与自检", "window_baseline" in app and "window_baseline" in webapp)
    check(g, "P2-3 空消息直接拒发", "if not message:" in sender)
    check(g, "P2-3 剪贴板用后还原",
          ("_clip_saved" in human) and ("def restore_clipboard" in human)
          and ("human.restore_clipboard()" in sender))
    check(g, "P3-1 程序缺陷/环境未就绪不重试",
          ("_NO_RETRY_ERRORS" in sender) and ("环境未就绪，不重试" in sender))
    check(g, "P3-2 收尾统一 finally（面板/窗口/剪贴板）",
          ("清理搜索面板" in sender) and ("还原窗口" in sender) and ("还原剪贴板" in sender))
    check(g, "P3-3 HTTP 噪音已压制", "_silence_http_noise" in client)
    check(g, "P3-4 diff_ratio 有效参数 noise", "noise: int = 24" in vision)
    check(g, "P3-4 成功判据可配置", "message_diff_threshold" in loader)


# ---------------------------------------------------------------- 单元检查
def unit_checks(root: str, work: str):
    g = "单元"
    sys.path.insert(0, root)
    sys.path.insert(0, os.path.join(root, "workbench"))

    try:
        import app  # noqa: F401
        import client  # noqa: F401
        from wechat_auto import sender, vision  # noqa: F401
        from wechat_auto.config_loader import Config
        from wechat_auto.safety import SingleInstance
        from wechat_auto.settings import Settings  # noqa: F401
        from wechat_auto.webapp import WebConsole

        check(g, "全部核心模块可导入（无 NameError/ImportError）", True)
    except Exception as exc:
        check(g, "全部核心模块可导入（无 NameError/ImportError）", False, repr(exc))
        return

    check(g, "P0-1 CANDIDATE_LIMIT == 3", sender.CANDIDATE_LIMIT == 3,
          f"值={sender.CANDIDATE_LIMIT}")

    # P2-2 路径消毒
    p_ok = vision.ref_path_for(root, "../evil").replace("\\", "/").endswith("/assets/refs/evil.png")
    p_bad = ".." not in os.path.basename(vision.ref_path_for(root, "../../x:y"))
    check(g, "P2-2 路径穿越被消毒", p_ok and p_bad,
          f"'../evil' -> {os.path.basename(vision.ref_path_for(root, '../evil'))}")
    check(g, "P2-2 非法字符替换且落在 refs 内",
          os.path.dirname(vision.ref_path_for(root, 'a/b:c?d*e')).replace("\\", "/").endswith("assets/refs"),
          os.path.basename(vision.ref_path_for(root, 'a/b:c?d*e')))

    # P2-1 源码目录回退模板
    cfg = Config(root)
    check(g, "P2-1 源码根无活配置时回退模板",
          os.path.basename(cfg.path) == "config.example.yaml", cfg.path)

    # P0-2 幂等状态（在临时目录里跑，不碰用户数据）
    idem_root = tempfile.mkdtemp(prefix="idem_", dir=work)
    os.makedirs(os.path.join(idem_root, "config"), exist_ok=True)
    shutil.copyfile(os.path.join(root, "config", "config.example.yaml"),
                    os.path.join(idem_root, "config", "config.yaml"))
    c2 = Config(idem_root)
    fresh = not c2.already_sent("__verify__")
    c2.mark_sent("__verify__")
    sent = c2.already_sent("__verify__")
    c2.state["__verify__"]["last_sent"] = "2000-01-01 00:00:00"
    old = not c2.already_sent("__verify__")
    check(g, "P0-2 幂等：未发过=False / 刚发过=True / 过期=False",
          fresh and sent and old, f"fresh={fresh} sent={sent} old={old}")

    # P1-2 单实例锁语义
    lock_root = os.path.join(work, "lockcase")
    os.makedirs(lock_root, exist_ok=True)
    lock_file = os.path.join(lock_root, "logs", "wechat_auto.lock")
    os.makedirs(os.path.dirname(lock_file), exist_ok=True)

    a = SingleInstance(lock_root)
    got_a = a.acquire()
    written = os.path.exists(lock_file) and int(read(lock_file).strip()) == os.getpid()
    a.release()
    released = not os.path.exists(lock_file)
    check(g, "P1-2 创建者获取→写入本进程 pid→释放即删锁",
          got_a and written and released)

    with open(lock_file, "w", encoding="utf-8") as fh:
        fh.write("999999")          # 已死进程留下的僵尸锁
    b = SingleInstance(lock_root)
    got_b = b.acquire()             # 应能夺锁
    b.release()
    check(g, "P1-2 僵尸锁可被夺回", got_b and not os.path.exists(lock_file))

    c = SingleInstance(lock_root)
    c.acquire()
    d = SingleInstance(lock_root)   # 同进程重复获取（app.py 持锁 + Sender 再拿）
    got_d = d.acquire()
    d.release()                     # 非创建者释放不得删锁
    kept = os.path.exists(lock_file)
    c.release()
    check(g, "P1-2 同进程复用放行、非创建者释放不删锁",
          got_d and kept and not os.path.exists(lock_file), f"kept={kept}")

    # ------------------------------------------------------------ HTTP 闸门
    gh = "HTTP"
    from contacts import ContactStore
    from wechat_auto.webapp import WebConsole as WC

    store = ContactStore(os.path.join(work, "contacts.json"))
    console = WC(root, store, cfg=Config(root))
    port = None
    for candidate in (8799, 8801, 8802, 8803, 8804):
        try:
            port = console.start(candidate, open_browser=False)
            break
        except OSError:
            continue
    if port is None:
        check(gh, "控制台可在独立端口启动", False, "8799/8801-8804 均被占用")
        return

    check(gh, "控制台启动", True, f"http://127.0.0.1:{port}")

    def req(method, path, headers=None, body=None):
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=6)
        conn.request(method, path, body=body, headers=headers or {})
        resp = conn.getresponse()
        data = resp.read().decode("utf-8", "replace")
        conn.close()
        return resp.status, data

    try:
        st, _ = req("GET", "/")
        check(gh, "首页可访问", st == 200, f"status={st}")

        st, data = req("GET", "/api/overview")
        check(gh, "只读接口可访问且回显校准基准",
              st == 200 and "window_baseline" in data, f"status={st}")

        st, data = req("POST", "/api/overview", headers={"Content-Length": "0"})
        check(gh, "写操作缺 X-Requested-With 头 → 403 csrf",
              st == 403 and '"csrf"' in data, f"status={st}")

        st, _ = req("POST", "/api/__nonexistent__",
                     headers={"X-Requested-With": "wechat-auto-console", "Content-Length": "0"})
        check(gh, "带头写操作放行（落到 404 表示闸门已过）", st == 404, f"status={st}")

        st, data = req("PUT", "/api/__nonexistent__", headers={"Content-Length": "0"})
        check(gh, "PUT 缺令牌 → 403 csrf", st == 403 and '"csrf"' in data, f"status={st}")
        st, _ = req("PUT", "/api/__nonexistent__",
                    headers={"X-Requested-With": "wechat-auto-console", "Content-Length": "0"})
        check(gh, "PUT 带令牌放行（落到 404）", st == 404, f"status={st}")
        st, data = req("DELETE", "/api/__nonexistent__", headers={"Content-Length": "0"})
        check(gh, "DELETE 缺令牌 → 403 csrf", st == 403 and '"csrf"' in data, f"status={st}")
        st, _ = req("DELETE", "/api/__nonexistent__",
                    headers={"X-Requested-With": "wechat-auto-console", "Content-Length": "0"})
        check(gh, "DELETE 带令牌放行（落到 404）", st == 404, f"status={st}")

        st, _ = req("GET", "/api/overview", headers={"Origin": "http://evil.example"})
        check(gh, "跨站 Origin → 403", st == 403, f"status={st}")

        st, _ = req("GET", "/api/overview", headers={"Host": "evil.example"})
        check(gh, "非回环 Host（DNS rebinding）→ 403", st == 403, f"status={st}")

        st, _ = req("GET", "/api/overview", headers={"Host": "127.0.0.1:%d" % port})
        check(gh, "合法 Host 放行", st == 200, f"status={st}")
    finally:
        console.stop()


# ---------------------------------------------------------------- 打包产物
def dist_checks(root: str):
    g = "打包态"
    dist = os.path.join(root, "dist", "微信定时发送")
    if not os.path.isdir(dist):
        check(g, "dist 目录存在", False, dist)
        return
    exe = os.path.join(dist, "微信定时发送.exe")
    check(g, "exe 存在", os.path.isfile(exe), exe)
    check(g, "_internal 完整",
          os.path.isfile(os.path.join(dist, "_internal", "base_library.zip")))
    check(g, "打包内 web/index.html 含 CSRF 头",
          "X-Requested-With" in read(os.path.join(dist, "web", "index.html")))
    cfg_txt = read(os.path.join(dist, "config", "config.yaml"))
    check(g, "活配置保留 window_baseline", "window_baseline" in cfg_txt)
    check(g, "活配置保留 dry_run 开关", "dry_run" in cfg_txt)
    for live in ("config", "data", "assets", "logs"):
        check(g, f"活数据目录保留 {live}/", os.path.isdir(os.path.join(dist, live)))
    check(g, "打包内同步了自检脚本",
          os.path.isfile(os.path.join(dist, "tools", "verify_fix.py")))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    parser.add_argument("--work", default=None)
    args = parser.parse_args()
    root = os.path.abspath(args.root)
    work = args.work or tempfile.mkdtemp(prefix="verify_fix_")
    os.makedirs(work, exist_ok=True)
    print(f"项目根：{root}\n临时目录：{work}\n" + "=" * 66)

    static_checks(root)
    unit_checks(root, work)
    dist_checks(root)

    passed = sum(1 for r in RESULTS if r["ok"])
    failed = len(RESULTS) - passed
    print("=" * 66)
    print(f"结果：PASS {passed} / FAIL {failed} / 共 {len(RESULTS)}")
    for r in RESULTS:
        if not r["ok"]:
            print(f"  ✗ [{r['group']}] {r['name']} | {r['detail']}")
    print("SUMMARY_JSON=" + json.dumps(
        {"pass": passed, "fail": failed, "total": len(RESULTS),
         "failed_items": [f"{r['group']}·{r['name']}" for r in RESULTS if not r["ok"]]},
        ensure_ascii=False))
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
