# -*- coding: utf-8 -*-
"""界面预览与对齐自检。

两种输出：
  1. 纯文本布局：逐行校验显示宽度不超过容器宽度，用来证明中文/英文混排不串列；
     （按字符显示宽度计算，全角占 2 列）
  2. HTML 预览：把 ANSI 真彩色转成 span，直观看深色/浅色两套色板的实际效果。

这个脚本只读取界面层，不写任何业务数据。
"""
from __future__ import annotations

import argparse
import contextlib
import html
import io
import os
import re
import shutil
import sys
import tempfile
import types
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "workbench"))

import theme as th  # noqa: E402
from contacts import ContactStore  # noqa: E402
from ui import Workbench  # noqa: E402
from app import TaskController  # noqa: E402  复用真实状态文本，避免预览与实现漂移

REAL_SIZE = shutil.get_terminal_size
REAL_COLUMNS = th.Theme._terminal_columns

TARGETS = [
    {"name": "张三", "enabled": True, "approved": True, "times": ["08:30"]},
    {"name": "李四", "enabled": True, "approved": False, "times": ["21:00", "22:15"]},
]


class StubCfg:
    def __init__(self, root):
        self.root = root
        self.path = os.path.join(root, "config.yaml")
        self.safety = {"dry_run": True}
        self.targets = TARGETS

    def target_times(self, target):
        return target["times"]


class StubScheduler:
    def __init__(self, moment):
        self.moment = moment

    def get_jobs(self):
        return [types.SimpleNamespace(next_run_time=self.moment)]

    def pause(self):
        pass

    def resume(self):
        pass


def patch_size(cols: int):
    """把"终端列数"钉死成指定值。

    必须同时替换 Theme._terminal_columns：主题会优先直接问控制台要列数，
    只改 shutil 的话，在真实终端里跑自检时补丁会被绕过，窄布局根本没被测到。
    """
    shutil.get_terminal_size = lambda fallback=(96, 30): types.SimpleNamespace(
        columns=cols, lines=40)
    th.Theme._terminal_columns = staticmethod(lambda: cols)


def unpatch_size():
    shutil.get_terminal_size = REAL_SIZE
    th.Theme._terminal_columns = REAL_COLUMNS


def make_store(root: str, fill: bool = True) -> ContactStore:
    store = ContactStore(os.path.join(root, "contacts.json"))
    if fill:
        store.add("张三", "13800138000", "2026-09-12 08:30")
        store.add("李四", "lisi@example.com", "2026-09-13 21:00")
        store.add("王小明", "wang.xiaoming@long-domain.example.com", "2026-09-14 07:45")
    return store


def make_workbench(root: str, fill: bool = True, with_task: bool = True, notices=None):
    # 每个页面用独立的数据文件，避免多次渲染互相累加
    case_dir = tempfile.mkdtemp(prefix="ui-case-")
    os.makedirs(os.path.join(case_dir, "assets", "refs"), exist_ok=True)
    open(os.path.join(case_dir, "assets", "refs", "张三.png"), "wb").close()
    store = make_store(case_dir, fill)
    ctrl = None
    if with_task:
        cfg = StubCfg(case_dir)
        ctrl = TaskController(StubScheduler(datetime(2026, 9, 12, 8, 32, 0)),
                              cfg, types.SimpleNamespace(info=lambda *a: None), {"paused": False})
    return Workbench(store, ctrl, notices=notices)


class EchoStdin(io.StringIO):
    """模拟真实终端的行回声：管道里 input() 不回声，会把下一行输出粘到提示行上。"""

    def readline(self, *args, **kwargs):
        line = super().readline(*args, **kwargs)
        if line:
            sys.stdout.write(line if line.endswith("\n") else line + "\n")
        return line


def capture(fn, stdin_text: str = "") -> str:
    buf = io.StringIO()
    old_stdin = sys.stdin
    sys.stdin = EchoStdin(stdin_text)
    try:
        with contextlib.redirect_stdout(buf):
            fn()
    finally:
        sys.stdin = old_stdin
    return buf.getvalue()


# ---------------------------------------------------------------- 页面清单
def collect(mode: str, color: str, cols: int):
    """返回 (页面列表, 容器宽度)。每个页面用独立的数据副本，互不干扰。"""
    tmp = tempfile.mkdtemp(prefix="ui-preview-")
    os.makedirs(os.path.join(tmp, "assets", "refs"), exist_ok=True)
    open(os.path.join(tmp, "assets", "refs", "张三.png"), "wb").close()
    patch_size(cols)
    th.init(mode=mode, color=color, tui=False)
    try:
        box_width = th.get().width
        pages = []

        wb = make_workbench(tmp)
        pages.append(("主菜单", capture(lambda: wb.flush(wb.home_lines()))))

        wb = make_workbench(tmp, notices=[
            ("WARNING", "当前没有任何定时任务：targets 里没有 enabled: true 的联系人。"),
            ("INFO", "已注册定时任务：每天 08:30（mon,tue,wed,thu,fri,sat,sun）→ ['张三']"),
        ])
        pages.append(("主菜单 · 带启动提醒", capture(lambda: wb.flush(wb.home_lines()))))

        wb = make_workbench(tmp)
        pages.append(("联系人列表 + 详情", capture(wb.action_list, "1\n")))

        wb = make_workbench(tmp, fill=False)
        pages.append(("空状态", capture(wb.action_list)))

        wb = make_workbench(tmp)
        pages.append(("新增 · 校验失败反馈", capture(wb.action_add, "李四\n12345\n")))

        wb = make_workbench(tmp)
        pages.append(("编辑 · 字段子菜单", capture(wb.action_edit, "1\n")))

        wb = make_workbench(tmp)
        pages.append(("删除 · 二次确认", capture(wb.action_delete, "1\nn\n")))

        wb = make_workbench(tmp)
        pages.append(("发送任务状态", capture(wb.action_task_status)))

        wb = make_workbench(tmp)
        pages.append(("搜索", capture(wb.action_search, "王\n")))

        wb = make_workbench(tmp)
        pages.append(("无效序号 + 退出", capture(wb.run, "9\n\n0\n")))
        return pages, box_width
    finally:
        unpatch_size()


# ---------------------------------------------------------------- 自检
def check_alignment(pages, cols: int, theme_obj) -> list:
    """逐行校验：任何一行的显示宽度都不得超过容器宽度。"""
    problems = []
    for name, text in pages:
        for i, line in enumerate(text.split("\n"), start=1):
            width = th.display_width(line)
            if width > theme_obj.width:
                problems.append(f"{name} 第 {i} 行 宽 {width} > {theme_obj.width}：{line!r}")
    return problems


# ---------------------------------------------------------------- HTML
SGR = re.compile(r"\x1b\[([0-9;]*)m")


def ansi_to_html(text: str) -> str:
    """逐段转换：每个 SGR 段各自成一个 span，遇到重置码才恢复默认。"""

    def wrap(piece: str, color, bold: bool) -> str:
        if not piece:
            return ""
        escaped = html.escape(piece)
        if not color and not bold:
            return escaped
        rules = []
        if color:
            rules.append(f"color:{color}")
        if bold:
            rules.append("font-weight:600")
        return f'<span style="{";".join(rules)}">{escaped}</span>'

    out, pos, color, bold = [], 0, None, False
    for match in SGR.finditer(text):
        out.append(wrap(text[pos:match.start()], color, bold))
        params = [p for p in match.group(1).split(";") if p]
        if not params or params == ["0"]:
            color, bold = None, False
        elif params[0] == "38" and len(params) >= 5 and params[1] == "2":
            color = f"rgb({params[2]},{params[3]},{params[4]})"
        elif params[0] == "1":
            bold = True
        pos = match.end()
    out.append(wrap(text[pos:], color, bold))
    return "".join(out)


PAGE_CSS = """
:root{
  --bg:#0B0D11; --panel:#12151B; --line:#232A33; --text:#E6E8EB;
  --muted:#9AA4B2; --accent:#07C160; --radius:14px;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);
  font-family:-apple-system,"Segoe UI","Microsoft YaHei UI",system-ui,sans-serif;
  -webkit-font-smoothing:antialiased}
.wrap{max-width:1180px;margin:0 auto;padding:40px 24px 80px}
h1{font-size:24px;letter-spacing:.2px;margin:0 0 8px}
.lede{color:var(--muted);font-size:14px;line-height:1.7;margin:0 0 24px;max-width:820px}
.lede code{background:#1B2028;border:1px solid var(--line);border-radius:5px;padding:1px 5px;
  font-size:12.5px;color:#B9C2CF}
.bar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:0 0 26px}
.seg{display:inline-flex;background:#161A20;border:1px solid var(--line);border-radius:999px;padding:3px}
.seg button{border:0;background:transparent;color:var(--muted);font-size:13px;padding:6px 14px;
  border-radius:999px;cursor:pointer;font-family:inherit}
.seg button.on{background:#222A33;color:#fff}
.group{margin:0 0 34px}
.group > h2{font-size:15px;font-weight:600;color:var(--text);margin:0 0 4px;
  display:flex;align-items:center;gap:8px}
.group > h2 span.dot{width:7px;height:7px;border-radius:50%;background:var(--accent)}
.group > p{color:var(--muted);font-size:13px;margin:0 0 14px;line-height:1.65}
.term{border-radius:var(--radius);overflow:hidden;border:1px solid var(--line);
  box-shadow:0 18px 40px -18px rgba(0,0,0,.75);background:#0C0E12}
.term.light{box-shadow:0 18px 40px -18px rgba(31,35,40,.35);border-color:#D8DEE5;background:#fff}
.tbar{display:flex;align-items:center;gap:7px;padding:9px 13px;border-bottom:1px solid var(--line);
  background:#151921}
.term.light .tbar{background:#F4F6F8;border-color:#E3E8EE}
.tbar i{width:10px;height:10px;border-radius:50%;display:block}
.tbar b{font-size:12px;font-weight:500;color:var(--muted);margin-left:6px;
  font-family:"MS Gothic",Consolas,monospace}
pre{margin:0;padding:16px 18px;overflow-x:auto;font-size:13px;line-height:1.5;
  font-family:"MS Gothic",SimSun,Consolas,monospace;white-space:pre;tab-size:4}
.term.light pre{color:#1F2328}
body.look pre{font-family:Consolas,"Cascadia Mono",monospace}
.note{color:var(--muted);font-size:12.5px;margin:8px 0 0;line-height:1.7}
.grid{display:grid;gap:22px;grid-template-columns:repeat(auto-fit,minmax(430px,1fr))}
@media (max-width:560px){.wrap{padding:24px 14px 60px}pre{font-size:11.5px;padding:12px}}
"""

PAGE_JS = """
<script>
document.querySelectorAll('[data-font]').forEach(function(b){
  b.addEventListener('click', function(){
    document.querySelectorAll('[data-font]').forEach(function(x){x.classList.remove('on');});
    b.classList.add('on');
    document.body.classList.toggle('look', b.dataset.font === 'look');
  });
});
</script>
"""


def panel(title: str, text: str, mode: str) -> str:
    body = ansi_to_html(text)
    cls = "term light" if mode == "light" else "term"
    bar_bg = "#F4F6F8" if mode == "light" else "#151921"
    dots = "".join(
        f'<i style="background:{c}"></i>' for c in ("#FF5F57", "#FEBC2E", "#28C840")
    )
    label = "管理员工作台 — 浅色终端" if mode == "light" else "管理员工作台 — 深色终端"
    return (
        f'<div class="{cls}">'
        f'<div class="tbar" style="background:{bar_bg}">{dots}<b>{label}</b></div>'
        f"<pre>{body}</pre></div>"
    )


def build_html(groups) -> str:
    """groups: [(小标题, 说明, [(页面名, 文本, mode)])]"""
    parts = []
    for head, desc, items in groups:
        panels = "".join(panel(name, text, mode) for name, text, mode in items)
        cls = "grid" if len(items) > 1 else ""
        parts.append(
            f'<div class="group"><h2><span class="dot"></span>{html.escape(head)}</h2>'
            f"<p>{desc}</p><div class='{cls}'>{panels}</div></div>"
        )
    return (
        '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        "<title>微信定时发送 · 界面预览</title>"
        f"<style>{PAGE_CSS}</style></head><body><div class='wrap'>"
        "<h1>微信定时发送 · 管理员工作台</h1>"
        "<p class='lede'>控制台界面的配色与排版预览。程序本身没有换技术栈——"
        "仍然是纯 Python 标准库在 cmd/PowerShell 里跑，"
        "这里只是把 ANSI 真彩色序列转成网页样式，方便你在浏览器里一次看全。</p>"
        "<p class='lede'>页面里出现的<b>圆角、投影</b>属于终端窗口自身（控制台程序无法绘制），"
        "卡片层级是用 Unicode 圆角边框 <code>╭╮╰╯</code> + 描边色深浅做的；"
        "同理<b>字号</b>由终端设置决定，程序只用色阶和粗体建立层级。</p>"
        "<div class='bar'><span style='color:#9AA4B2;font-size:13px'>等宽字体：</span>"
        "<div class='seg'>"
        "<button class='on' data-font='align'>严格对齐（推荐）</button>"
        "<button data-font='look'>观感优先</button>"
        "</div></div>"
        + "".join(parts)
        + "</div>" + PAGE_JS + "</body></html>"
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cols", type=int, default=0, help="只跑指定宽度")
    parser.add_argument("--html", default="", help="输出 HTML 预览路径")
    parser.add_argument("--plain", action="store_true", help="打印纯文本布局")
    args = parser.parse_args()

    widths = [args.cols] if args.cols else [120, 100, 86, 62, 44]
    failures = []
    for cols in widths:
        for mode in ("dark", "light"):
            pages, box_width = collect(mode, "off", cols)
            problems = check_alignment(pages, cols, types.SimpleNamespace(width=box_width))
            failures += problems
            tag = f"{mode}/{cols}列 (容器宽 {box_width})"
            if problems:
                print(f"[FAIL] {tag} 发现 {len(problems)} 处溢出")
                for p in problems[:6]:
                    print("    " + p)
            else:
                print(f"[ OK ] {tag} {len(pages)} 个页面，全部行宽合规")
            if args.plain:
                print("-" * 70)
                for name, text in pages:
                    print(f"### {name}")
                    print(text)
                print("-" * 70)

    if args.html:
        wide_dark, _ = collect("dark", "truecolor", 120)
        narrow_dark, _ = collect("dark", "truecolor", 52)
        wide_light, _ = collect("light", "truecolor", 120)
        lookup_w = dict(wide_dark)
        lookup_n = dict(narrow_dark)
        lookup_l = dict(wide_light)
        groups = [
            ("主菜单", "页头 + 状态徽标条 + 分组导航。宽终端在右侧补说明文字（与卡片右缘对齐），窄终端自动省略。", [
                ("宽终端 120 列 · 深色", lookup_w["主菜单"], "dark"),
                ("宽终端 120 列 · 浅色", lookup_l["主菜单"], "light"),
            ]),
            ("响应式：窄终端", "同一份代码，52 列时徽标条自动换行，表格降级为堆叠布局，不再横向溢出。", [
                ("窄终端 52 列 · 深色", lookup_n["主菜单"], "dark"),
                ("窄终端 52 列 · 浅色", lookup_l["主菜单 · 带启动提醒"], "light"),
            ]),
            ("状态与提醒", "后台日志不再与菜单混排，收进卡片；深色/浅色两套色板对比度都经过调整。", [
                ("深色 · 启动提醒", lookup_w["主菜单 · 带启动提醒"], "dark"),
                ("浅色 · 启动提醒", lookup_l["主菜单 · 带启动提醒"], "light"),
            ]),
            ("联系人列表", "宽终端用等宽表格，余量自动补给会变长的那列（联系方式），长邮箱不再被截断；窄终端拆成多行卡片式条目。", [
                ("宽终端 · 表格", lookup_w["联系人列表 + 详情"], "dark"),
                ("窄终端 · 堆叠", lookup_n["联系人列表 + 详情"], "dark"),
            ]),
            ("空状态与表单反馈", "空状态给引导而不是一句「暂无数据」；校验失败用 × 徽标 + 折行说明。", [
                ("空状态", lookup_l["空状态"], "light"),
                ("校验失败", lookup_w["新增 · 校验失败反馈"], "dark"),
            ]),
            ("发送任务与危险操作", "闸门自检逐项着色（已批准/未批准、有参考图/缺参考图）；删除用红色描边卡片提高警示度。", [
                ("任务状态", lookup_w["发送任务状态"], "dark"),
                ("删除确认", lookup_l["删除 · 二次确认"], "light"),
            ]),
            ("编辑子菜单", "编辑只改一个字段：先给当前值卡片，再列可改字段，层级清晰。", [
                ("字段选择", lookup_l["编辑 · 字段子菜单"], "light"),
            ]),
        ]
        out = os.path.abspath(args.html)
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "w", encoding="utf-8") as fh:
            fh.write(build_html(groups))
        print(f"\nHTML 预览已写入：{out}")

    if failures:
        print(f"\n对齐自检未通过：{len(failures)} 处")
        return 1
    print("\n对齐自检全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
