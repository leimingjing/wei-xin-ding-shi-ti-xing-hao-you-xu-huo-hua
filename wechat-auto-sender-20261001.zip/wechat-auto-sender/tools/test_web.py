# -*- coding: utf-8 -*-
"""网页控制台集成测试：按 app.py 的真实接线启动调度器 + 控制台，再发请求自检。

运行：python tools/test_web.py
覆盖：overview 连接态、暂停/恢复、独立模式拒绝逻辑（反向）、页面可达。
"""
import json
import os
import sys
import time
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "workbench"))
os.chdir(ROOT)

import app as appmod  # noqa: E402
from contacts import ContactStore  # noqa: E402
from wechat_auto import logger as logutil  # noqa: E402
from wechat_auto.config_loader import Config  # noqa: E402
from wechat_auto.webapp import WebConsole  # noqa: E402

PORT = 8898
BASE = f"http://127.0.0.1:{PORT}"
PASS, FAIL = 0, 0


def check(name, cond, detail=""):
    global PASS, FAIL
    mark = "PASS" if cond else "FAIL"
    if cond:
        PASS += 1
    else:
        FAIL += 1
    print(f"  [{mark}] {name}" + (f"  {detail}" if detail and not cond else ""))


def req(path, method="GET", body=None):
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method,
                               headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(r, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        # 4xx 拒绝也是有效响应：返回 {ok:false, error:...} 供断言
        return json.loads(exc.read().decode("utf-8"))


def main():
    cfg = Config(ROOT)
    logger = logutil.setup(ROOT)
    scheduler = appmod.build_scheduler(cfg, logger)
    scheduler.start()
    state = {"paused": False}
    controller = appmod.TaskController(scheduler, cfg, logger, state)
    store = ContactStore(os.path.join(ROOT, "data", "contacts.json"))

    def rebuild():
        cfg.reload()
        scheduler.remove_all_jobs()
        if state.get("paused"):
            scheduler.pause()
        appmod.register_jobs(scheduler, cfg, logger)

    web = WebConsole(ROOT, store, cfg=cfg, controller=controller,
                     run_now=lambda real: appmod.web_run(cfg, logger, real=real),
                     logger=logger, on_config_change=rebuild)
    port = web.start(PORT)
    print(f"集成实例已启动：{BASE}" + ("（端口被占，自动换到这里）" if port != PORT else ""))
    base = BASE if port == PORT else f"http://127.0.0.1:{port}"

    # 备份真实配置，测试中的所有改动最后都会还原
    cfg_backup = open(cfg.path, "r", encoding="utf-8").read()
    contacts_path = os.path.join(ROOT, "data", "contacts.json")
    contacts_backup = open(contacts_path, "r", encoding="utf-8").read() if os.path.exists(contacts_path) else None

    try:
        d = req("/api/overview")["data"]
        check("overview 标记为已连接", d["connected"] is True)
        check("overview 返回下次执行时间", bool(d["next_run"]), d["next_run"])
        check("overview 读取到 targets 配置", len(d["targets"]) >= 1)

        with urllib.request.urlopen(base + "/", timeout=10) as resp:
            page = resp.read().decode("utf-8")
        check("首页 HTML 可达且含标题", "微信定时发送" in page and len(page) > 10000)

        d = req("/api/pause", "POST")["data"]
        check("暂停调度", d["paused"] is True)
        d = req("/api/overview")["data"]
        check("overview 反映已暂停", d["paused"] is True)
        d = req("/api/pause", "POST")["data"]
        check("恢复调度", d["paused"] is False)

        d = req("/api/run", "POST", {"real": True})
        check("正式发送缺少确认词被拒绝", d["ok"] is False and "正式发送" in d["error"])
        d = req("/api/run", "POST", {"real": True, "confirm": "错误词"})
        check("错误确认词被拒绝", d["ok"] is False)

        d = req("/api/kill", "POST")["data"]
        check("触发急停", d["kill_active"] is True)
        d = req("/api/run", "POST", {"real": False})
        check("急停期间触发发送被拒绝", d["ok"] is False and "急停" in d["error"])
        d = req("/api/kill", "DELETE")["data"]
        check("解除急停", d["kill_active"] is False)

        d = req("/api/contacts")
        check("联系人列表可达", d["ok"] is True and d["data"]["count"] >= 0)

        # ---------- 联系人：联系方式为可选 ----------
        # 部分微信好友没登记号码，留空也应当能新增（发送靠姓名定位）
        d = req("/api/contacts", "POST",
                {"name": "无号码测试", "contact": "", "datetime": "2026-09-13 08:30"})["data"]
        check("联系方式留空也能新增",
              d["name"] == "无号码测试" and d["contact"] == "" and d["contact_type"] == "未登记")
        d = req("/api/contacts")["data"]
        blank = next((c for c in d["contacts"] if c["name"] == "无号码测试"), None)
        check("留空记录列表可见且类型为未登记",
              blank is not None and blank["contact"] == "" and blank["contact_type"] == "未登记")
        if blank:
            d = req(f"/api/contacts/{blank['index']}", "DELETE")["data"]
            check("清理留空测试记录", d["name"] == "无号码测试")

        d = req("/api/contacts", "POST",
                {"name": "非法号码测试", "contact": "不是号码", "datetime": "2026-09-13 08:30"})
        check("非法联系方式仍被拒绝", d["ok"] is False)
        # 确认没有落库脏数据
        d = req("/api/contacts")["data"]
        check("非法记录未落库", all(c["name"] != "非法号码测试" for c in d["contacts"]))

        d = req("/api/logs?lines=200")
        check("日志接口可达", d["ok"] is True and isinstance(d["data"]["lines"], list))

        # ---------- 配置与发送目标 ----------
        d = req("/api/config")["data"]
        check("读取配置视图", d["ok"] if "ok" in d else "schedule" in d and "safety" in d)

        # 先加一个启用、跟随全局时间的目标（否则没有 enabled 目标时任务数恒为 0）
        d = req("/api/targets", "POST", {
            "name": "测试目标甲", "enabled": True, "times": [],
            "messages": ["你好{name}，{greeting}"]})["data"]
        check("新增发送目标", d["name"] == "测试目标甲" and d["approved"] is False)
        idx = d["index"]

        # 调度编辑：加一个时间点，任务应重建为 2 个
        d = req("/api/config/schedule", "PUT",
                {"times": ["08:30", "21:05"], "weekdays": [1, 2, 3, 4, 5], "jitter_minutes": 2})["data"]
        check("保存调度设置", d["schedule"]["times"] == ["08:30", "21:05"]
              and d["schedule"]["weekdays"] == [1, 2, 3, 4, 5])
        check("定时任务按新配置重建", len(scheduler.get_jobs()) == 2,
              f"期望 2 个任务，实际 {len(scheduler.get_jobs())}")
        d = req("/api/config/schedule", "PUT", {"times": ["25:00"]})
        check("非法时间点被拒绝", d["ok"] is False)

        # 目标更新与闸门
        d = req(f"/api/targets/{idx}", "PUT", {"messages": ["改过的消息"], "enabled": False})["data"]
        check("更新发送目标", d["messages"] == ["改过的消息"] and d["enabled"] is False)
        d = req(f"/api/targets/{idx}/gate", "PUT", {"approved": True, "confirm": "错误的词"})
        check("批准闸门错误确认词被拒绝", d["ok"] is False)
        d = req(f"/api/targets/{idx}/gate", "PUT", {"approved": True, "confirm": "我已核对参考图"})
        check("无参考图时批准被拒绝", d["ok"] is False and "参考图" in d["error"])
        d = req("/api/targets", "POST", {"name": "", "messages": ["x"]})
        check("空姓名被拒绝", d["ok"] is False)
        d = req(f"/api/targets/{idx}", "DELETE")["data"]
        check("删除发送目标", d["deleted"] == "测试目标甲")

        # dry_run 闸门
        d = req("/api/config/safety", "PUT", {"dry_run": False})
        check("解除 dry_run 缺确认词被拒绝", d["ok"] is False)
        d = req("/api/config/safety", "PUT", {"dry_run": False, "confirm": "正式发送"})["data"]
        check("带确认词解除 dry_run", d["safety"]["dry_run"] is False)
        d = req("/api/config/safety", "PUT", {"dry_run": True})["data"]
        check("切回演练模式", d["safety"]["dry_run"] is True)

        # 注释保留：改过这么多配置，关键注释必须还在
        after = open(cfg.path, "r", encoding="utf-8").read()
        check("编辑不丢注释（使用说明仍在）", "首次使用四步" in after and "实测要点" in after)
        check("编辑不丢注释（targets 模板注释仍在）", "微信里的备注名，必须完全一致" in after)

        # 校准状态接口（不真正触发校准，避免动微信窗口）
        d = req("/api/calibrate/status")["data"]
        check("校准状态接口", d["running"] is False)

        # ---------- 自动识别（contact_resolve） ----------
        # 不实际打开微信窗口；只验证参数校验、错误响应里 code/hint 的传递
        # （真实流程在 tools/test_resolve.py 单独验证）
        d = req("/api/contacts/resolve", "POST", {"name": "   "})
        check("空昵称被拒绝（带 code/hint）",
              d["ok"] is False and d.get("code") == "empty_query" and d.get("hint"))
        d = req("/api/contacts/resolve", "POST", {})
        check("缺 name 字段被拒绝", d["ok"] is False and d.get("code") == "empty_query")

        # 丢弃未确认参考图：不存在的名字应安全返回 removed=False
        d = req("/api/contacts/discard-ref", "POST", {"name": "__不存在的测试名字__"})
        check("丢弃不存在的参考图安全返回", d["ok"] is True and d["data"]["removed"] is False)
        d = req("/api/contacts/discard-ref", "POST", {"name": ""})
        check("丢弃参考图缺名字被拒绝", d["ok"] is False)
    finally:
        web.stop()
        scheduler.shutdown(wait=False)
        # 还原真实配置
        with open(cfg.path, "w", encoding="utf-8", newline="") as fh:
            fh.write(cfg_backup)
        print("（已还原 config.yaml）")
        # 还原联系人数据（测试里新增/删除过记录）
        if contacts_backup is not None:
            with open(contacts_path, "w", encoding="utf-8", newline="") as fh:
                fh.write(contacts_backup)
            print("（已还原 data/contacts.json）")

    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
