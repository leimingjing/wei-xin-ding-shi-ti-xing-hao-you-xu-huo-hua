# -*- coding: utf-8 -*-
"""自动识别联系人 · 真实环境自检。

直接调用生产代码路径（ContactResolver），在已登录的微信窗口里按昵称查找联系人。
不会发送任何消息，只做「搜索 → 点候选行 → 校验会话标题」，结束自动关掉搜索面板。

用法：
    python tools/test_resolve.py                 # 默认用「文件传输助手」跑正反面用例
    python tools/test_resolve.py 张三            # 用你自己的好友昵称测
    python tools/test_resolve.py 张三 --no-fake  # 跳过"查无此人"用例

判定：正例要求 matched_name 与输入一致；反例（乱码名字）要求给出 no_results。
"""
import argparse
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import ctypes  # noqa: E402

ctypes.windll.shcore.SetProcessDpiAwareness(2)

from wechat_auto.config_loader import Config  # noqa: E402
from wechat_auto.wechat.resolver import ContactResolver, ResolveError  # noqa: E402

PASS, FAIL = 0, 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [PASS] {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name}  {detail}")


class Log:
    def __init__(self, verbose):
        self.verbose = verbose

    def info(self, m):
        if self.verbose:
            print("    · " + str(m))

    def warning(self, m):
        print("    ! " + str(m))

    error = warning


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("name", nargs="?", default="文件传输助手", help="要查找的好友昵称/备注名")
    parser.add_argument("--no-fake", action="store_true", help="跳过「查无此人」反例")
    parser.add_argument("-v", "--verbose", action="store_true", help="打印每一步的细节")
    args = parser.parse_args()

    cfg = Config(ROOT)
    log = Log(args.verbose)
    print(f"自动识别自检 · 目标昵称「{args.name}」")
    print("（会短暂把微信窗口调到前台，不发送任何消息）\n")

    print("用例 1：正例 —— 微信里真实存在的会话")
    try:
        r = ContactResolver(cfg, log).resolve(args.name)
        check("识别成功", True)
        check("返回的名字与输入一致", r.matched_name == args.name, f"得到 {r.matched_name!r}")
        check("记录了检查过的候选行数", r.checked_rows >= 1, f"checked_rows={r.checked_rows}")
        if r.had_ref_before:
            check("复用了既有参考图并给出相似度",
                  isinstance(r.verify_score, float) and r.verify_score >= 0.9,
                  f"verify_score={r.verify_score}")
        else:
            check("首跑新建了参考图（需人工核对）", r.ref_saved is True)
    except ResolveError as exc:
        check("识别成功", False, f"{exc.code}: {exc.message}")
    time.sleep(1.5)

    if not args.no_fake:
        print("\n用例 2：反例 —— 微信里不存在的昵称，必须给出 no_results")
        fake = "zzz不存在的联系人zzz987"
        try:
            r = ContactResolver(cfg, log).resolve(fake)
            check("被正确拒绝", False,
                  f"竟然返回成功 matched_name={r.matched_name!r}（应判未找到）")
        except ResolveError as exc:
            check("给出未找到提示", exc.code == "no_results", f"code={exc.code}")
            check("提示文案可读", bool(exc.message and exc.hint))
        time.sleep(1.5)

    print("\n用例 3：入参校验 —— 空昵称必须在打开微信前就被拦掉")
    try:
        ContactResolver(cfg, log).resolve("   ")
        check("空昵称被拒绝", False)
    except ResolveError as exc:
        check("空昵称被拒绝", exc.code == "empty_query")

    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
