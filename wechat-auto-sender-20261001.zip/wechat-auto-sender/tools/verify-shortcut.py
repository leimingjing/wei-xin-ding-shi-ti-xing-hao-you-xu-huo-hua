# 验证 .lnk 的 IDList 能否被系统解析成正确路径（shell32.SHGetPathFromIDListW）
import ctypes
import ctypes.wintypes as wt
import os
import struct
import sys

sys.stdout.reconfigure(encoding="utf-8")

lnk = sys.argv[1] if len(sys.argv) > 1 else r"<桌面路径>\微信定时发送.lnk"
data = open(lnk, "rb").read()

flags = struct.unpack_from("<I", data, 20)[0]
print("flags: 0x%X  (HasIDList=%s HasLinkInfo=%s)" % (flags, bool(flags & 1), bool(flags & 2)))

if not (flags & 1):
    print("无 IDList，无法验证")
    sys.exit(1)

size = struct.unpack_from("<H", data, 76)[0]
pidl = data[78 : 78 + size]
print("IDList 长度:", size)

buf = ctypes.create_string_buffer(pidl, len(pidl))
shell32 = ctypes.windll.shell32
shell32.SHGetPathFromIDListW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
out = ctypes.create_unicode_buffer(520)
ok = shell32.SHGetPathFromIDListW(ctypes.cast(buf, ctypes.c_void_p), out)
print("SHGetPathFromIDListW 返回:", ok)
print("解析出的路径:", out.value)
print("路径是否存在:", os.path.exists(out.value) if out.value else False)
