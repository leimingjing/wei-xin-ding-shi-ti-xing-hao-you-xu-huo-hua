# -*- coding: utf-8 -*-
"""验证 Ctrl+F 能否唤起微信搜索框（只做像素差异比对，不输出任何聊天内容）。

用法：
    python tools/test_search.py
"""
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from wechat_auto.config_loader import Config  # noqa: E402
from wechat_auto.input import kbdmouse  # noqa: E402,F401  开启 DPI 感知
from wechat_auto.input.human import Human  # noqa: E402
from wechat_auto.vision import Vision  # noqa: E402
from wechat_auto.wechat.window import WeChatWindow  # noqa: E402


class Log:
    def info(self, m):
        print(m)

    warning = error = info


def main():
    cfg = Config(ROOT)
    logger = Log()
    window = WeChatWindow(cfg.wechat, logger)
    window.ensure_running()
    print("窗口类名:", window.control.ClassName, "| 登录窗口:", window.is_login_window())
    window.activate()
    time.sleep(1.0)

    r = window.control.BoundingRectangle
    rect = (int(r.left), int(r.top), int(r.width()), int(r.height()))
    region = (rect[0], rect[1], int(rect[2] * 0.35), int(rect[3] * 0.12))

    vision = Vision(ROOT, logger)
    human = Human(cfg.behavior)

    before = vision.grab(region)
    human.hotkey("ctrl", "f")
    time.sleep(1.5)
    after = vision.grab(region)
    ratio = Vision.diff_ratio(before, after)
    print(f"Ctrl+F 前后顶部区域差异: {ratio:.2%}")
    print("判定:", "搜索框已被唤起（区域发生变化）" if ratio >= 0.005 else "顶部区域几乎无变化，Ctrl+F 可能未生效")

    human.press("esc")
    time.sleep(0.4)
    human.press("esc")
    time.sleep(0.4)
    after2 = vision.grab(region)
    print(f"Esc 关闭后与初始状态差异: {Vision.diff_ratio(before, after2):.2%}")


if __name__ == "__main__":
    main()
