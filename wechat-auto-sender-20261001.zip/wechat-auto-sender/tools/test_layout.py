# -*- coding: utf-8 -*-
"""布局几何自检（纯计算，不需要微信、不需要截图）。

守的是这个坑：`title_band` 曾经写成 `y: {top: 62, bottom: 902}`——
"两端拉伸"的写法把窗口高度 1006 硬编码了进去。窗口一旦变矮（实测 988），
裁出来的标题条只剩 24px，比参考图(42px)还矮，`compare_ref` 会直接判 False，
表现为"会话标题与参考图不一致 / 找错人"，整个自动识别静默失效。

运行：python tools/test_layout.py
"""
import os
import sys

sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from wechat_auto.wechat.locator import WeChatLocator  # noqa: E402

PASS, FAIL = 0, 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [PASS] {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name}  {detail}")


class _Log:
    def info(self, m):
        pass

    warning = error = info


def main():
    logger = _Log()
    # 参考图实测尺寸（assets/refs/*.png 是按 1645x1006 窗口裁的）
    REF_H = 42

    heights = [900, 988, 1006, 1200, 1400]
    for h in heights:
        loc = WeChatLocator((409, 210, 1645, h), None, logger, vision=None, cfg={})

        _, _, bw, bh = loc.band("title_band")
        check(f"窗口高 {h}：标题条高度恒为 {REF_H}（不随窗口缩放）",
              bh == REF_H, f"实际 {bh}")
        check(f"窗口高 {h}：标题条宽度恒为 725",
              bw == 725, f"实际 {bw}")

        # 标题条贴在窗口顶部：y 起点固定 = top + 62
        _, by, _, _ = loc.band("title_band")
        check(f"窗口高 {h}：标题条顶边锚定 top+62",
              by == 210 + 62, f"实际 {by}")

    # 拉伸类元素应保持"随窗口变化"，别被误改成定高
    tall = WeChatLocator((409, 210, 1645, 1400), None, logger, vision=None, cfg={})
    short = WeChatLocator((409, 210, 1645, 900), None, logger, vision=None, cfg={})
    _, _, _, mh_tall = tall.band("message_area")
    _, _, _, mh_short = short.band("message_area")
    check("message_area 仍随窗口高度拉伸", mh_tall > mh_short, f"{mh_tall} vs {mh_short}")

    # 底锚定元素：输入框中心距底边固定
    p1 = short.point("input_box")
    p2 = tall.point("input_box")
    check("input_box 锚定底边：窗口变高时中心随之下移",
          p2[1] - p1[1] == 1400 - 900, f"Δ={p2[1] - p1[1]}")

    # 显式 width/height 与 left/top 组合
    loc = WeChatLocator((0, 0, 1000, 800), None, logger, vision=None,
                        cfg={"layout": {"probe": {"x": {"left": 10, "width": 200},
                                                  "y": {"top": 20, "height": 30}}}})
    bx, by, bw, bh = loc.band("probe")
    check("自定义 left+width / top+height 生效",
          (bx, by, bw, bh) == (10, 20, 200, 30), f"实际 {(bx, by, bw, bh)}")

    print(f"\n结果：{PASS} 通过 / {FAIL} 失败")
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
