// 生成 Windows 原生 .lnk 快捷方式（不依赖 COM / WScript.Shell）
//
// 用法：
//   node tools/make-shortcut.js [--target <文件>] [--name <名称>] [--out <目录>] [--icon <ico/exe>]
//
// 背景：沙箱禁止 New-Object -ComObject 与 cscript/wscript，因此按 MS-SHLLINK
// 规范手工构造二进制。两个关键约束：
//   1) IDList 不能省 —— Explorer 主要靠它定位目标，缺了会双击无反应。
//   2) IDList / LinkInfo 里的路径是 **ANSI(cp936)** 编码，中文目录名必须转成
//      GBK 字节；直接按 UTF-8/latin1 写会变成乱码，Explorer 找不到目标。
//      本脚本通过 `cmd /c dir /b <父目录>` 取回系统真实的文件名字节。
// 大小/时间戳只是创建期快照，过期不影响解析（Windows 按名称解析）。

const fs = require('node:fs');
const path = require('node:path');
const { execSync } = require('node:child_process');
const os = require('node:os');

function readOpts(argv) {
  const opts = {};
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i].startsWith('--')) opts[argv[i].slice(2)] = argv[i + 1];
  }
  return opts;
}

const opts = readOpts(process.argv.slice(2));
const PROJECT_DIR = path.resolve(__dirname, '..');
const TARGET_PATH = path.resolve(opts.target || path.join(PROJECT_DIR, 'start.bat'));
const DESKTOP = opts.out || path.join(process.env.USERPROFILE || os.homedir(), 'Desktop');
const LNK_PATH = path.join(DESKTOP, `${opts.name || '微信定时发送'}.lnk`);

const GBK = new TextDecoder('gbk');
const ASCII_RE = /^[\x20-\x7e]+$/;

// 取路径某级的 cp936 字节：纯 ASCII 直接编码；否则列父目录找系统真实字节
const nameBytesCache = new Map();
function nameBytes(fullPath) {
  const name = path.basename(fullPath);
  if (nameBytesCache.has(fullPath)) return nameBytesCache.get(fullPath);
  let bytes;
  if (ASCII_RE.test(name)) {
    bytes = Buffer.from(name, 'latin1');
  } else {
    const parent = path.dirname(fullPath);
    const out = execSync(`cmd /c dir /b "${parent}"`, { encoding: 'latin1' });
    const hit = out
      .split(/\r?\n/)
      .map((l) => Buffer.from(l, 'latin1'))
      .find((b) => GBK.decode(b) === name);
    if (!hit) throw new Error(`无法取得 "${name}" 的 ANSI 文件名（父目录：${parent}）`);
    bytes = hit;
  }
  nameBytesCache.set(fullPath, bytes);
  return bytes;
}

// 盘符卷序列号（LinkInfo 的 VolumeID 不匹配的会被判定失效）
function volumeOf(driveLetter) {
  let serial = 0x8af0caa6;
  let label = 'Windows-SSD';
  try {
    const out = execSync(`cmd /c vol ${driveLetter}:`, { encoding: 'latin1' });
    const m = out.match(/([0-9A-Fa-f]{4})-([0-9A-Fa-f]{4})/);
    if (m) serial = parseInt(m[1] + m[2], 16);
    const lm = out.match(/in drive [A-Za-z]:\s*(?:is\s+)?(.+?)\r?\n/);
    if (lm) label = lm[1].trim().slice(0, 32);
  } catch (_) {
    /* 取不到就用默认值 */
  }
  return { serial, label };
}

const HAS_TARGET_IDLIST = 0x00000001;
const HAS_LINK_INFO = 0x00000002;
const HAS_WORKING_DIR = 0x00000010;
const HAS_ICON_LOCATION = 0x00000040;
const IS_UNICODE = 0x00000080;
const LINK_FLAGS =
  HAS_TARGET_IDLIST | HAS_LINK_INFO | HAS_WORKING_DIR | HAS_ICON_LOCATION | IS_UNICODE;

const MY_COMPUTER_GUID = Buffer.from('1f50e04fd020ea3a6910a2d808002b30309d', 'hex');
const EPOCH_DIFF_MS = 11644473600000;
const toFileTime = (ms) => BigInt(Math.floor(ms) + EPOCH_DIFF_MS) * 10000n;

const cstr = (buf) => Buffer.concat([buf, Buffer.from([0x00])]);
function unicodeString(s) {
  const body = Buffer.from(s + '\0', 'utf16le');
  const count = Buffer.alloc(2);
  count.writeUInt16LE(body.length / 2, 0);
  return Buffer.concat([count, body]);
}
const sizeField = (len) => {
  const b = Buffer.alloc(2);
  b.writeUInt16LE(len + 2, 0);
  return b;
};

// 文件系统条目：0x31 目录 / 0x32 文件
function fileEntryItem(type, fullPath) {
  const name = path.basename(fullPath);
  const stat = fs.statSync(fullPath);
  const ft = toFileTime(stat.mtimeMs);

  const prefix = Buffer.alloc(12);
  prefix[0] = type;
  prefix[1] = 0x00;
  prefix.writeUInt32LE(type === 0x32 ? stat.size : 0, 2);
  prefix.writeUInt32LE(Number(ft & 0xffffffffn) >>> 0, 6);
  prefix.writeUInt16LE(type === 0x32 ? 0x20 : 0x10, 10);

  const uniName = Buffer.from(name, 'utf16le');
  const blockSize = 50 + uniName.length;
  const block = Buffer.alloc(blockSize);
  block.writeUInt16LE(blockSize, 0);
  block.writeUInt16LE(9, 2);
  block.writeUInt32LE(0xbeef0004, 4);
  const ftBuf = Buffer.alloc(8);
  ftBuf.writeBigUInt64LE(ft);
  ftBuf.copy(block, 8);
  block.writeUInt32LE(0x2e, 16);
  block.writeUInt32LE(1, 20);
  block.writeUInt32LE(0, 24);
  uniName.copy(block, 28 + 18);
  block.writeUInt16LE(0x0000, 28 + 18 + uniName.length);
  block.writeUInt16LE(name.length + 16, 28 + 18 + uniName.length + 2);

  const data = Buffer.concat([prefix, cstr(nameBytes(fullPath)), block]);
  return Buffer.concat([sizeField(data.length), data]);
}

function buildIdList(targetPath) {
  const drive = targetPath.slice(0, 3).toUpperCase();
  const parts = targetPath.slice(3).split('\\').filter(Boolean);
  const items = [
    Buffer.concat([sizeField(MY_COMPUTER_GUID.length), MY_COMPUTER_GUID]),
    Buffer.concat([
      sizeField(23),
      Buffer.from([0x2f]),
      Buffer.from(drive, 'latin1'),
      Buffer.from([0x00]),
      Buffer.alloc(18),
    ]),
  ];
  parts.forEach((_, idx) => {
    const full = path.join(drive, ...parts.slice(0, idx + 1));
    items.push(fileEntryItem(idx === parts.length - 1 ? 0x32 : 0x31, full));
  });
  const body = Buffer.concat(items);
  const size = Buffer.alloc(2);
  size.writeUInt16LE(body.length + 2, 0);
  return Buffer.concat([size, body, Buffer.from([0x00, 0x00])]);
}

function buildLinkInfo(basePath, volume) {
  const volumeLabel = cstr(Buffer.from(volume.label, 'latin1'));
  const volumeIdSize = 16 + volumeLabel.length;
  const volumeId = Buffer.alloc(volumeIdSize);
  volumeId.writeUInt32LE(volumeIdSize, 0);
  volumeId.writeUInt32LE(3, 4); // DRIVE_FIXED
  volumeId.writeUInt32LE(volume.serial >>> 0, 8);
  volumeId.writeUInt32LE(0x10, 12);
  volumeLabel.copy(volumeId, 16);

  // BasePath 同样是 ANSI：逐级拼出 cp936 字节
  const drive = basePath.slice(0, 3);
  const parts = basePath.slice(3).split('\\').filter(Boolean);
  const chunk = [Buffer.from(drive, 'latin1')];
  let acc = drive.replace(/\\$/, '');
  for (const p of parts) {
    acc = path.join(acc, p);
    chunk.push(nameBytes(acc));
    if (acc !== basePath) chunk.push(Buffer.from('\\', 'latin1'));
  }
  const basePathAnsi = cstr(Buffer.concat(chunk));

  const headerSize = 0x1c;
  const volumeIdOffset = headerSize;
  const basePathOffset = volumeIdOffset + volumeIdSize;
  const suffixOffset = basePathOffset + basePathAnsi.length;
  const info = Buffer.alloc(headerSize + volumeIdSize + basePathAnsi.length + 1);
  info.writeUInt32LE(info.length, 0);
  info.writeUInt32LE(headerSize, 4);
  info.writeUInt32LE(0x00000001, 8);
  info.writeUInt32LE(volumeIdOffset, 12);
  info.writeUInt32LE(basePathOffset, 16);
  info.writeUInt32LE(0, 20);
  info.writeUInt32LE(suffixOffset, 24);
  volumeId.copy(info, volumeIdOffset);
  basePathAnsi.copy(info, basePathOffset);
  info.writeUInt8(0, suffixOffset);
  return info;
}

function buildHeader() {
  const h = Buffer.alloc(76);
  h.writeUInt32LE(0x0000004c, 0);
  Buffer.from('0114020000000000c000000000000046', 'hex').copy(h, 4);
  h.writeUInt32LE(LINK_FLAGS, 20);
  h.writeUInt32LE(0x00000020, 24); // FILE_ATTRIBUTE_ARCHIVE
  h.writeUInt32LE(0, 52);
  h.writeUInt32LE(0, 56); // IconIndex
  h.writeUInt32LE(1, 60); // SW_SHOWNORMAL
  return h;
}

if (!fs.existsSync(TARGET_PATH)) {
  console.error('目标不存在:', TARGET_PATH);
  process.exit(1);
}

let icon = opts.icon;
if (!icon) {
  const wechat = 'D:\\Weixin\\Weixin.exe';
  icon = fs.existsSync(wechat) ? wechat : 'C:\\Windows\\System32\\imageres.dll';
}

const volume = volumeOf(TARGET_PATH[0]);
const parts = [buildHeader(), buildIdList(TARGET_PATH), buildLinkInfo(TARGET_PATH, volume)];
parts.push(unicodeString(path.dirname(TARGET_PATH))); // WORKING_DIR (Unicode)
parts.push(unicodeString(icon)); // ICON_LOCATION (Unicode)
parts.push(Buffer.from([0x00, 0x00, 0x00, 0x00])); // TerminalBlock

const lnk = Buffer.concat(parts);
fs.writeFileSync(LNK_PATH, lnk);
console.log('已创建 :', LNK_PATH);
console.log('目标   :', TARGET_PATH);
console.log('工作目录:', path.dirname(TARGET_PATH));
console.log('图标   :', icon);
console.log('卷序列号: 0x' + (volume.serial >>> 0).toString(16).toUpperCase(), '卷标:', volume.label);
console.log('大小   :', lnk.length, 'bytes');
