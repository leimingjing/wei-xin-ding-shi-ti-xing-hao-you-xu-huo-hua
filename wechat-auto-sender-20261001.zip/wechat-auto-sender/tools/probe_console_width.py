# -*- coding: utf-8 -*-
"""标尺探测：在真实控制台里核对"报告列数"与"实际可视列数"是否一致。

重点回答三个问题：
  1. os.get_terminal_size 报的列数，是缓冲区宽度还是可视窗口宽度？
  2. 最后一列（第 N 列）是否真的在可视区域内？
  3. 中文/全角混排时列宽是否为 2。
"""
import ctypes
import os
import sys
import time
from ctypes import wintypes

sys.stdout.reconfigure(encoding="utf-8")

COLS = 100  # 只画到 100 列，避免缓冲区比窗口宽时误判


def console_metrics():
    """直接问控制台：缓冲区尺寸 / 可视窗口矩形 / 光标位置。"""
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    class COORD(ctypes.Structure):
        _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]

    class SMALL_RECT(ctypes.Structure):
        _fields_ = [("Left", ctypes.c_short), ("Top", ctypes.c_short),
                    ("Right", ctypes.c_short), ("Bottom", ctypes.c_short)]

    class CONSOLE_SCREEN_BUFFER_INFO(ctypes.Structure):
        _fields_ = [("dwSize", COORD), ("dwCursorPosition", COORD),
                    ("wAttributes", wintypes.WORD), ("srWindow", SMALL_RECT),
                    ("dwMaximumWindowSize", COORD)]

    h = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
    info = CONSOLE_SCREEN_BUFFER_INFO()
    ok = kernel32.GetConsoleScreenBufferInfo(h, ctypes.byref(info))
    if not ok:
        return None
    sr = info.srWindow
    return {
        "buffer": (info.dwSize.X, info.dwSize.Y),
        "viewport": (sr.Right - sr.Left + 1, sr.Bottom - sr.Top + 1),
    }


def get_terminal_size_os():
    try:
        s = os.get_terminal_size(sys.stdout.fileno())
        return (s.columns, s.lines)
    except Exception as exc:  # pragma: no cover
        return f"失败({exc})"


def main():
    # 1) ASCII 标尺：每 10 列一个刻度，末尾收口
    ruler = "".join(str((i // 10) % 10) if i % 10 == 0 else "-" for i in range(COLS))
    ruler = ruler[:-1] + "|"
    # 2) 全角标尺：COLS/2 个全角块，若全角=2 列则应正好覆盖上一行
    wide = "田" * (COLS // 2 - 1) + "界"
    # 3) 定位标记：在第 100 列打 X，用来判断右边界是否被切
    marks = [" "] * COLS
    for col in (59, 79, 89, 99):
        marks[col] = "X"

    print("== 缓冲区 vs 可视窗口 ==")
    m = console_metrics()
    print("  控制台 API:", m)
    print("  os.get_terminal_size:", get_terminal_size_os())
    print("== 标尺（0..99 列，末列是 |）==")
    print(ruler)
    print("== 定位标记（第 60/80/90/100 列）==")
    print("".join(marks))
    print("== 全角标尺（50 个全角 = 100 列）==")
    print(wide)
    print("== 中文混排 ==")
    print("  │ " + "编号" + "  " + "姓名" + "      " + "联系方式" + "  " + "指定时间")
    print("== 结束 ==")
    time.sleep(600)


if __name__ == "__main__":
    main()
