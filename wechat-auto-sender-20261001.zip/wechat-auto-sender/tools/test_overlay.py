# -*- coding: utf-8 -*-
"""悬浮窗自检：建窗 → 校验置顶与位置 → 倒计时刷新 → 复用 → 手动关闭 → 归零自关。

用法：
    python tools/test_overlay.py            # 跑全套自检（约 12 秒）
    python tools/test_overlay.py 20         # 顺带看 20 秒倒计时（手动观察窗口）
"""
import ctypes
import ctypes.wintypes as wt
import os
import threading
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

_u = ctypes.windll.user32
WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
_u.EnumWindows.argtypes = [WNDENUMPROC, wt.LPARAM]
_u.EnumChildWindows.argtypes = [wt.HWND, WNDENUMPROC, wt.LPARAM]
_u.GetClassNameW.argtypes = [wt.HWND, wt.LPCWSTR, ctypes.c_int]
_u.GetWindowTextW.argtypes = [wt.HWND, wt.LPCWSTR, ctypes.c_int]
_u.GetWindowLongW.argtypes = [wt.HWND, ctypes.c_int]
_u.GetWindowLongW.restype = ctypes.c_long
_u.GetWindowRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]

WS_EX_TOPMOST = 0x00000008
GWL_EXSTYLE = -20
CLASS_NAME = "WeChatAutoTaskOverlay"

FAILS = []


def check(cond, label, extra=""):
    tag = "PASS" if cond else "FAIL"
    if not cond:
        FAILS.append(label)
    print(f"  [{tag}] {label}" + (f"  {extra}" if extra else ""))


def _text(hwnd):
    n = _u.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    _u.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def find_windows():
    found = []

    @WNDENUMPROC
    def cb(hwnd, _):
        buf = ctypes.create_unicode_buffer(256)
        _u.GetClassNameW(hwnd, buf, 256)
        if buf.value == CLASS_NAME:
            found.append(hwnd)
        return True

    _u.EnumWindows(cb, 0)
    return found


def child_texts(hwnd):
    texts = []

    @WNDENUMPROC
    def cb(h, _):
        texts.append(_text(h))
        return True

    _u.EnumChildWindows(hwnd, cb, 0)
    return texts


def main():
    from wechat_auto import overlay

    print("== 1. 时间格式 ==")
    check(overlay._fmt(59) == "00:59", f"59s → {overlay._fmt(59)}")
    check(overlay._fmt(3725) == "01:02:05", f"3725s → {overlay._fmt(3725)}（超 1 小时用 hh:mm:ss）")
    check(overlay._fmt(-1) == "00:00", "负数兜底 00:00")

    print("== 2. 建窗 ==")
    t0 = time.time()
    created = overlay.show(8, detail="自检：8 秒倒计时")
    check(created is True, "show() 返回 True（新建窗口）")
    check(overlay.is_active(), "窗口已激活")
    wins = find_windows()
    check(len(wins) == 1, f"屏幕上悬浮窗数量 = {len(wins)}", "（需求 5：同一时间只允许一个）")
    if not wins:
        print("窗口未创建，后续检查中止")
        return 1
    hwnd = wins[0]
    ex = _u.GetWindowLongW(hwnd, GWL_EXSTYLE)
    check(bool(ex & WS_EX_TOPMOST), f"WS_EX_TOPMOST 已置位（exStyle=0x{ex & 0xFFFFFFFF:08X}）", "（需求 2）")
    r = wt.RECT()
    _u.GetWindowRect(hwnd, ctypes.byref(r))
    print(f"       位置/尺寸：({r.left},{r.top}) {r.right - r.left}x{r.bottom - r.top}")
    check(r.right - r.left <= 400 and r.bottom - r.top <= 160, "尺寸紧凑（≤400x160）")
    print(f"       子控件文本：{child_texts(hwnd)}")

    print("== 3. 倒计时每秒刷新 ==")
    first = child_texts(hwnd)
    time.sleep(2.2)
    second = child_texts(hwnd)
    print(f"       2.2 秒后：{second}")
    check(any(t != first[i] for i, t in enumerate(second)), "倒计时文本已变化", "（需求 3）")

    print("== 4. 更新副标题 ==")
    overlay.set_detail("正在处理 示例联系人A（1/2）")
    time.sleep(0.3)
    check("正在处理 示例联系人A（1/2）" in child_texts(hwnd), "副标题已刷新")

    print("== 5. 复用（不新建第二个窗口） ==")
    reused = overlay.show(30, detail="复用：30 秒")
    time.sleep(0.3)
    check(reused is False, "show() 返回 False（复用已有窗口）")
    check(len(find_windows()) == 1, "窗口数仍为 1", "（需求 5）")
    check("复用：30 秒" in child_texts(hwnd), "复用后副标题已刷新")
    left = overlay._deadline - time.monotonic()
    check(25 < left <= 30, f"倒计时已重置为 {left:.1f}s", "（需求 5：刷新倒计时）")

    print("== 6. 手动关闭 ==")
    overlay.stop()
    time.sleep(0.5)
    check(not overlay.is_active(), "窗口已销毁")
    check(len(find_windows()) == 0, "屏幕上无残留窗口", "（需求 6）")

    print("== 7. 倒计时归零自动关闭 ==")
    overlay.show(3, detail="自检：归零自动关闭")
    check(overlay.is_active(), "窗口已显示")
    time.sleep(4.2)
    check(not overlay.is_active(), "归零后窗口自动关闭", "（需求 4）")
    check(len(find_windows()) == 0, "无残留窗口 / 计时器线程已退出")

    print("== 7.5 主流程接线（假 Sender，完全不碰微信） ==")
    try:
        import app as appmod
        from wechat_auto.config_loader import Config
        from wechat_auto import logger as logutil

        class FakeSender:
            def __init__(self, cfg, logger):
                pass

            def run_once(self, target, dry_run=None):
                time.sleep(1.0)
                return {"status": "dry_run", "detail": "自检假发送", "snapshots": []}

        appmod.Sender = FakeSender
        cfg = Config(ROOT)
        logger = logutil.setup(ROOT, 7)
        check(appmod.overlay_enabled(cfg), "配置 ui.task_overlay 已生效")
        th = threading.Thread(target=lambda: appmod.run_now(cfg, logger, real=False), daemon=True)
        th.start()
        time.sleep(1.3)
        check(overlay.is_active(), "run_now 执行期间悬浮窗已显示")
        wins_now = find_windows()
        texts_now = child_texts(wins_now[0]) if wins_now else []
        print(f"       窗口内容：{texts_now}")
        check(any("示例联系人A" in t for t in texts_now), "副标题显示当前联系人进度")
        th.join(timeout=30)
        time.sleep(0.6)
        check(not overlay.is_active(), "任务结束后悬浮窗自动关闭", "（需求 6）")

        def boom(self, target, dry_run=None):
            raise RuntimeError("自检触发的异常")

        FakeSender.run_once = boom
        appmod.web_run(cfg, logger, real=False)  # 网页入口：异常被内部捕获
        time.sleep(0.6)
        check(not overlay.is_active(), "执行报错后悬浮窗也已关闭，无残留", "（需求 6）")
    except Exception as exc:  # 接线自检失败要显式暴露
        import traceback
        traceback.print_exc()
        check(False, f"主流程接线自检异常：{exc}")

    print("== 8. 耗时 ==")
    print(f"       全流程 {time.time() - t0:.1f}s（show() 不阻塞主线程）")

    if len(sys.argv) > 1:
        sec = int(sys.argv[1])
        print(f"== 9. 观察窗口 {sec} 秒（可看右上角） ==")
        overlay.show(sec, detail=f"观察模式 {sec}s")
        time.sleep(sec + 1)
        overlay.stop()

    print()
    if FAILS:
        print(f"❌ 失败 {len(FAILS)} 项：{FAILS}")
        return 1
    print("✅ 全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
