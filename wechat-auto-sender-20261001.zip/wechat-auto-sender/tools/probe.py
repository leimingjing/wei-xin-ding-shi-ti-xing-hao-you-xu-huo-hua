# -*- coding: utf-8 -*-
"""P0 只读探测：确认微信窗口能被识别（微信 4.x 不暴露控件树，这里只探窗口）。

用法：
    python tools/probe.py              # 只探测已运行的微信
    python tools/probe.py --launch     # 没运行就自动启动
输出写入 logs/probe_report.txt
"""
import argparse
import io
import os
import sys
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import win32gui  # noqa: E402

from wechat_auto.config_loader import Config  # noqa: E402
from wechat_auto.wechat.window import WeChatWindow  # noqa: E402


class Log:
    def __init__(self):
        self.lines = []

    def info(self, m):
        self.lines.append(str(m))

    warning = error = info


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--launch", action="store_true", help="微信未运行时自动启动")
    args = parser.parse_args()

    log = Log()
    cfg = Config(ROOT)
    window = WeChatWindow(cfg.wechat, log)

    t0 = time.time()
    control = window.find(timeout=3)
    if not control and args.launch:
        control = window.ensure_running()
    lines = log.lines
    lines.append(f"窗口定位耗时: {time.time() - t0:.2f}s")

    if not control:
        lines.append("未发现微信窗口。加 --launch 参数可自动启动，或手动打开微信后重试。")
    else:
        rect = control.BoundingRectangle
        lines.append(f"窗口类名: {control.ClassName}")
        lines.append(f"窗口标题: {win32gui.GetWindowText(control.NativeWindowHandle)}")
        lines.append(f"窗口位置: left={rect.left} top={rect.top} {rect.width()}x{rect.height()}")
        lines.append(f"是否登录窗口: {window.is_login_window()}")
        lines.append(f"UI 自动化子节点数: {len(control.GetChildren())}（微信 4.x 通常为 0~1，属正常）")
        lines.append("")
        lines.append("结论：窗口可定位即可用；控件级信息依赖图像匹配，请运行 tools/calibrate.py 校准。")

    text = "\n".join(lines)
    print(text)
    out = os.path.join(ROOT, "logs", "probe_report.txt")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(text)
    print(f"\n报告已写入: {out}")


if __name__ == "__main__":
    main()
