"""验证合并后只有一个实例：第二次启动应提示已有实例并退出。"""
import os
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = sys.executable
ENV = dict(os.environ, CONTACT_MGR_NO_PAUSE="1")

first = subprocess.Popen(
    [PY, "app.py"], cwd=ROOT, stdin=subprocess.PIPE,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    encoding="utf-8", env=ENV,
)
time.sleep(8)

second = subprocess.run(
    [PY, "app.py"], cwd=ROOT, input="", capture_output=True,
    text=True, encoding="utf-8", timeout=40, env=ENV,
)
print("第二次启动输出:")
print((second.stdout or "").strip()[:400])
ok = "已有实例在运行" in (second.stdout or "")
print(f"\n[{'OK' if ok else 'FAIL'}] 第二次启动被单实例锁挡住")

first.terminate()
try:
    first.wait(timeout=15)
except subprocess.TimeoutExpired:
    first.kill()
print("第一次实例已结束")
sys.exit(0 if ok else 1)
