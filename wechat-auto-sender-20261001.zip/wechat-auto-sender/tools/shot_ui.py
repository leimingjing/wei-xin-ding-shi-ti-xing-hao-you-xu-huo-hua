# -*- coding: utf-8 -*-
"""把真实界面渲染到当前物理控制台，供截图核对（只读，不写业务数据）。"""
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "workbench"))
sys.path.insert(0, os.path.join(ROOT, "tools"))

import preview_ui as P  # noqa: E402
import theme as th  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
th.init(mode=os.environ.get("SHOT_MODE", "auto"),
        color=os.environ.get("SHOT_COLOR", "auto"), tui=False)
t = th.get()
print(f"### 终端 {t.width} 列 | 色深 {t.color_depth} | unicode={t.unicode} ###")


def page(title, action):
    wb = P.make_workbench("", notices=[
        ("WARNING", "当前没有任何定时任务：targets 里没有 enabled: true 的联系人。"),
        ("INFO", "已注册定时任务：每天 08:30 → ['张三']"),
    ])
    # 预览数据落在临时目录，但页脚显示的应是真实数据文件位置
    wb.store.path = os.path.join(ROOT, "data", "contacts.json")
    wb.read = lambda prompt="": "0"
    wb.pause = lambda msg="": None
    print()
    print(f"### {title} ###")
    action(wb)


WHICH = os.environ.get("SHOT_PAGE", "menu")
if WHICH == "menu":
    page("主菜单", lambda wb: wb.flush(wb.home_lines()))
elif WHICH == "list":
    page("联系人列表", lambda wb: wb.action_list())
elif WHICH == "task":
    page("任务状态", lambda wb: wb.action_task_status())
elif WHICH == "edit":
    page("编辑子菜单", lambda wb: wb.action_edit())
elif WHICH == "both":
    page("主菜单", lambda wb: wb.flush(wb.home_lines()))
    page("联系人列表", lambda wb: wb.action_list())

time.sleep(600)
