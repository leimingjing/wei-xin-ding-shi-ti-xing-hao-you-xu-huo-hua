# -*- coding: utf-8 -*-
"""研究：搜索面板里如何选中「联系人」那一行（而不是第一行的“搜索网络结果”）。

只截图、只按方向键，**不按回车、不发送**。每按一次 ↓ 存一张面板截图，
用来观察高亮条落在哪一行。

用法：
    python tools/probe_select.py
    python tools/probe_select.py --query 文件传输助手 --downs 4
"""
import argparse
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from PIL import Image  # noqa: E402

from wechat_auto.config_loader import Config  # noqa: E402
from wechat_auto.input import kbdmouse as km  # noqa: E402,F401
from wechat_auto.input.human import Human  # noqa: E402
from wechat_auto.vision import Vision  # noqa: E402
from wechat_auto.wechat.locator import WeChatLocator, rect_tuple  # noqa: E402
from wechat_auto.wechat.window import WeChatWindow  # noqa: E402

LOGS = None


class Log:
    def info(self, m):
        pass

    warning = error = info


def main():
    global LOGS
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", default="文件传输助手")
    parser.add_argument("--downs", type=int, default=4, help="最多按几次方向键")
    args = parser.parse_args()

    cfg = Config(ROOT)
    logger = Log()
    LOGS = os.path.join(ROOT, "logs")

    window = WeChatWindow(cfg.wechat, logger)
    window.ensure_running()
    window.activate()
    time.sleep(1.0)

    rect = rect_tuple(window.control)
    human = Human(cfg.behavior)
    vision = Vision(ROOT, logger)
    locator = WeChatLocator(rect, human, logger, vision, cfg.wechat)

    # 面板区域：搜索框下方整块候选列表
    left, top, width, height = rect
    panel = (left + 90, top + 85, 580, 880)

    def snap(tag):
        path = os.path.join(LOGS, f"probe_select_{tag}.png")
        Image.fromarray(vision.grab(panel)[:, :, ::-1]).save(path)
        return path, vision.grab(panel)

    locator.open_search()
    locator.type_query(args.query)
    locator.wait_results()

    path0, prev = snap("0_panel")
    print(f"已粘贴「{args.query}」，面板截图：{path0}")

    for i in range(1, args.downs + 1):
        human.press("down")
        time.sleep(0.5)
        path, cur = snap(f"{i}_down{i}")
        print(f"按 ↓ ×{i} 后：面板差异 {Vision.diff_ratio(prev, cur):.2%} → {path}")
        prev = cur

    human.press("esc")
    time.sleep(0.6)
    snap("9_closed")
    print("\n已按 Esc 收尾。请对比 0_panel 与各 down 截图，看高亮条移动到哪一行：")
    print("  若 ↓ 能走到「联系人」行，则发送流程可改为「搜索 → ↓×N → 回车」")
    print("  若 ↓ 无效，则改为「点击联系人行」的方案（需实测该行坐标）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
