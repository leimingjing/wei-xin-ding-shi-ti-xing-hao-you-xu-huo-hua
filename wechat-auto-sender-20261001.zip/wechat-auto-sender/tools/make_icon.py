# -*- coding: utf-8 -*-
"""生成应用图标 assets/app.ico（多尺寸）+ 托盘用的 PNG。

设计：微信绿圆底 + 白色对勾（简洁，16px 下仍可辨认）。
可反复运行：图标是纯几何绘制，不依赖外部素材。
"""
import os

from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_ICO = os.path.join(ROOT, "assets", "app.ico")
OUT_PNG = os.path.join(ROOT, "assets", "app.png")

GREEN = (7, 193, 96, 255)      # 微信绿 #07C160
WHITE = (255, 255, 255, 255)
SIZES = [16, 24, 32, 48, 64, 128, 256]


def draw_icon(size: int) -> Image.Image:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # 圆底（留 1px 边距，小尺寸不贴边）
    d.ellipse((1, 1, size - 2, size - 2), fill=GREEN)
    # 白色对勾：粗细随尺寸缩放
    s = size
    lw = max(2, round(s / 7.5))          # 线宽
    # 三个锚点：左中、下中、右上（比例固定）
    p1 = (round(s * 0.26), round(s * 0.52))
    p2 = (round(s * 0.44), round(s * 0.70))
    p3 = (round(s * 0.76), round(s * 0.34))
    d.line([p1, p2, p3], fill=WHITE, width=lw, joint="curve")
    # 端点补圆头
    r = lw / 2 - 0.5
    for p in (p1, p2, p3):
        d.ellipse((p[0] - r, p[1] - r, p[0] + r, p[1] + r), fill=WHITE)
    return img


def main():
    os.makedirs(os.path.dirname(OUT_ICO), exist_ok=True)
    frames = [draw_icon(s) for s in SIZES]
    frames[-1].save(OUT_ICO, format="ICO",
                    sizes=[(s, s) for s in SIZES], append_images=frames[:-1])
    draw_icon(256).save(OUT_PNG)
    print(f"OK ico={OUT_ICO} ({os.path.getsize(OUT_ICO)} bytes)")
    print(f"OK png={OUT_PNG} ({os.path.getsize(OUT_PNG)} bytes)")


if __name__ == "__main__":
    main()
