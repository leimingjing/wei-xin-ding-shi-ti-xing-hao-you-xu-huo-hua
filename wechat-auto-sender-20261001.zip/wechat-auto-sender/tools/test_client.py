# -*- coding: utf-8 -*-
"""桌面客户端自检：设置持久化 / 开机自启注册表 / API / 关闭决策 / 冒烟生命周期。

  1. 关闭窗口决策纯函数 decide_close（收进托盘 vs 退出）
  2. Settings 默认值 / 持久化 / 非法值回退 / 窗口尺寸下限 / 损坏文件容错
  3. 开机自启注册表（独立键名 WeChatAutoSenderSelfTest，不动真实自启项）
  4. /api/settings：GET / PUT 联动（settings.json + 注册表）/ 浏览器模式拒绝修改
  5. 冒烟：client.py --smoke 完整启动（窗口+托盘+内嵌后端）3 秒后自动退出，退出码 0
  6. 打包产物冒烟：dist 里的 exe --smoke（存在时才跑）

用法：
    python tools/test_client.py             # 全部
    python tools/test_client.py --no-smoke  # 跳过真实窗口冒烟
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "workbench"))

FAILS = []


def check(cond, label, extra=""):
    tag = "PASS" if cond else "FAIL"
    if not cond:
        FAILS.append(label)
    print(f"  [{tag}] {label}" + (f"  | {extra}" if extra else ""))


def expect_error(fn, key, label):
    try:
        fn()
        check(False, label, "（没有抛出预期异常）")
    except Exception as exc:
        check(key in str(exc), label, f"异常信息：{exc}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-smoke", action="store_true", help="跳过真实窗口冒烟")
    args = parser.parse_args()

    tmp = tempfile.mkdtemp(prefix="wxclient_")
    for d in ("config", "data", "logs", "web"):
        os.makedirs(os.path.join(tmp, d), exist_ok=True)

    from wechat_auto import settings as settings_mod
    from wechat_auto.settings import Settings

    # ===== 1. 关闭决策纯函数 =====
    print("== 1. 关闭窗口决策 decide_close ==")
    from client import decide_close
    check(decide_close("minimize", False) is False, "minimize + 非托盘退出 → 收进托盘")
    check(decide_close("exit", False) is True, "exit → 放行关闭（退出）")
    check(decide_close("minimize", True) is True, "托盘退出 → 一律放行")
    check(decide_close(None, False) is False, "行为值缺失 → 按默认收进托盘")

    # ===== 2. Settings 持久化 =====
    print("== 2. Settings 持久化与容错 ==")
    spath = os.path.join(tmp, "data", "settings.json")
    st = Settings(spath, startup_command='"C:\\fake\\app.exe" --startup')
    check(st.data["close_behavior"] == "minimize" and st.data["auto_start"] is False,
          "首次加载 = 默认值（minimize / 不自启）")
    check(st.data["start_minimized"] is False, "start_minimized 默认 False")
    st.update({"close_behavior": "exit", "start_minimized": True})
    on_disk = json.load(open(spath, encoding="utf-8"))
    check(on_disk["close_behavior"] == "exit" and on_disk["start_minimized"] is True,
          "update 后落盘，重启读取一致")
    st.update({"close_behavior": "bogus"})
    check(st.data["close_behavior"] == "minimize", "非法 close_behavior 回退 minimize")
    st.update({"window": {"width": 100, "height": 100}})
    w = st.data["window"]
    check(w["width"] >= 980 and w["height"] >= 640, "窗口尺寸低于下限时钳制", f"{w}")
    with open(spath, "w", encoding="utf-8") as fh:
        fh.write("{ 不是合法 JSON")
    st2 = Settings(spath, startup_command='"x"')
    check(st2.data["close_behavior"] == "minimize", "settings.json 损坏 → 回默认值可启动")

    # ===== 3. 开机自启注册表（独立键名，不碰真实项） =====
    print("== 3. 开机自启注册表 ==")
    old_name = settings_mod.RUN_NAME
    settings_mod.RUN_NAME = "WeChatAutoSenderSelfTest"
    try:
        import winreg
        st3 = Settings(spath, startup_command='"C:\\fake\\app.exe" --startup')
        st3.update({"auto_start": True})
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, settings_mod.RUN_KEY) as key:
            val, _ = winreg.QueryValueEx(key, settings_mod.RUN_NAME)
        check(val == '"C:\\fake\\app.exe" --startup', "开启自启 → Run 键值 = 启动命令", val)
        check(st3.is_auto_start() is True, "is_auto_start 如实反映注册表")
        # 手动删掉模拟注册表被清理，sync 应按设置意图重写
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, settings_mod.RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, settings_mod.RUN_NAME)
        st3.sync_auto_start_on_boot()
        check(st3.is_auto_start() is True, "注册表被清后 sync_auto_start_on_boot 自愈重写")
        st3.update({"auto_start": False})
        check(st3.is_auto_start() is False, "关闭自启 → Run 键删除")
        st3.update({"auto_start": True})   # 再开一次，最后统一清理
    finally:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, settings_mod.RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
                winreg.DeleteValue(key, settings_mod.RUN_NAME)
        except OSError:
            pass
        settings_mod.RUN_NAME = old_name

    # ===== 4. /api/settings =====
    print("== 4. /api/settings 接口 ==")
    from contacts import ContactStore
    from wechat_auto.webapp import WebConsole
    settings_mod.RUN_NAME = "WeChatAutoSenderSelfTest"
    try:
        store = ContactStore(os.path.join(tmp, "data", "contacts.json"))
        st_api = Settings(spath, startup_command='"C:\\fake\\app.exe" --startup')
        console = WebConsole(tmp, store, cfg=None, settings=st_api)
        view = console.settings_view()
        check(view["client_mode"] is True and view["settings"]["close_behavior"] in ("minimize", "exit"),
              "GET：客户端模式返回设置视图")
        console.settings_update({"auto_start": True, "close_behavior": "exit"})
        disk = json.load(open(spath, encoding="utf-8"))
        check(disk["auto_start"] is True and disk["close_behavior"] == "exit",
              "PUT：改动落盘 settings.json")
        check(st_api.is_auto_start() is True, "PUT auto_start → 注册表联动")
        view = console.settings_update({"close_behavior": "hack"})
        check(view["settings"]["close_behavior"] == "minimize", "PUT 非法值 → 服务端同样回退")

        browser = WebConsole(tmp, store, cfg=None, settings=None)
        check(browser.settings_view()["client_mode"] is False, "浏览器模式 GET：client_mode=False")
        expect_error(lambda: browser.settings_update({"auto_start": True}),
                     "浏览器控制台模式", "浏览器模式 PUT 被拒绝")

        # 真实 HTTP 路由冒烟：GET /api/settings（响应结构 {"ok":true,"data":{...}}）
        console.start(18899, open_browser=False)
        try:
            with urllib.request.urlopen(f"{console.url}/api/settings", timeout=5) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
            data = payload.get("data") or {}
            check(payload.get("ok") is True and data.get("client_mode") is True,
                  "HTTP GET /api/settings 路由可达")
        finally:
            console.stop()
    finally:
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, settings_mod.RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
                winreg.DeleteValue(key, settings_mod.RUN_NAME)
        except OSError:
            pass
        settings_mod.RUN_NAME = old_name

    # ===== 5. 冒烟：完整生命周期 =====
    if not args.no_smoke:
        print("== 5. client.py --smoke 冒烟（3 秒真实窗口）==")
        lock = os.path.join(ROOT, "logs", "wechat_auto.lock")
        running = False
        if os.path.exists(lock):
            try:
                pid = int(open(lock, encoding="utf-8").read().strip() or 0)
            except Exception:
                pid = 0
            if pid and pid != os.getpid():
                from wechat_auto.safety import _process_alive
                running = _process_alive(pid)
        if running:
            check(False, "跳过冒烟：检测到程序正在运行（PID 见锁文件）", f"pid={pid}")
        else:
            log_before = os.path.getsize(os.path.join(ROOT, "logs", "run.log")) \
                if os.path.exists(os.path.join(ROOT, "logs", "run.log")) else 0
            proc = subprocess.run(
                [sys.executable, os.path.join(ROOT, "client.py"), "--smoke"],
                cwd=ROOT, capture_output=True, text=True, timeout=90)
            check(proc.returncode == 0, "冒烟退出码 0", f"rc={proc.returncode} {proc.stderr[-200:] if proc.stderr else ''}")
            tail = ""
            try:
                with open(os.path.join(ROOT, "logs", "run.log"), encoding="utf-8", errors="replace") as fh:
                    fh.seek(max(0, log_before))
                    tail = fh.read()
            except OSError:
                pass
            check("[客户端] 程序退出" in tail, "退出流程完整（run.log 记录程序退出）")
            check("[客户端] 主窗口已创建" in tail, "窗口正常创建并进入消息循环")

        # ===== 6. 打包产物冒烟（dist 存在时） =====
        dist_exe = os.path.join(ROOT, "dist", "微信定时发送", "微信定时发送.exe")
        if os.path.exists(dist_exe):
            print("== 6. 打包产物冒烟（dist exe，无控制台模式）==")
            proc = subprocess.run([dist_exe, "--smoke"], cwd=ROOT, capture_output=True, timeout=90)
            check(proc.returncode == 0, "打包 exe 冒烟退出码 0", f"rc={proc.returncode}")
        else:
            print("== 6. 打包产物冒烟：dist 未构建，跳过 ==")

    shutil.rmtree(tmp, ignore_errors=True)
    print()
    if FAILS:
        print(f"❌ 失败 {len(FAILS)} 项：{FAILS}")
        sys.exit(1)
    print("✅ 全部通过")


if __name__ == "__main__":
    main()
