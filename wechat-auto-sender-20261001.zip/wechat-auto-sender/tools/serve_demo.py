# -*- coding: utf-8 -*-
"""完整功能演示实例：调度器 + 网页控制台，不进控制台 TUI。

用途：
- 体验/演示网页控制台的全部功能（暂停、演练、目标管理、调度编辑……）
- 无浏览器环境下的轻量常驻方式

注意：与 app.py 不同，这里**不取单实例锁**。若同时双击桌面图标启动主程序，
会出现两个调度进程（本实例通常没有启用的目标，不会重复发送，
但正式使用请只用一个入口：双击「微信定时发送」）。

运行：python tools/serve_demo.py [--port 8899] [--open]
"""
import argparse
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "workbench"))
os.chdir(ROOT)

import app as appmod  # noqa: E402
from contacts import ContactStore  # noqa: E402
from wechat_auto import logger as logutil  # noqa: E402
from wechat_auto.config_loader import Config  # noqa: E402
from wechat_auto.webapp import WebConsole  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8899)
    parser.add_argument("--open", action="store_true", help="启动后自动打开浏览器")
    args = parser.parse_args()

    cfg = Config(ROOT)
    logger = logutil.setup(ROOT)
    scheduler = appmod.build_scheduler(cfg, logger)
    scheduler.start()
    state = {"paused": False}
    controller = appmod.TaskController(scheduler, cfg, logger, state)
    store = ContactStore(os.path.join(ROOT, "data", "contacts.json"))

    def rebuild():
        cfg.reload()
        scheduler.remove_all_jobs()
        if state.get("paused"):
            scheduler.pause()
        appmod.register_jobs(scheduler, cfg, logger)

    web = WebConsole(
        ROOT, store, cfg=cfg, controller=controller,
        run_now=lambda real: appmod.web_run(cfg, logger, real=real),
        logger=logger, on_config_change=rebuild,
    )
    port = web.start(args.port, open_browser=args.open)
    print(f"完整功能演示实例：{web.url}")
    print("Ctrl+C 退出；正式使用请双击桌面「微信定时发送」")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        web.stop()
        scheduler.shutdown(wait=False)


if __name__ == "__main__":
    main()
