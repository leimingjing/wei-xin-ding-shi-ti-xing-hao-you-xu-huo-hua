# -*- coding: utf-8 -*-
"""图像匹配模板采集工具（UI 自动化失效时的兜底）。

用法：
    python tools/capture_templates.py
运行后按提示把鼠标移到目标元素中心，脚本自动截取周围区域存为模板。
"""
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")

import win32api  # noqa: E402
from PIL import ImageGrab  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TPL_DIR = os.path.join(ROOT, "assets", "templates")
os.makedirs(TPL_DIR, exist_ok=True)

TARGETS = [
    ("search_box.png", "微信左上角的【搜索】框", 120, 36),
    ("input_box.png", "聊天窗口底部的【消息输入框】", 160, 40),
]


def capture(name, desc, width, height):
    print("")
    print(f"请在 8 秒内把鼠标移到 {desc} 的中心位置并保持不动……")
    for i in range(8, 0, -1):
        print(f"  {i} 秒", end="\r", flush=True)
        time.sleep(1)
    x, y = win32api.GetCursorPos()
    box = (x - width // 2, y - height // 2, x + width // 2, y + height // 2)
    path = os.path.join(TPL_DIR, name)
    ImageGrab.grab(bbox=box).save(path)
    print(f"  已保存模板：{path}（采样点 {x},{y}）")


def main():
    print("=" * 60)
    print("图像匹配模板采集")
    print("用途：当 UI 自动化识别不到控件时，程序用这些模板做兜底定位。")
    print("=" * 60)
    for name, desc, w, h in TARGETS:
        capture(name, desc, w, h)
    print("")
    print("采集完成。模板位于 assets/templates/ 目录下。")


if __name__ == "__main__":
    main()
