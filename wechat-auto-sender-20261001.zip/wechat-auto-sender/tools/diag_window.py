# -*- coding: utf-8 -*-
"""微信窗口状态诊断 / 解锁。

只读诊断（默认）：
    python tools/diag_window.py
解锁（清置顶、恢复被禁用窗口、还原最小化）：
    python tools/diag_window.py --unlock
强制结束无响应的微信进程（最后手段）：
    python tools/diag_window.py --kill

用途：自动执行期间会操作微信窗口（激活/截图/发消息），
若中途异常退出可能留下「窗口置顶 / 被禁用 / 最小化到托盘」等残留状态，
表现就是窗口点不动、关不掉、缩不小。
"""
import argparse
import ctypes
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import win32api  # noqa: E402
import win32con  # noqa: E402
import win32gui  # noqa: E402
import win32process  # noqa: E402

try:  # 与运行时一致，保证坐标口径统一
    from wechat_auto.input import kbdmouse  # noqa: F401,E402
except Exception:
    pass

GWL_STYLE = -16
GWL_EXSTYLE = -20
WM_NULL = 0x0000
SMTO_ABORTIFHUNG = 0x0002
WM_SYSCOMMAND = 0x0112
SC_CLOSE = 0xF060
SC_MINIMIZE = 0xF020

STYLE_BITS = (
    (0x08000000, "WS_DISABLED 窗口被禁用"),
    (0x20000000, "WS_MINIMIZE 最小化"),
    (0x01000000, "WS_MAXIMIZE 最大化"),
    (0x10000000, "WS_VISIBLE 可见"),
    (0x00C00000, "WS_CAPTION 有标题栏"),
    (0x00040000, "WS_THICKFRAME 可缩放"),
)
EX_BITS = (
    (0x00000008, "WS_EX_TOPMOST 总在最前"),
    (0x00000080, "WS_EX_TOOLWINDOW 工具窗"),
    (0x00040000, "WS_EX_APPWINDOW"),
    (0x00000020, "WS_EX_TRANSPARENT 点击穿透"),
    (0x00200000, "WS_EX_NOREDIRECTIONBITMAP 未响应幽灵窗"),
)


def _proc_name(hwnd):
    try:
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)  # QUERY_LIMITED_INFORMATION
        name = ""
        if handle:
            try:
                name = os.path.basename(win32process.GetModuleFileNameEx(handle, 0)).lower()
            finally:
                ctypes.windll.kernel32.CloseHandle(handle)
        return pid, name
    except Exception:
        return 0, ""


def _flags(value, table):
    return [desc for bit, desc in table if value & bit]


def find_wechat_windows():
    out = []

    def cb(hwnd, _):
        try:
            if win32gui.GetParent(hwnd) != 0:
                return True
            pid, name = _proc_name(hwnd)
            if name not in ("weixin.exe", "wechat.exe"):
                return True
            cls = win32gui.GetClassName(hwnd) or ""
            low = cls.lower()
            if "ime" in low or "msctfime" in low:
                return True
            r = win32gui.GetWindowRect(hwnd)
            out.append((hwnd, cls, win32gui.GetWindowText(hwnd) or "", r, name))
        except Exception:
            pass
        return True

    win32gui.EnumWindows(cb, None)
    out.sort(key=lambda x: -(x[3][2] - x[3][0]) * (x[3][3] - x[3][1]))
    return out


class _Log:
    def info(self, m):
        print(m)

    warning = error = info


def responsive(hwnd, timeout_ms=1500):
    """发送 WM_NULL 探测窗口是否还在处理消息。"""
    try:
        res = ctypes.c_ulong()
        ok = ctypes.windll.user32.SendMessageTimeoutW(
            hwnd, WM_NULL, 0, 0, SMTO_ABORTIFHUNG, timeout_ms, ctypes.byref(res))
        return bool(ok)
    except Exception:
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--unlock", action="store_true", help="解锁：清置顶 / 恢复禁用 / 还原最小化")
    ap.add_argument("--fix", action="store_true",
                    help="把主窗口拉回屏幕可见区（标题栏按钮跑到屏幕外时用它）")
    ap.add_argument("--kill", action="store_true", help="结束无响应的微信进程（最后手段）")
    args = ap.parse_args()

    wins = find_wechat_windows()
    if not wins:
        print("没有找到微信窗口（可能已退出或最小化到托盘且不属顶层窗口）")
        return 0
    fg = ctypes.windll.user32.GetForegroundWindow()
    print(f"前台窗口 hwnd={fg}\n")

    for hwnd, cls, title, rect, proc in wins[:6]:
        style = win32gui.GetWindowLong(hwnd, GWL_STYLE)
        ex = win32gui.GetWindowLong(hwnd, GWL_EXSTYLE)
        alive = responsive(hwnd)
        icon = win32gui.IsIconic(hwnd)
        print(f"hwnd={hwnd}  [{proc}]")
        print(f"  类名={cls!r} 标题={title!r}")
        print(f"  矩形=({rect[0]}, {rect[1]}) {rect[2]-rect[0]}x{rect[3]-rect[1]}  最小化标记={icon}")
        print(f"  响应= {'是' if alive else '否（无响应/卡死）'}")
        print(f"  样式: {_flags(style, STYLE_BITS) or '无特殊'}")
        print(f"  扩展样式: {_flags(ex, EX_BITS) or '无特殊'}")
        print(f"  是否前台: {hwnd == fg}\n")

    if args.fix:
        from wechat_auto.config_loader import Config
        from wechat_auto.wechat.window import WeChatWindow, ensure_on_screen

        win = WeChatWindow(Config(ROOT).wechat, _Log())
        control = win.find(timeout=3)
        if not control:
            print("没有找到微信主窗口")
            return 1
        print(f"主窗口 hwnd={control.NativeWindowHandle}")
        moved = ensure_on_screen(control.NativeWindowHandle, print)
        print("已拉回屏幕可见区" if moved else "窗口本来就在屏幕内，无需移动")
        return 0

    if not (args.unlock or args.kill):
        return 0

    target = wins[0]
    hwnd, cls, title, rect, proc = target
    if args.unlock:
        print(f"--- 解锁 {hwnd} ---")
        style = win32gui.GetWindowLong(hwnd, GWL_STYLE)
        ex = win32gui.GetWindowLong(hwnd, GWL_EXSTYLE)
        if ex & 0x8:
            win32gui.SetWindowPos(hwnd, -2, 0, 0, 0, 0,  # HWND_NOTOPMOST
                                  win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_NOACTIVATE)
            print("已清除「总在最前」")
        if style & 0x08000000:
            ctypes.windll.user32.EnableWindow(hwnd, True)
            print("已恢复窗口可用（EnableWindow True）")
        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            print("已从最小化还原")
        time.sleep(0.5)
        print(f"解锁后响应={responsive(hwnd)}")
        return 0

    if args.kill:
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        print(f"结束进程 {proc} (pid={pid}) …")
        rc = ctypes.windll.kernel32.OpenProcess(1, False, pid)  # PROCESS_TERMINATE
        if rc:
            ctypes.windll.kernel32.TerminateProcess(rc, 1)
            ctypes.windll.kernel32.CloseHandle(rc)
        print("已结束。重新打开微信即可。")
        return 0


if __name__ == "__main__":
    sys.exit(main())
