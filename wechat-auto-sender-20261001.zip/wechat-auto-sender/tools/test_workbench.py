# -*- coding: utf-8 -*-
"""模拟双击：start.bat -> 工作台，验证任务状态、联系人增删改、退出。

要点：
- 输入用管道喂给 TUI，所以**步数必须和程序实际提问次数严格对齐**，
  否则后面的输入会串到别的提示上（曾经因此出现"没真跑却全 OK"的假通过）。
  主菜单每个动作后都会 pause 等一次回车，因此每个动作后补一个空行。
- 断言尽量落在**数据文件**上（唯一强证据），而不是只做子串匹配——
  子串很容易被菜单文案误命中。
- 测试会先把数据文件临时清空（保证流程确定），结束（含异常）后原样还原。
"""
import json
import os
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data", "contacts.json")

TEST_NAME = "测试老王"
TEST_CONTACT = "test@example.com"
TEST_TIME = "2026-09-13 08:30"

# 每行是一次回车；"" 是动作后的 pause（按回车返回主菜单）
STEPS = [
    "6", "",                                            # 发送任务状态
    "7", "",                                            # 暂停
    "6", "",                                            # 再看状态（应显示已暂停）
    "7", "",                                            # 恢复
    "1", "",                                            # 查看联系人（此时为空）
    "2", TEST_NAME, "", TEST_TIME, "",                  # 新增：联系方式留空（可选字段）
    "1", "1", "",                                       # 列表 -> 详情 #1
    "3", "1", "2", TEST_CONTACT, "0", "",               # 编辑：改联系方式（2=联系方式）
    "1", "0", "",                                       # 再查看列表（应显示新联系方式）
    "5", TEST_NAME, "",                                 # 搜索联系人
    "0",                                                # 退出
]


def load_data():
    with open(DATA, "r", encoding="utf-8") as fh:
        return json.load(fh)


def main():
    backup = open(DATA, "r", encoding="utf-8").read() if os.path.exists(DATA) else None
    ok = False
    try:
        # 先清空，让"查看联系人（空）"这一步稳定成立
        with open(DATA, "w", encoding="utf-8", newline="") as fh:
            fh.write(json.dumps({"version": 1, "contacts": []}, ensure_ascii=False, indent=2))

        proc = subprocess.run(
            ["cmd", "/c", "start.bat", "--no-browser"],
            cwd=ROOT,
            input="\n".join(STEPS) + "\n",
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=120,
        )
        out = proc.stdout
        print("退出码:", proc.returncode)
        if proc.stderr.strip():
            print("stderr:", proc.stderr.strip()[:600])

        rows = load_data()["contacts"]
        saved = next((c for c in rows if c["name"] == TEST_NAME), None)

        checks = {
            "标题为微信定时发送工作台": "微信定时发送 · 管理员工作台" in out,
            "显示发送任务概要": "发送任务" in out,
            "任务状态页可用": "调度状态" in out,
            "暂停生效": "定时任务已暂停" in out,
            "状态显示已暂停": "已暂停" in out,
            "恢复生效": "定时任务已恢复" in out,
            "空列表有引导文案": "还没有联系人" in out,
            "新增成功（联系方式留空）": saved is not None,
            # 新增时联系方式留空 → 提示里应显示"未登记"（证明空值被接受）
            "留空时新增提示显示未登记": f"{TEST_NAME} | 未登记 | {TEST_TIME}" in out,
            "编辑联系方式已保存": "已更新联系方式并保存" in out,
            # 最终数据文件里联系方式已是邮箱（新增留空 → 编辑补上，两步都对才会这样）
            "数据文件里最终为邮箱联系方式": saved is not None and saved["contact"] == TEST_CONTACT
            and saved["contact_type"] == "邮箱",
            "列表显示新联系方式": TEST_CONTACT in out,
            "详情页显示新联系方式": "联系方式" in out and TEST_CONTACT in out,
            "菜单含 7 项功能": "7. 暂停/恢复发送任务" in out,
            "无独立工作台入口残留": "联系人管理台" not in out,
            "退出提示": "已退出工作台" in out,
        }
        for k, v in checks.items():
            print(f"  [{'OK' if v else 'FAIL'}] {k}")

        ok = all(checks.values()) and proc.returncode == 0
        print("\n--- 运行结束时的数据文件 ---")
        print(json.dumps(load_data(), ensure_ascii=False, indent=2)[:400])
    finally:
        if backup is not None:
            with open(DATA, "w", encoding="utf-8", newline="") as fh:
                fh.write(backup)
            print("（已还原 data/contacts.json）")

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
