# -*- coding: utf-8 -*-
"""控制台视觉系统：色板 / 网格 / 组件。

职责边界：本模块只回答"怎么显示"，不含任何业务判断。
联系人数据层（contacts.py）与发送任务的暂停/状态逻辑（app.py 的
TaskController）都未被改动，这里只是把它们的输出重新排版。

设计要点
--------
1. 配色：语义化 token（text / muted / faint / accent / ok / warn / err / border），
   深色与浅色两套色板，取值经过对比度调整（浅色底不用亮绿做正文，改用深绿）。
2. 主题：自动探测控制台背景明暗（GetConsoleScreenBufferInfoEx 读调色板），
   也可用环境变量 WECHAT_THEME=dark|light|none 强制。
3. 网格：所有宽度按"字符显示宽度"计算（中日韩全角算 2 列），
   保证中文与英文混排时表格严格对齐。
4. 响应式：宽度取终端列数并夹在 [MIN_WIDTH, MAX_WIDTH]，按断点切换布局——
   宽终端用表格/双列，窄终端自动降级为堆叠卡片/单列。
5. 字体字号：由终端决定，程序不去改用户字体设置；层级靠色阶 + 字重（bold）建立。
6. 降级：真彩色 → 256 色 → 无色；Unicode 边框 → ASCII 边框；全屏重绘 → 追加输出。
   逐级可退，保证任何终端下都不会出现乱码。

环境变量
--------
WECHAT_THEME=auto|dark|light|none   主题（none = 不上色）
WECHAT_COLOR=auto|truecolor|256|off  颜色深度
WECHAT_TUI=1|0                       全屏重绘（仅在有真实终端时生效）
WECHAT_ASCII=1                       强制 ASCII 边框/图标
"""
from __future__ import annotations

import os
import re
import shutil
import sys
import threading
import time
import unicodedata

# ------------------------------------------------------------------ 色板
PALETTE = {
    "dark": {
        "text": (229, 233, 240),
        "muted": (154, 164, 181),
        "faint": (108, 117, 133),
        "accent": (7, 193, 96),      # 微信绿，深底上足够亮
        "accent2": (88, 166, 255),
        "ok": (63, 185, 80),
        "warn": (210, 153, 34),
        "err": (248, 81, 73),
        "border": (58, 65, 74),
        "border2": (38, 43, 50),
        "key": (7, 193, 96),
    },
    "light": {
        "text": (31, 35, 40),
        "muted": (89, 99, 110),
        "faint": (129, 139, 152),
        "accent": (10, 123, 69),     # 浅底上压暗，保证 4.5:1 以上对比
        "accent2": (9, 105, 218),
        "ok": (26, 127, 55),
        "warn": (154, 103, 0),
        "err": (207, 34, 46),
        "border": (209, 217, 224),
        "border2": (230, 234, 239),
        "key": (10, 123, 69),
    },
}

BOLD_TOKENS = {"key"}

# 语义别名的映射：调用方只关心语义，不关心用哪个 token
ALIAS = {
    "title": "text", "body": "text", "dim": "muted", "hint": "faint",
    "info": "accent2", "success": "ok", "warning": "warn", "danger": "err",
    "line": "border", "line2": "border2",
}

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

MIN_WIDTH = 34
MAX_WIDTH = 96                # 内容区上限：+2 缩进后仍能塞进 100 列窗口，不触发横向滚动
WIDE_BREAKPOINT = 74          # 小于此宽度切换为窄布局
INDENT = 2                    # 全局左缩进，统一留白节奏


# ------------------------------------------------------------------ 宽度工具
def display_width(text: str) -> int:
    """按终端列宽计算字符串宽度（忽略 ANSI，全角算 2）。"""
    if not text:
        return 0
    plain = _ANSI_RE.sub("", text)
    total = 0
    for ch in plain:
        if unicodedata.combining(ch):
            continue
        total += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return total


def _char_width(ch: str) -> int:
    return 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1


def _rgb_to_256(r: int, g: int, b: int) -> int:
    if abs(r - g) < 12 and abs(g - b) < 12:
        if r < 8:
            return 16
        if r > 248:
            return 231
        return 232 + round((r - 8) / 247 * 24)
    return 16 + 36 * round(r / 255 * 5) + 6 * round(g / 255 * 5) + round(b / 255 * 5)


# ------------------------------------------------------------------ 终端能力
class _COORD(object):
    pass


def _enable_vt() -> bool:
    """打开 Windows 控制台的 VT 序列解析。"""
    if os.name != "nt":
        return True
    try:
        import ctypes

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.GetStdHandle.argtypes = [ctypes.c_int]
        k32.GetStdHandle.restype = ctypes.c_void_p
        k32.GetConsoleMode.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        k32.SetConsoleMode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
        handle = k32.GetStdHandle(-11)
        if not handle:
            return False
        mode = ctypes.c_ulong()
        if not k32.GetConsoleMode(handle, ctypes.byref(mode)):
            return False
        return bool(k32.SetConsoleMode(handle, mode.value | 0x0004))
    except Exception:
        return False


def _detect_background() -> str:
    """读控制台调色板里"背景色"的亮度，判断深色还是浅色终端。"""
    if os.name != "nt":
        return "dark"
    try:
        import ctypes

        class COORD(ctypes.Structure):
            _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]

        class SMALL_RECT(ctypes.Structure):
            _fields_ = [
                ("Left", ctypes.c_short), ("Top", ctypes.c_short),
                ("Right", ctypes.c_short), ("Bottom", ctypes.c_short),
            ]

        class CSBIEX(ctypes.Structure):
            _fields_ = [
                ("cbSize", ctypes.c_ulong),
                ("dwSize", COORD),
                ("dwCursorPosition", COORD),
                ("wAttributes", ctypes.c_ushort),
                ("srWindow", SMALL_RECT),
                ("dwMaximumWindowSize", COORD),
                ("wPopupAttributes", ctypes.c_ushort),
                ("bFullscreenSupported", ctypes.c_int),
                ("ColorTable", ctypes.c_ulong * 16),
            ]

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.GetStdHandle.argtypes = [ctypes.c_int]
        k32.GetStdHandle.restype = ctypes.c_void_p
        k32.GetConsoleScreenBufferInfoEx.argtypes = [ctypes.c_void_p, ctypes.POINTER(CSBIEX)]

        handle = k32.GetStdHandle(-11)
        info = CSBIEX()
        info.cbSize = ctypes.sizeof(info)
        if not k32.GetConsoleScreenBufferInfoEx(handle, ctypes.byref(info)):
            return "dark"
        index = (info.wAttributes >> 4) & 0x0F
        ref = info.ColorTable[index]
        r, g, b = ref & 0xFF, (ref >> 8) & 0xFF, (ref >> 16) & 0xFF
        luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255
        return "light" if luminance > 0.5 else "dark"
    except Exception:
        return "dark"


def _set_title(title: str):
    if os.name != "nt":
        return
    try:
        import ctypes

        ctypes.windll.kernel32.SetConsoleTitleW(ctypes.c_wchar_p(title))
    except Exception:
        pass


# ------------------------------------------------------------------ 主题对象
class Theme:
    """一次初始化的全局视觉配置。"""

    def __init__(self, mode: str = "auto", color: str = "auto", tui=None):
        env_mode = (os.environ.get("WECHAT_THEME") or mode or "auto").strip().lower()
        env_color = (os.environ.get("WECHAT_COLOR") or color or "auto").strip().lower()

        self.is_tty = bool(getattr(sys.stdout, "isatty", lambda: False)())
        self.vt = _enable_vt()

        if env_mode in ("dark", "light"):
            self.mode = env_mode
        elif env_mode in ("none", "off", "no"):
            self.mode = "dark"
            env_color = "off"
        else:
            self.mode = _detect_background()

        # 颜色：auto 时按终端能力判断；显式指定 truecolor/256 则视为强制
        forced = env_color in ("truecolor", "256")
        if env_color == "off":
            self.color_depth = "off"
        elif forced:
            self.color_depth = env_color
        elif not self.is_tty or not self.vt:
            self.color_depth = "off"
        else:
            self.color_depth = "truecolor"

        self.unicode = not (
            os.environ.get("WECHAT_ASCII") == "1" or not self._can_encode("╭─│╰●✓")
        )

        if tui is None:
            tui = os.environ.get("WECHAT_TUI", "1") != "0"
        self.tui = bool(tui and self.is_tty and self.vt)

        self._alt = False
        self._codes = self._build_codes()

    # ---------- 内部 ----------
    @staticmethod
    def _can_encode(text: str) -> bool:
        try:
            text.encode(sys.stdout.encoding or "utf-8")
            return True
        except Exception:
            return False

    def _build_codes(self) -> dict:
        codes = {}
        table = PALETTE[self.mode]
        for name, rgb in table.items():
            if self.color_depth == "off":
                codes[name] = ""
                continue
            r, g, b = rgb
            if self.color_depth == "256":
                codes[name] = f"\x1b[38;5;{_rgb_to_256(r, g, b)}m"
            else:
                codes[name] = f"\x1b[38;2;{r};{g};{b}m"
        return codes

    @staticmethod
    def _w(text: str):
        try:
            sys.stdout.write(text)
            sys.stdout.flush()
        except UnicodeEncodeError:
            enc = sys.stdout.encoding or "utf-8"
            sys.stdout.write(text.encode(enc, "replace").decode(enc, "replace"))
            sys.stdout.flush()
        except Exception:
            pass

    # ---------- 基础 ----------
    @property
    def reset(self) -> str:
        return "\x1b[0m" if self.color_depth != "off" else ""

    def paint(self, token: str, text: str, bold: bool = False) -> str:
        """按语义 token 上色。token 不存在时原样返回，不会抛错。"""
        if self.color_depth == "off" or not text:
            return text
        name = ALIAS.get(token, token)
        code = self._codes.get(name, "")
        if not code:
            return text
        weight = "\x1b[1m" if (bold or name in BOLD_TOKENS) else ""
        return f"{weight}{code}{text}{self.reset}"

    # ---------- 宽度 ----------
    @staticmethod
    def _terminal_columns() -> int:
        """优先直接问控制台要列数。

        不能只依赖 shutil.get_terminal_size：它会优先读环境变量 COLUMNS，
        而 MSYS / CI / 某些终端会把这个变量设成与真实窗口不符的值，
        结果算出的行宽比可视宽度还大，右侧内容被切掉（实测踩过）。
        """
        try:
            return os.get_terminal_size(sys.stdout.fileno()).columns
        except Exception:
            pass
        try:
            return shutil.get_terminal_size((96, 30)).columns
        except Exception:
            return 96

    @property
    def width(self) -> int:
        """内容区总宽（含左缩进），随终端列数自适应。"""
        return max(MIN_WIDTH, min(self._terminal_columns() - 4, MAX_WIDTH))

    @property
    def wide(self) -> bool:
        return self.width >= WIDE_BREAKPOINT

    @staticmethod
    def dw(text: str) -> int:
        return display_width(text)

    def pad(self, text: str, width: int, align: str = "<") -> str:
        gap = width - self.dw(text)
        if gap <= 0:
            return text
        if align == ">":
            return " " * gap + text
        if align == "^":
            left = gap // 2
            return " " * left + text + " " * (gap - left)
        return text + " " * gap

    def trunc(self, text: str, width: int, ellipsis: str = None) -> str:
        """按显示宽度截断并补足到 width（表格单元格专用）。"""
        if ellipsis is None:
            ellipsis = "…" if self.unicode else ".."
        plain = _ANSI_RE.sub("", text or "")
        if self.dw(plain) <= width:
            return self.pad(plain, width)
        if width <= 0:
            return ""
        room = width - self.dw(ellipsis)
        if room <= 0:
            return ellipsis[:width]
        out, used = [], 0
        for ch in plain:
            w = _char_width(ch)
            if used + w > room:
                break
            out.append(ch)
            used += w
        return "".join(out) + ellipsis + " " * (width - used - self.dw(ellipsis))

    def trunc_left(self, text: str, width: int) -> str:
        """从左侧截断（长路径保留尾部更有用）。"""
        plain = _ANSI_RE.sub("", text or "")
        if self.dw(plain) <= width:
            return plain
        out, used = [], 0
        for ch in reversed(plain):
            w = _char_width(ch)
            if used + w > width - 1:
                break
            out.append(ch)
            used += w
        return "…" + "".join(reversed(out))

    def fit(self, text: str, width: int) -> str:
        """未超宽就原样保留（保住颜色），超宽才截断。卡片正文用。"""
        if self.dw(text) <= width:
            return text + " " * (width - self.dw(text))
        return self.trunc(text, width)

    def wrap(self, text: str, width: int, first: str = "", rest: str = "") -> list:
        """按显示宽度折行，中文不按空格断词。"""
        plain = _ANSI_RE.sub("", text or "")
        lines, current, used = [], first, self.dw(first)
        for ch in plain:
            if ch == "\n":
                lines.append(current)
                current, used = rest, self.dw(rest)
                continue
            w = _char_width(ch)
            if used + w > width:
                lines.append(current)
                current, used = rest, self.dw(rest)
            current += ch
            used += w
        lines.append(current)
        return lines

    # ---------- 全屏重绘 ----------
    def screen_begin(self):
        if not self.tui:
            return
        if not self._alt:
            self._w("\x1b[?1049h")
            self._alt = True
        self._w("\x1b[?25l\x1b[2J\x1b[H")

    def show_cursor(self):
        if self.tui:
            self._w("\x1b[?25h")

    def screen_end(self):
        if self._alt:
            self._w("\x1b[?25h\x1b[?1049l")
            self._alt = False

    def draw(self, lines) -> None:
        # 逐行去掉行尾空白：卡片内部的填充在边框之前，不受影响
        self._w("\n".join(str(line).rstrip() for line in lines) + "\n")

    @staticmethod
    def blank(count: int = 1) -> list:
        return [""] * count

    # ---------- 原子组件 ----------
    def rule(self, label: str = "", token: str = "border") -> str:
        # 容错：rule("border2") 这种把色板名当标签的写法，按 token 处理
        if label and token == "border" and label in PALETTE["dark"]:
            label, token = "", label
        total = self.width
        if not label:
            head = ""
            fill = total - INDENT
        else:
            head = f"{label} "
            fill = total - INDENT - self.dw(label) - 2
        char = "─" if self.unicode else "-"
        return " " * INDENT + self.paint(token, head + char * max(1, fill))

    def section(self, label: str) -> str:
        """区块标题：一条带标签的分隔线，用来划分视觉层次。"""
        return self.rule(label, "border")

    @property
    def card_inner(self) -> int:
        """卡片正文可用宽度（卡片左右各让出边框 + 1 空格）。"""
        return max(8, self.width - INDENT - 4)

    def _key_cell(self, key: str, key_width: int) -> str:
        """键名单元格：至少留 2 空格间隔，避免长键名顶到值上。"""
        cell = self.pad(key, key_width)
        if self.dw(key) + 2 > key_width:
            cell += "   "
        return cell

    def kv_columns(self, rows, key_width: int, columns: int = 2, limit: int = None) -> int:
        """值太长时自动退回单列，宁可多占一行也不截断信息。"""
        if columns <= 1 or not self.wide or not rows:
            return 1
        usable = limit or self.width
        gap = 3
        cell_w = (usable - INDENT - gap * (columns - 1)) // columns
        room = cell_w - key_width - 2
        return columns if all(self.dw(str(v)) <= room for _, v in rows) else 1

    def kv(self, rows, columns: int = 1, key_width: int = 12, indent: int = INDENT,
           limit: int = None) -> list:
        """键值对网格。宽终端排成双列，窄终端自动回落到单列。

        limit 用于卡片内部：可用宽度要比容器窄（卡片边框占据 4 列）。
        """
        usable = limit or self.width
        if columns <= 1:
            room = max(6, usable - indent - key_width)
            return [" " * indent + self.paint("muted", self._key_cell(key, key_width))
                    + self.paint("text", self.trunc(str(value), room))
                    for key, value in rows]

        gap = 3
        cell_w = max(key_width + 10, (usable - indent - gap * (columns - 1)) // columns)
        out, line, used = [], " " * indent, 0
        for key, value in rows:
            kcell = self._key_cell(key, key_width)
            room = max(6, cell_w - self.dw(kcell))
            cell = (self.paint("muted", kcell)
                    + self.paint("text", self.trunc(str(value), room)))
            line += self.pad(cell, cell_w) + " " * gap
            used += 1
            if used == columns:
                out.append(line.rstrip())
                line, used = " " * indent, 0
        if used:
            out.append(line.rstrip())
        return out

    def spread(self, widths, flexible: int = -1, indent: int = INDENT, gap: int = 2) -> list:
        """把内容区的剩余列宽补给伸缩列，让表格右边缘与卡片对齐。

        固定列宽本来就是给"内容定长"的列用的（编号、时间）；把余量交给
        可变长的那一列（如联系方式、发送时间），既吃满宽度又避免无谓截断。
        可用宽度不足时原样返回，由 trunc 兜底。
        """
        widths = list(widths)
        if not widths:
            return widths
        slack = self.width - indent - sum(widths) - gap * (len(widths) - 1)
        if slack > 0:
            widths[flexible] += slack
        return widths

    def table(self, headers, rows, widths, aligns=None, indent: int = INDENT) -> list:
        """等宽表格：表头 muted + 细下划线，单元格按显示宽度对齐。

        单元格可以是字符串，也可以是 (文本, 语义 token) 元组，用于逐列配色。
        """
        aligns = aligns or ["<"] * len(headers)
        sep_char = "─" if self.unicode else "-"
        out = [" " * indent + "  ".join(
            self.paint("muted", self.pad(str(h), w, a)) for h, w, a in zip(headers, widths, aligns)
        ).rstrip()]
        out.append(" " * indent + self.paint(
            "border2", "  ".join(sep_char * w for w in widths)))
        for row in rows:
            line = " " * indent
            for i, (cell, w, al) in enumerate(zip(row, widths, aligns)):
                if isinstance(cell, tuple):
                    text, token = cell
                else:
                    text, token = cell, ("faint" if i == 0 else "text")
                line += self.paint(token, self.pad(self.trunc(str(text), w), w, al)) + "  "
            out.append(line.rstrip())
        return out

    def card(self, lines, title: str = "", tone: str = "border") -> list:
        """圆角卡片。终端没有圆角/阴影，用圆角字符 + 描边色深浅代替层级。"""
        inner = max(8, self.width - INDENT - 4)
        if self.unicode:
            tl, tr, bl, br, hz, vt = "╭", "╮", "╰", "╯", "─", "│"
        else:
            tl, tr, bl, br, hz, vt = "+", "+", "+", "+", "-", "|"
        if title:
            # ╭─ title ─...─╮ 总宽 = inner + 4，与无标题卡片严格等宽
            head = f"{tl}{hz} {title} "
            head += hz * max(0, inner - self.dw(title) - 1) + tr
        else:
            head = tl + hz * (inner + 2) + tr
        out = [" " * INDENT + self.paint(tone, head)]
        for item in lines:
            for piece in str(item).split("\n"):
                out.append(" " * INDENT + self.paint(tone, vt) + " "
                           + self.fit(piece, inner) + " " + self.paint(tone, vt))
        out.append(" " * INDENT + self.paint(tone, bl + hz * (inner + 2) + br))
        return out

    def empty(self, title: str, hints=None, glyph: str = "○") -> list:
        """空状态：居中标题 + 引导行，避免只丢一句"暂无数据"。"""
        inner = self.width - INDENT - 4
        body = [""]
        if not self.unicode:
            glyph = "o"
        body.append(self.paint("faint", self.pad(glyph, inner, "^")))
        body.append("")
        body.append(self.paint("muted", self.pad(title, inner, "^")))
        body.append("")
        for hint in (hints or []):
            body.append(self.paint("faint", self.pad(hint, inner, "^")))
        body.append("")
        return self.card(body, tone="border2")

    def toast(self, kind: str, text: str, detail: str = "", limit: int = None) -> str:
        """单行结果反馈。glyph 与色调一起构成"微交互"的落点；过长自动折行缩进。"""
        glyphs = {"ok": "✓", "warn": "!", "err": "×", "info": "·"}
        if not self.unicode:
            glyphs = {"ok": "+", "warn": "!", "err": "x", "info": "-"}
        token = {"ok": "ok", "warn": "warn", "err": "err", "info": "accent2"}[kind]
        head = " " * INDENT + self.paint(token, glyphs[kind])
        room = max(10, (limit or self.width) - INDENT - 2)
        body = str(text) + ("  " + str(detail) if detail else "")
        if self.dw(body) <= room:
            return f"{head} {self.paint('text', text)}" + (
                "  " + self.paint("dim", detail) if detail else "")
        wrapped = self.wrap(str(text), room)
        out = [f"{head} {self.paint('text', wrapped[0])}"]
        for extra in wrapped[1:]:
            out.append(" " * (INDENT + 2) + self.paint("text", extra))
        if detail:
            for extra in self.wrap(str(detail), room - 2, rest="  "):
                out.append(" " * (INDENT + 2) + self.paint("dim", extra))
        return "\n".join(out)

    def notice(self, level: str, text: str, limit: int = None) -> str:
        """重放日志记录时的样式（把 logger 的级别映射成视觉语义）。"""
        kind = {"ERROR": "err", "CRITICAL": "err", "WARNING": "warn"}.get(level, "info")
        return self.toast(kind, text, limit=limit)

    def strip(self, items, indent: int = INDENT) -> list:
        """徽标状态条：● 名称 值。宽度不够时自动换行，是响应式的基本单位。"""
        dot = "●" if self.unicode else "*"
        pieces = []
        for token, label, value in items:
            piece = self.paint(token, dot) + " " + self.paint("muted", label)
            if value:
                piece += " " + self.paint("text", value)
            pieces.append(piece)
        out, line = [], ""
        for piece in pieces:
            candidate = (line + "    " + piece) if line else (" " * indent + piece)
            if line and self.dw(candidate) > self.width:
                out.append(line)
                line = " " * indent + piece
            else:
                line = candidate
        if line:
            out.append(line)
        return out

    def item(self, number: str, text: str, hint: str = "", danger: bool = False) -> str:
        """导航项：编号做成"按键徽标"，右侧可选说明文字（窄终端自动省略）。"""
        key = self.paint("key", f"{number}.", bold=True)
        label = self.paint("danger" if danger else "text", text)
        line = "      " + key + " " + label
        if hint and self.wide:
            gap = self.width - 2 - self.dw(line) - self.dw(hint)
            line += " " * max(2, gap) + self.paint("faint", hint)
        return line

    def title_bar(self, title: str, subtitle: str = "") -> list:
        """页头：主标题 + 副标题，构成最高一级视觉层次。"""
        inner = self.width - INDENT - 4
        if self.unicode:
            tl, tr, bl, br, hz, vt = "╭", "╮", "╰", "╯", "─", "│"
        else:
            tl, tr, bl, br, hz, vt = "+", "+", "+", "+", "-", "|"
        out = [" " * INDENT + self.paint("border", tl + hz * (inner + 2) + tr)]
        out.append(" " * INDENT + self.paint("border", vt) + " "
                   + self.paint("accent", self.trunc(title, inner), bold=True)
                   + " " + self.paint("border", vt))
        if subtitle:
            out.append(" " * INDENT + self.paint("border", vt) + " "
                       + self.paint("faint", self.trunc(subtitle, inner))
                       + " " + self.paint("border", vt))
        out.append(" " * INDENT + self.paint("border", bl + hz * (inner + 2) + br))
        return out


# ------------------------------------------------------------------ 加载动效
class Spinner:
    """克制版加载指示：仅在真实终端里逐帧刷新单行，其它情况静默。"""

    FRAMES_UNICODE = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    FRAMES_ASCII = "-\\|/"

    def __init__(self, theme: Theme, label: str = "处理中"):
        self.theme = theme
        self.label = label
        self.supported = theme.tui
        self._stop = threading.Event()
        self._thread = None
        self.result = None

    def _spin(self):
        frames = self.FRAMES_UNICODE if self.theme.unicode else self.FRAMES_ASCII
        i = 0
        while not self._stop.is_set():
            frame = frames[i % len(frames)]
            self.theme._w("\r\x1b[K" + self.theme.paint("accent", frame)
                          + " " + self.theme.paint("muted", self.label))
            i += 1
            self._stop.wait(0.09)

    def __enter__(self):
        if self.supported:
            self.theme.show_cursor()
            self._thread = threading.Thread(target=self._spin, daemon=True)
            self._thread.start()
        elif self.label:
            print(self.label)
        return self

    def __exit__(self, *exc):
        if self.supported:
            self._stop.set()
            if self._thread:
                self._thread.join(timeout=1.0)
            self.theme._w("\r\x1b[K")
            self.theme.show_cursor()
        return False


# ------------------------------------------------------------------ 单例
_CURRENT: Theme = None


def init(mode: str = "auto", color: str = "auto", tui=None, title: str = "") -> Theme:
    global _CURRENT
    _CURRENT = Theme(mode=mode, color=color, tui=tui)
    if title:
        _set_title(title)
    return _CURRENT


def get() -> Theme:
    global _CURRENT
    if _CURRENT is None:
        _CURRENT = Theme()
    return _CURRENT
