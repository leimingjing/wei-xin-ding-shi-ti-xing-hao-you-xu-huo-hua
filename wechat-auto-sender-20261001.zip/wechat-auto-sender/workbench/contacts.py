# -*- coding: utf-8 -*-
"""联系人数据层：字段校验、JSON 持久化、增删改查。

界面逻辑放在 app.py，本模块只负责数据与校验，便于单独测试。
"""
from __future__ import annotations

import json
import os
import re
import tempfile
from datetime import datetime

TIME_FMT = "%Y-%m-%d %H:%M"
PHONE_RE = re.compile(r"^1[3-9]\d{9}$")
EMAIL_RE = re.compile(r"^[\w.!#$%&'*+/=?^`{|}~-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$")

FIELDS = ("name", "contact", "datetime")
FIELD_LABELS = {"name": "姓名", "contact": "联系方式", "datetime": "指定时间"}
# 联系方式允许留空：部分微信好友没有登记手机号/微信号，发送时靠姓名（备注名/昵称）
# 定位即可，不该因为填不出号码就卡住新增。姓名是身份标识、时间决定何时发，两者仍必填。
OPTIONAL_FIELDS = frozenset({"contact"})
# 联系方式留空时在界面上的展示文案
CONTACT_UNSET = "未登记"


class ValidationError(Exception):
    """输入校验失败。"""


def check_name(value: str) -> str:
    v = (value or "").strip()
    if not v:
        raise ValidationError("姓名不能为空")
    if len(v) > 30:
        raise ValidationError("姓名过长，最多 30 个字符")
    return v


def check_contact(value: str) -> tuple[str, str]:
    """校验联系方式，返回 (规范化值, 类型)。手机号与邮箱均可，**留空也合法**。

    留空返回 ("", CONTACT_UNSET)，表示"没登记号码"，不影响发送（发送靠姓名定位）。
    """
    v = (value or "").strip()
    if not v:
        return "", CONTACT_UNSET
    if PHONE_RE.match(v):
        return v, "手机"
    if EMAIL_RE.match(v):
        return v.lower(), "邮箱"
    raise ValidationError(
        "联系方式无效：请填写 11 位手机号（如 13800138000）或邮箱（如 someone@example.com），留空也可以"
    )


def is_optional(field: str) -> bool:
    """字段是否允许留空（供界面层复用，避免前后端判断不一致）。"""
    return field in OPTIONAL_FIELDS


def check_datetime(value: str) -> str:
    v = (value or "").strip()
    if not v:
        raise ValidationError("指定时间不能为空")
    try:
        return datetime.strptime(v, TIME_FMT).strftime(TIME_FMT)
    except ValueError:
        raise ValidationError(
            f"时间格式无效：应为 YYYY-MM-DD HH:MM（例如 {datetime.now():%Y-%m-%d} 08:30）"
        ) from None


CHECKERS = {"name": check_name, "contact": check_contact, "datetime": check_datetime}


def validate_field(field: str, value: str):
    """统一入口：返回可直接存入记录的值；非法则抛 ValidationError。"""
    if field not in CHECKERS:
        raise ValidationError(f"未知字段：{field}")
    return CHECKERS[field](value)


class ContactStore:
    """联系人集合，改动后立即落盘。"""

    def __init__(self, path: str):
        self.path = path
        self.contacts: list[dict] = []
        self.load_error = ""
        self.load()

    # ---------- 持久化 ----------
    def load(self):
        self.load_error = ""
        if not os.path.exists(self.path):
            self.contacts = []
            return
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            items = data.get("contacts", []) if isinstance(data, dict) else []
            self.contacts = [self._normalize(it) for it in items if isinstance(it, dict)]
        except json.JSONDecodeError as exc:
            self.load_error = f"数据文件损坏（第 {exc.lineno} 行）：{exc.msg}"
            self._backup_broken()
            self.contacts = []
        except OSError as exc:
            self.load_error = f"读取数据文件失败：{exc}"
            self.contacts = []
        self._ensure_ids()

    # ---------- 稳定 id ----------
    @staticmethod
    def _id_num(cid: str):
        """从 c12 这类 id 里取出数字部分；不合法返回 None。"""
        m = re.fullmatch(r"c(\d+)", str(cid or "").strip())
        return int(m.group(1)) if m else None

    def _next_id(self) -> str:
        nums = [n for n in (self._id_num(c.get("id")) for c in self.contacts) if n is not None]
        return f"c{(max(nums) if nums else 0) + 1}"

    def _ensure_ids(self):
        """老数据没有 id：按现有最大编号补齐并立即落盘（只发生一次）。"""
        changed = False
        for c in self.contacts:
            if not c.get("id"):
                c["id"] = self._next_id()
                changed = True
        if changed:
            try:
                self.save()
            except OSError:
                pass  # 落盘失败不阻断加载；下次保存会再带上 id

    def find_by_id(self, cid: str):
        """按稳定 id 找联系人；找不到返回 None（调用方决定报错还是忽略）。"""
        cid = str(cid or "").strip()
        if not cid:
            return None
        for c in self.contacts:
            if c.get("id") == cid:
                return c
        return None

    def _normalize(self, item: dict) -> dict:
        name = (item.get("name") or "").strip()
        contact = (item.get("contact") or "").strip()
        contact_type = (item.get("contact_type") or "").strip()
        if not contact:
            # 没填号码：不能沿用"手机"（老数据里可能是空 contact + 默认值），统一显示未登记
            contact_type = CONTACT_UNSET
        elif not contact_type:
            contact_type = "邮箱" if "@" in contact else "手机"
        return {
            "id": str(item.get("id") or "").strip(),  # 稳定外键：发送任务通过它关联联系人
            "name": name,
            "contact": contact,
            "contact_type": contact_type,
            "datetime": (item.get("datetime") or "").strip(),
            "created_at": item.get("created_at", ""),
            "updated_at": item.get("updated_at", ""),
        }

    def _backup_broken(self):
        try:
            bak = self.path + ".broken"
            if os.path.exists(self.path):
                os.replace(self.path, bak)
        except OSError:
            pass

    def save(self):
        """原子写入：先写临时文件再替换，避免写一半断电导致数据损坏。"""
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        payload = {"version": 1, "contacts": self.contacts}
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(self.path), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)
        except Exception:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise

    # ---------- 增删改查 ----------
    def __len__(self):
        return len(self.contacts)

    def get(self, index: int) -> dict:
        """index 为用户可见的 1 起编号。"""
        return self.contacts[index - 1]

    def add(self, name: str, contact: str, when: str) -> dict:
        value_name = check_name(name)
        value_contact, contact_type = check_contact(contact)
        value_time = check_datetime(when)
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = {
            "id": self._next_id(),
            "name": value_name,
            "contact": value_contact,
            "contact_type": contact_type,
            "datetime": value_time,
            "created_at": now,
            "updated_at": now,
        }
        self.contacts.append(record)
        self.save()
        return record

    def update(self, index: int, field: str, value: str) -> dict:
        record = self.get(index)
        if field == "contact":
            value_contact, contact_type = check_contact(value)
            record["contact"] = value_contact
            record["contact_type"] = contact_type
        elif field == "name":
            record["name"] = check_name(value)
        elif field == "datetime":
            record["datetime"] = check_datetime(value)
        else:
            raise ValidationError(f"未知字段：{field}")
        record["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.save()
        return record

    def remove(self, index: int) -> dict:
        record = self.contacts.pop(index - 1)
        self.save()
        return record

    def find(self, keyword: str) -> list[tuple[int, dict]]:
        kw = (keyword or "").strip().lower()
        if not kw:
            return list(enumerate(self.contacts, start=1))
        return [
            (i, c)
            for i, c in enumerate(self.contacts, start=1)
            if kw in c["name"].lower() or kw in c["contact"].lower() or kw in c["datetime"]
        ]
