# -*- coding: utf-8 -*-
"""管理员工作台界面（控制台）。

合并后的唯一界面入口：双击桌面「微信定时发送」直接进这里，
微信定时发送任务在同一进程的后台常驻运行，不再单独注册入口。

本次只改"怎么显示"：菜单编号（0~7）、输入方式（输入序号回车）、
校验文案、数据层调用一律照旧，改动集中在排版与配色。
"""
from __future__ import annotations

import threading

import theme as th  # noqa: E402  （由 workbench 包提供，与控制台视觉系统同目录）
from contacts import (  # noqa: E402
    CONTACT_UNSET,
    FIELD_LABELS,
    FIELDS,
    ValidationError,
    is_optional,
    validate_field,
)

CANCEL = ("q", "quit", "exit", "0")

FIELD_HINTS = {
    "name": "最多 30 个字符",
    "contact": "可选 · 11 位手机号或邮箱，没登记可直接回车跳过",
    "datetime": "格式 YYYY-MM-DD HH:MM",
}


def contact_text(record: dict) -> str:
    """联系方式展示文案：没填时显示"未登记"，不要拼出"未登记 · 未登记"。"""
    contact = (record.get("contact") or "").strip()
    if not contact:
        return CONTACT_UNSET
    kind = (record.get("contact_type") or "").strip()
    return f"{contact} · {kind}" if kind else contact


class Workbench:
    """控制台菜单循环。task_ctrl 为空时只做联系人管理。"""

    def __init__(self, store, task_ctrl=None, notices=None):
        self.store = store
        self.task_ctrl = task_ctrl
        self.notices = list(notices or [])
        self._lock = threading.Lock()
        self.t = th.get()

    # ---------- 日志接管 ----------
    def on_log(self, level: str, message: str):
        """调度器等后台线程产生的提醒，攒到下一次刷新时统一展示。

        这样后台日志不会插进正在等待输入的提示行里，把界面打乱。
        """
        with self._lock:
            self.notices.append((level, message))
            if len(self.notices) > 20:
                del self.notices[0]

    def drain_notices(self):
        with self._lock:
            items, self.notices = self.notices, []
        return items

    # ---------- 基础输入输出 ----------
    def note(self, text: str, token: str = "faint"):
        """辅助说明行：按容器宽度折行，窄终端也不会顶破边框。"""
        for line in self.t.wrap(text, max(12, self.t.width - 4)):
            print("  " + self.t.paint(token, line))

    def read(self, prompt: str) -> str:
        """提示语过长时先自己占几行，再留一个干净的输入标记。"""
        t = self.t
        t.show_cursor()
        marker = t.paint("accent", "▸")
        if t.dw(prompt) > t.width - 6:
            self.note(prompt, "text")
            tip = "  " + marker + " "
        else:
            tip = "  " + t.paint("text", prompt) + "  " + marker + " "
        try:
            return input(tip).strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return "q"

    def pause(self, msg="按回车键继续..."):
        self.t.show_cursor()
        try:
            input("\n  " + self.t.paint("faint", msg) + " ")
        except (EOFError, KeyboardInterrupt):
            print()

    @staticmethod
    def is_cancel(value: str) -> bool:
        return value.lower() in CANCEL

    def say(self, kind: str, text: str, detail: str = ""):
        print(self.t.toast(kind, text, detail))

    def ask_number(self, prompt: str, maximum: int):
        while True:
            raw = self.read(prompt)
            if self.is_cancel(raw):
                return None
            if not raw:
                self.say("warn", "提示：请输入编号（输入 0 或 q 取消）")
                continue
            if not raw.isdigit():
                self.say("err", "错误：只能输入数字编号")
                continue
            num = int(raw)
            if not 1 <= num <= maximum:
                self.say("err", f"错误：编号需在 1 ~ {maximum} 之间")
                continue
            return num

    def ask_value(self, field: str, current: str = ""):
        while True:
            label = FIELD_LABELS[field]
            if current:
                hint = f"当前 {current}"
                tail = "，直接回车保持不变，输入 q 取消"
            else:
                hint = FIELD_HINTS.get(field, "")
                tail = "，输入 q 取消"
            if hint:
                self.note(f"{hint}{tail}")
            raw = self.read(f"请输入{label}")
            if self.is_cancel(raw):
                return None
            if current and not raw:
                return None
            if not raw:
                # 可选字段（联系方式）允许留空，返回空串照常保存
                if is_optional(field):
                    return ""
                self.say("err", f"错误：{label}不能为空")
                continue
            try:
                validate_field(field, raw)
                return raw
            except ValidationError as exc:
                self.say("err", f"错误：{exc}")
            except Exception as exc:
                self.say("err", f"错误：输入无效（{exc}）")

    # ---------- 页面骨架 ----------
    def page(self, title: str, subtitle: str = "", key: str = "") -> list:
        """开一个新页面：清屏 + 页头 + 暂挂的提醒。所有子页面都从这里起步。"""
        t = self.t
        t.screen_begin()
        lines = t.title_bar(f"微信定时发送 · {title}", subtitle)
        lines += t.blank()
        notes = self.drain_notices()
        if notes:
            lines += self.notice_card(notes)
            lines += t.blank()
        if key:
            lines.append(t.section(key))
        return lines

    def notice_card(self, notes) -> list:
        t = self.t
        tone = "err" if any(lv in ("ERROR", "CRITICAL") for lv, _ in notes) else "warn"
        shown, extra = notes[:5], len(notes) - 5
        inner = t.card_inner
        body = []
        for lv, msg in shown:
            for i, piece in enumerate(t.notice(lv, msg, limit=inner).split("\n")):
                body.append(piece.strip() if i == 0 else "  " + piece.strip())
        if extra > 0:
            body.append(t.toast("info", f"另有 {extra} 条提醒已写入 logs\\run.log", limit=inner))
        return t.card(body, title="提醒", tone=tone)

    def flush(self, lines):
        self.t.draw(lines)

    # ---------- 展示 ----------
    def status_strip(self) -> list:
        """把任务概要拆成徽标条；宽窄终端都靠它自适应换行。"""
        t = self.t
        items = []
        if self.task_ctrl:
            for raw in self.task_ctrl.brief().split("|"):
                part = raw.strip()
                if not part:
                    continue
                if "：" in part:
                    key, value = part.split("：", 1)
                else:
                    key, value = part, ""
                items.append((self._tone(key, value), key, value))
        items.append(("accent2", "联系人", f"{len(self.store)} 条"))
        return t.strip(items)

    @staticmethod
    def _tone(key: str, value: str) -> str:
        text = f"{key}{value}"
        if "已暂停" in text:
            return "warn"
        if "运行中" in text:
            return "ok"
        if "演练" in text or "dry_run" in text:
            return "accent2"
        if "正式发送" in text:
            return "err"
        if "无（" in text:
            return "faint"
        return "muted"

    def contact_lines(self, rows) -> list:
        """联系人列表：宽终端用表格，窄终端自动降级为堆叠卡片。"""
        t = self.t
        if not rows:
            return t.empty("还没有联系人", ["回主菜单按 2，新增第一条记录"])

        def record(c):
            return contact_text(c)

        if t.wide:
            # 余量给"联系方式"：邮箱/长号码是唯一会超长的字段，不该被截断
            widths = t.spread([4, 12, 28, 16], flexible=2)
            body = [
                [str(idx), c["name"], (record(c), "muted"), (c["datetime"], "accent2")]
                for idx, c in rows
            ]
            return t.table(
                ["编号", "姓名", "联系方式", "指定时间"],
                body,
                widths,
                aligns=[">", "<", "<", "<"],
            )

        out = []
        for idx, c in rows:
            out.append("  " + t.paint("faint", f"{idx:>3}") + "  "
                       + t.paint("text", c["name"]))
            out.append("        " + t.paint("muted", t.trunc(record(c), t.width - 10)))
            out.append("        " + t.paint("accent2", c["datetime"]))
            out.append("")
        return out[:-1]

    def print_list(self, rows=None):
        rows = rows if rows is not None else list(enumerate(self.store.contacts, start=1))
        self.flush([self.t.section(f"联系人 {len(rows)} 条")] + self.contact_lines(rows))

    def print_detail(self, idx: int, c: dict):
        t = self.t
        rows = [
            ("编号", idx),
            ("姓名", c["name"]),
            ("联系方式", contact_text(c)),
            ("指定时间", c["datetime"]),
            ("创建时间", c.get("created_at") or "-"),
            ("更新时间", c.get("updated_at") or "-"),
        ]
        columns = t.kv_columns(rows, key_width=10, limit=t.card_inner)
        self.flush(t.blank() + t.card(t.kv(rows, columns=columns, key_width=10,
                                           limit=t.card_inner),
                                     title="联系人详情"))

    # ---------- 联系人操作 ----------
    def action_list(self):
        self.flush(self.page("查看联系人", "列表与详情"))
        self.print_list()
        if self.store.contacts:
            num = self.ask_number("输入编号查看详情（0 返回）", len(self.store))
            if num:
                self.print_detail(num, self.store.get(num))

    def action_add(self):
        self.flush(self.page("新增联系人", "姓名和时间必填；联系方式没号码可留空", key="新增记录"))
        values = {}
        for field in FIELDS:
            value = self.ask_value(field)
            if value is None:
                self.say("info", "已取消新增")
                return
            values[field] = value
        try:
            record = self.store.add(values["name"], values["contact"], values["datetime"])
        except ValidationError as exc:
            self.say("err", f"错误：{exc}")
            return
        self.say("ok", "已保存", f"{record['name']} | {contact_text(record)} | {record['datetime']}")

    def action_edit(self):
        self.flush(self.page("编辑联系人", "可单独修改任一字段"))
        if not self.store.contacts:
            self.flush(self.t.empty("还没有联系人", ["回主菜单按 2，新增第一条记录"]))
            return
        self.print_list()
        num = self.ask_number("请输入要编辑的编号（0 取消）", len(self.store))
        if not num:
            return
        record = self.store.get(num)
        while True:
            t = self.t
            lines = t.card(t.kv([
                ("姓名", record["name"]),
                ("联系方式", contact_text(record)),
                ("指定时间", record["datetime"]),
            ], key_width=10), title=f"正在编辑第 {num} 条")
            lines += t.blank()
            lines += [t.section("选择要修改的字段")]
            lines += [t.item(str(i), FIELD_LABELS[f], FIELD_HINTS.get(f, ""))
                      for i, f in enumerate(FIELDS, start=1)]
            lines += [t.item("0", "返回主菜单", danger=True)]
            lines += t.blank()
            self.flush(lines)
            choice = self.ask_number("请选择要修改的字段编号", len(FIELDS))
            if not choice:
                return
            field = FIELDS[choice - 1]
            new_value = self.ask_value(field, record[field])
            if new_value is None:
                self.say("info", "未作修改")
                continue
            try:
                self.store.update(num, field, new_value)
            except ValidationError as exc:
                self.say("err", f"错误：{exc}")
                continue
            self.say("ok", f"已更新{FIELD_LABELS[field]}并保存", record[field])

    def action_delete(self):
        self.flush(self.page("删除联系人", "删除前会二次确认"))
        if not self.store.contacts:
            self.flush(self.t.empty("还没有联系人", ["没有可删除的记录"]))
            return
        self.print_list()
        num = self.ask_number("请输入要删除的编号（0 取消）", len(self.store))
        if not num:
            return
        record = self.store.get(num)
        t = self.t
        lines = t.card([
            t.paint("text", record["name"]),
            t.paint("muted", contact_text(record)),
            t.paint("accent2", record["datetime"]),
        ], title=f"即将删除第 {num} 条", tone="err")
        lines += t.blank()
        self.flush(lines)
        if self.read("确认删除？输入 y 确认，其它任意键取消").lower() != "y":
            self.say("info", "已取消删除")
            return
        self.store.remove(num)
        self.say("ok", "已删除并保存", record["name"])

    def action_search(self):
        self.flush(self.page("搜索联系人", "按姓名 / 联系方式 / 时间匹配"))
        keyword = self.read("请输入姓名/联系方式/时间的关键字（q 取消）")
        if self.is_cancel(keyword):
            return
        self.print_list(self.store.find(keyword))

    # ---------- 发送任务 ----------
    def action_task_status(self):
        self.flush(self.page("发送任务状态", "闸门自检与实际生效配置"))
        if not self.task_ctrl:
            self.say("warn", "未连接发送任务")
            return
        t = self.t
        pairs, targets, tips = [], [], []
        for raw in self.task_ctrl.status_lines():
            line = raw.strip()
            if line.startswith("- "):
                targets.append([x.strip() for x in line[2:].split("|")])
            elif line.startswith("提示"):
                tips.append(line)
            elif "：" in line:
                key, value = line.split("：", 1)
                pairs.append((key.strip(), value.strip()))
            else:
                pairs.append((line, ""))

        inner = t.card_inner
        columns = t.kv_columns(pairs, key_width=14, limit=inner)
        lines = t.card(t.kv(pairs, columns=columns, key_width=14, limit=inner),
                       title="任务概览")
        if targets:
            lines += t.blank()
            lines += [t.section(f"已启用联系人 {len(targets)} 个")]
            headers = ["联系人", "发送时间", "批准", "参考图"]
            # 这张表四列都是定长内容，拉伸只会把"批准/参考图"推离本行数据，
            # 所以保持自然宽度，宁可右边缘不齐也不要行内断开
            widths = [14, 20, 8, 10]
            if t.wide:
                rows = []
                for item in targets:
                    item = (item + ["", "", "", ""])[:4]
                    rows.append([
                        item[0],
                        item[1],
                        (item[2], "ok" if item[2] == "已批准" else "warn"),
                        (item[3], "ok" if item[3] == "有参考图" else "err"),
                    ])
                lines += t.table(headers, rows, widths,
                                 aligns=["<", "<", "^", "^"])
            else:
                for item in targets:
                    item = (item + ["", "", "", ""])[:4]
                    lines.append("  " + t.paint("text", item[0]))
                    lines.append("      " + t.paint("muted", item[1] or "-")
                                 + "   " + t.paint("ok" if item[2] == "已批准" else "warn", item[2])
                                 + "   " + t.paint("ok" if item[3] == "有参考图" else "err", item[3]))
        for tip in tips:
            lines += t.blank()
            lines.append(t.toast("warn", tip))
        self.flush(lines)

    def action_toggle_task(self):
        self.flush(self.page("暂停 / 恢复发送任务", "只影响定时调度，不动联系人数据"))
        if not self.task_ctrl:
            self.say("warn", "未连接发送任务")
            return
        paused = self.task_ctrl.toggle_pause()
        self.say("warn" if paused else "ok",
                 f"定时任务已{'暂停' if paused else '恢复'}",
                 "恢复后按配置时间继续" if not paused else "联系人数据不受影响")
        print()
        self.flush(self.status_strip())

    # ---------- 主循环 ----------
    def home_lines(self) -> list:
        t = self.t
        lines = t.title_bar("微信定时发送 · 管理员工作台", "本地控制台 · 数据只存在这台电脑上")
        lines += t.blank()
        notes = self.drain_notices()
        if notes:
            lines += self.notice_card(notes)
            lines += t.blank()
        lines += self.status_strip()
        lines += t.blank()
        lines += [t.section("联系人")]
        lines += [
            t.item("1", "查看联系人列表", "列表 / 详情"),
            t.item("2", "新增联系人", "姓名 · 联系方式(可选) · 时间"),
            t.item("3", "编辑联系人", "可单独改任一字段"),
            t.item("4", "删除联系人", "需二次确认"),
            t.item("5", "搜索联系人", "按姓名 / 联系方式 / 时间"),
        ]
        lines += t.blank()
        lines += [t.section("发送任务")]
        lines += [
            t.item("6", "发送任务状态", "运行模式与闸门自检"),
            t.item("7", "暂停/恢复发送任务", "只影响调度"),
        ]
        lines += t.blank()
        lines += [t.section("其他")]
        lines += [t.item("0", "退出程序", "数据已实时保存", danger=True)]
        lines += t.blank()
        lines += [t.rule(token="border2")]
        path = t.trunc_left(self.store.path, t.width - 14)
        lines += t.kv([("联系人", f"{len(self.store)} 条"), ("数据文件", path)], key_width=10)
        return lines

    def run(self):
        t = self.t
        actions = {
            "1": self.action_list,
            "2": self.action_add,
            "3": self.action_edit,
            "4": self.action_delete,
            "5": self.action_search,
            "6": self.action_task_status,
            "7": self.action_toggle_task,
        }
        try:
            while True:
                t.screen_begin()
                self.flush(self.home_lines())
                print()
                choice = self.read("请输入序号并回车")
                if choice in actions:
                    actions[choice]()
                    self.pause("按回车键返回主菜单...")
                elif choice in CANCEL:
                    print()
                    self.say("ok", "已退出工作台", f"数据已保存在 {self.store.path}")
                    return
                else:
                    self.say("err", "错误：无效序号，请输入 0 ~ 7 之间的数字")
                    self.pause("按回车键返回主菜单...")
        except (EOFError, KeyboardInterrupt):
            print()
        finally:
            t.screen_end()
